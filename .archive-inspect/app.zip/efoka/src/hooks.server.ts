import { error, redirect, type Handle } from '@sveltejs/kit';
import { readSession, SESSION_COOKIE } from '$lib/server/session';

// Webhooks authenticate with a shared secret instead of a session cookie.
const PUBLIC_ROUTES = ['/login', '/auth/google', '/api/webhooks'];

export const handle: Handle = async ({ event, resolve }) => {
	// Cookie-authenticated form requests must originate from this application.
	// Webhooks deliberately use a separate shared-secret authentication scheme.
	if (
		['POST', 'PUT', 'PATCH', 'DELETE'].includes(event.request.method) &&
		!event.url.pathname.startsWith('/api/webhooks')
	) {
		const origin = event.request.headers.get('origin');
		if (origin && origin !== event.url.origin) throw error(403, 'Request origin is not allowed');
	}

	event.locals.user = await readSession(event.cookies.get(SESSION_COOKIE));

	const isPublic = PUBLIC_ROUTES.some((route) => event.url.pathname.startsWith(route));
	if (!event.locals.user && !isPublic) {
		throw redirect(303, `/login?redirectTo=${encodeURIComponent(event.url.pathname)}`);
	}
	if (event.locals.user && event.url.pathname === '/login') {
		throw redirect(303, '/');
	}

	const response = await resolve(event);
	response.headers.set('X-Content-Type-Options', 'nosniff');
	response.headers.set('X-Frame-Options', 'DENY');
	response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
	response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
	const hotjarSources = process.env.PUBLIC_HOTJAR_SITE_ID
		? " https://static.hotjar.com https://*.hotjar.com https://*.hotjar.io wss://*.hotjar.com"
		: '';
	response.headers.set(
		'Content-Security-Policy',
		`default-src 'self'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'; object-src 'none'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'${hotjarSources}; connect-src 'self'${hotjarSources}`
	);
	return response;
};
