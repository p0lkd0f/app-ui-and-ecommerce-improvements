// Advanced Session Management for Efoka.ma

import { randomBytes } from 'crypto';

export interface SessionData {
	userId: number;
	userName: string;
	userEmail: string;
	role: string;
	permissions: string[];
	createdAt: Date;
	lastActivity: Date;
	ipAddress: string;
	userAgent: string;
	csrfToken: string;
	twoFactorVerified: boolean;
}

export interface SessionOptions {
	maxAge: number;
	rolling: boolean;
	renewOnActivity: boolean;
	secure: boolean;
	sameSite: 'strict' | 'lax' | 'none';
}

class SessionManager {
	private sessions = new Map<string, SessionData>();
	private cleanupInterval: NodeJS.Timeout | null = null;

	constructor(private options: SessionOptions = {
		maxAge: 86400000, // 24 hours
		rolling: true,
		renewOnActivity: true,
		secure: true,
		sameSite: 'strict'
	}) {
		this.startCleanup();
	}

	createSession(userData: {
		userId: number;
		userName: string;
		userEmail: string;
		role: string;
		permissions: string[];
	}, context: { ipAddress: string; userAgent: string }): string {
		const sessionId = this.generateSessionId();
		const csrfToken = this.generateCsrfToken();

		const sessionData: SessionData = {
			...userData,
			createdAt: new Date(),
			lastActivity: new Date(),
			ipAddress: context.ipAddress,
			userAgent: context.userAgent,
			csrfToken,
			twoFactorVerified: false
		};

		this.sessions.set(sessionId, sessionData);
		return sessionId;
	}

	getSession(sessionId: string): SessionData | null {
		const session = this.sessions.get(sessionId);

		if (!session) {
			return null;
		}

		if (this.isExpired(session)) {
			this.sessions.delete(sessionId);
			return null;
		}

		if (this.options.renewOnActivity) {
			session.lastActivity = new Date();
		}

		return session;
	}

	updateSession(sessionId: string, updates: Partial<SessionData>): boolean {
		const session = this.sessions.get(sessionId);

		if (!session || this.isExpired(session)) {
			return false;
		}

		Object.assign(session, updates);
		session.lastActivity = new Date();
		return true;
	}

	destroySession(sessionId: string): boolean {
		return this.sessions.delete(sessionId);
	}

	destroyAllUserSessions(userId: number): number {
		let count = 0;

		for (const [sessionId, session] of this.sessions.entries()) {
			if (session.userId === userId) {
				this.sessions.delete(sessionId);
				count++;
			}
		}

		return count;
	}

	getActiveSessions(userId: number): SessionData[] {
		const userSessions: SessionData[] = [];

		for (const session of this.sessions.values()) {
			if (session.userId === userId && !this.isExpired(session)) {
				userSessions.push(session);
			}
		}

		return userSessions;
	}

	validateCsrfToken(sessionId: string, token: string): boolean {
		const session = this.getSession(sessionId);
		return session ? session.csrfToken === token : false;
	}

	enableTwoFactor(sessionId: string): boolean {
		return this.updateSession(sessionId, { twoFactorVerified: true });
	}

	private generateSessionId(): string {
		return randomBytes(32).toString('hex');
	}

	private generateCsrfToken(): string {
		return randomBytes(16).toString('hex');
	}

	private isExpired(session: SessionData): boolean {
		const age = Date.now() - session.createdAt.getTime();
		return age > this.options.maxAge;
	}

	private startCleanup(): void {
		this.cleanupInterval = setInterval(() => {
			this.cleanupExpiredSessions();
		}, 60000); // Cleanup every minute
	}

	private cleanupExpiredSessions(): void {
		const now = Date.now();

		for (const [sessionId, session] of this.sessions.entries()) {
			if (now - session.createdAt.getTime() > this.options.maxAge) {
				this.sessions.delete(sessionId);
			}
		}
	}

	destroy(): void {
		if (this.cleanupInterval) {
			clearInterval(this.cleanupInterval);
		}
		this.sessions.clear();
	}

	getSessionCount(): number {
		return this.sessions.size;
	}

	getSessionStats(): {
		total: number;
		active: number;
		expired: number;
		byRole: Record<string, number>;
	} {
		const now = Date.now();
		let active = 0;
		let expired = 0;
		const byRole: Record<string, number> = {};

		for (const session of this.sessions.values()) {
			if (now - session.createdAt.getTime() > this.options.maxAge) {
				expired++;
			} else {
				active++;
			}

			byRole[session.role] = (byRole[session.role] || 0) + 1;
		}

		return {
			total: this.sessions.size,
			active,
			expired,
			byRole
		};
	}
}

// Session Security Features
export class SessionSecurity {
	private blockedIPs = new Set<string>();
	private suspiciousActivities = new Map<string, number>();

	blockIP(ipAddress: string, duration = 3600000): void {
		this.blockedIPs.add(ipAddress);

		setTimeout(() => {
			this.blockedIPs.delete(ipAddress);
		}, duration);
	}

	isIPBlocked(ipAddress: string): boolean {
		return this.blockedIPs.has(ipAddress);
	}

	reportSuspiciousActivity(ipAddress: string): void {
		const count = this.suspiciousActivities.get(ipAddress) || 0;
		this.suspiciousActivities.set(ipAddress, count + 1);

		if (count + 1 >= 5) {
			this.blockIP(ipAddress);
		}
	}

	clearSuspiciousActivities(ipAddress: string): void {
		this.suspiciousActivities.delete(ipAddress);
	}
}

// Session Analytics
export class SessionAnalytics {
	private loginEvents: Array<{
		userId: number;
		timestamp: Date;
		ipAddress: string;
		userAgent: string;
		success: boolean;
	}> = [];

	recordLoginEvent(event: {
		userId: number;
		ipAddress: string;
		userAgent: string;
		success: boolean;
	}): void {
		this.loginEvents.push({
			...event,
			timestamp: new Date()
		});

		// Keep only last 1000 events
		if (this.loginEvents.length > 1000) {
			this.loginEvents = this.loginEvents.slice(-1000);
		}
	}

	getLoginStats(hours = 24): {
		total: number;
		successful: number;
		failed: number;
		uniqueUsers: number;
		topIPs: Array<{ ip: string; count: number }>;
	} {
		const cutoff = new Date(Date.now() - hours * 3600000);
		const recentEvents = this.loginEvents.filter(e => e.timestamp >= cutoff);

		const successful = recentEvents.filter(e => e.success).length;
		const failed = recentEvents.filter(e => !e.success).length;
		const uniqueUsers = new Set(recentEvents.map(e => e.userId)).size;

		const ipCounts = new Map<string, number>();
		for (const event of recentEvents) {
			ipCounts.set(event.ipAddress, (ipCounts.get(event.ipAddress) || 0) + 1);
		}

		const topIPs = Array.from(ipCounts.entries())
			.map(([ip, count]) => ({ ip, count }))
			.sort((a, b) => b.count - a.count)
			.slice(0, 10);

		return {
			total: recentEvents.length,
			successful,
			failed,
			uniqueUsers,
			topIPs
		};
	}
}

// Export singleton instance
export const sessionManager = new SessionManager();
export const sessionSecurity = new SessionSecurity();
export const sessionAnalytics = new SessionAnalytics();
