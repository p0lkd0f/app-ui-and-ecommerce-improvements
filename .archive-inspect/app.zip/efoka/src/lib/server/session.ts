import { randomBytes } from 'node:crypto';
import { cacheDelete, cacheGet, cacheSet } from './cache';
import { one } from './db';
import { verifyPassword } from './password';
import type { SessionUser } from '$lib/types';

export const SESSION_COOKIE = 'cod_session';
const TTL_SECONDS = 60 * 60 * 8;

export async function login(email: string, password: string): Promise<SessionUser | null> {
	const user = await one<{
		id: number;
		name: string;
		email: string;
		role: SessionUser['role'];
		password_hash: string;
		active: boolean;
	}>('SELECT id, name, email, role, password_hash, active FROM users WHERE lower(email) = lower($1)', [email]);
	if (!user || !user.active) return null;
	if (!verifyPassword(password, user.password_hash)) return null;
	return { id: user.id, name: user.name, email: user.email, role: user.role };
}

export async function createSession(user: SessionUser): Promise<string> {
	// 256 bits of entropy keeps session identifiers unguessable.
	const token = randomBytes(32).toString('base64url');
	await cacheSet(`session:${token}`, JSON.stringify(user), TTL_SECONDS);
	return token;
}

export async function readSession(token: string | undefined): Promise<SessionUser | null> {
	if (!token) return null;
	const raw = await cacheGet(`session:${token}`);
	if (!raw) return null;
	try {
		const parsed = JSON.parse(raw) as SessionUser;
		return Number.isSafeInteger(parsed.id) && typeof parsed.name === 'string' && typeof parsed.email === 'string'
			? parsed
			: null;
	} catch {
		return null;
	}
}

export function destroySession(token: string | undefined): Promise<void> {
	return token ? cacheDelete(`session:${token}`) : Promise.resolve();
}
