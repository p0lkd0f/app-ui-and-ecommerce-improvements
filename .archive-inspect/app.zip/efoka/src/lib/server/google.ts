import { randomBytes, timingSafeEqual } from 'node:crypto';
import { error } from '@sveltejs/kit';
import { one } from './db';
import type { SessionUser } from '$lib/types';

const STATE_COOKIE = 'cod_google_state';

export function beginGoogleAuth(origin: string) {
	const clientId = process.env.GOOGLE_CLIENT_ID;
	if (!clientId) throw error(503, 'Google sign-in has not been configured');
	const state = randomBytes(32).toString('base64url');
	const redirectUri = process.env.GOOGLE_REDIRECT_URI ?? `${origin}/auth/google/callback`;
	const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
	url.searchParams.set('client_id', clientId);
	url.searchParams.set('redirect_uri', redirectUri);
	url.searchParams.set('response_type', 'code');
	url.searchParams.set('scope', 'openid email profile');
	url.searchParams.set('state', state);
	url.searchParams.set('prompt', 'select_account');
	return { state, url: url.toString() };
}

export function stateMatches(expected: string | undefined, received: string | null): boolean {
	if (!expected || !received) return false;
	const a = Buffer.from(expected);
	const b = Buffer.from(received);
	return a.length === b.length && timingSafeEqual(a, b);
}

export async function workspaceGoogleUser(code: string, origin: string): Promise<SessionUser> {
	const clientId = process.env.GOOGLE_CLIENT_ID;
	const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
	if (!clientId || !clientSecret) throw error(503, 'Google sign-in has not been configured');
	const redirectUri = process.env.GOOGLE_REDIRECT_URI ?? `${origin}/auth/google/callback`;
	const token = await fetch('https://oauth2.googleapis.com/token', {
		method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body: new URLSearchParams({ code, client_id: clientId, client_secret: clientSecret, redirect_uri: redirectUri, grant_type: 'authorization_code' })
	});
	if (!token.ok) throw error(401, 'Google sign-in could not be verified');
	const tokenData = (await token.json()) as { access_token?: string };
	if (!tokenData.access_token) throw error(401, 'Google did not return an access token');
	const profileResponse = await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tokenData.access_token}` } });
	if (!profileResponse.ok) throw error(401, 'Google profile could not be verified');
	const profile = (await profileResponse.json()) as { sub?: string; email?: string; email_verified?: boolean; name?: string };
	if (!profile.sub || !profile.email || !profile.email_verified) throw error(401, 'A verified Google email is required');
	const user = await one<SessionUser>('SELECT id, name, email, role FROM users WHERE active = true AND (google_subject = $1 OR lower(email) = lower($2))', [profile.sub, profile.email]);
	if (!user) throw error(403, 'This Google account is not a member of this workspace');
	await one('UPDATE users SET google_subject = $2 WHERE id = $1', [user.id, profile.sub]);
	return user;
}

export { STATE_COOKIE };
