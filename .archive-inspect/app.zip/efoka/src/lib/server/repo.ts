import { one, query, transaction } from './db';
import { cached, cacheDelete } from './cache';
import { deliverWhatsAppText } from './whatsapp';
import type {
	Conversation,
	Customer,
	OrderEvent,
	OrderItem,
	OrderRow,
	Product,
	Shipment,
	WhatsAppMessage
} from '$lib/types';

const ORDER_SELECT = `
	SELECT o.id, o.reference, o.status, o.confirmation, o.payment_method, o.total, o.subtotal,
	       o.shipping_fee, o.cod_fee, o.cogs, o.source, o.call_attempts, o.created_at,
	       c.full_name AS customer_name, c.phone AS customer_phone, c.city AS customer_city, c.id AS customer_id,
	       s.name AS store_name, u.name AS agent_name,
	       (SELECT coalesce(sum(quantity), 0) FROM order_items i WHERE i.order_id = o.id) AS items_count
	FROM orders o
	JOIN customers c ON c.id = o.customer_id
	JOIN stores s ON s.id = o.store_id
	LEFT JOIN users u ON u.id = o.assigned_agent_id`;

export interface OrderFilters {
	status?: string;
	confirmation?: string;
	search?: string;
	city?: string;
	limit?: number;
}

export async function listOrders(filters: OrderFilters = {}): Promise<OrderRow[]> {
	const where: string[] = [];
	const params: unknown[] = [];
	if (filters.status && filters.status !== 'all') {
		params.push(filters.status);
		where.push(`o.status = $${params.length}`);
	}
	if (filters.confirmation && filters.confirmation !== 'all') {
		params.push(filters.confirmation);
		where.push(`o.confirmation = $${params.length}`);
	}
	if (filters.city && filters.city !== 'all') {
		params.push(filters.city);
		where.push(`c.city = $${params.length}`);
	}
	if (filters.search) {
		params.push(`%${filters.search.toLowerCase()}%`);
		where.push(
			`(lower(o.reference) LIKE $${params.length} OR lower(c.full_name) LIKE $${params.length} OR c.phone LIKE $${params.length})`
		);
	}
	params.push(filters.limit ?? 60);
	return query<OrderRow>(
		`${ORDER_SELECT} ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
		 ORDER BY o.created_at DESC LIMIT $${params.length}`,
		params
	);
}

export async function getOrder(id: number) {
	const order = await one<OrderRow>(`${ORDER_SELECT} WHERE o.id = $1`, [id]);
	if (!order) return null;
	const [items, events, shipment, calls] = await Promise.all([
		query<OrderItem>(
			`SELECT i.id, i.product_id, p.sku, p.name, i.quantity, i.unit_price, i.unit_cost
			 FROM order_items i JOIN products p ON p.id = i.product_id WHERE i.order_id = $1`,
			[id]
		),
		query<OrderEvent>(
			'SELECT id, type, message, actor, created_at FROM order_events WHERE order_id = $1 ORDER BY created_at DESC, id DESC',
			[id]
		),
		one<Shipment>(
			`SELECT s.*, o.reference, c.full_name AS customer_name, c.city AS customer_city, c.phone AS customer_phone
			 FROM shipments s JOIN orders o ON o.id = s.order_id JOIN customers c ON c.id = o.customer_id
			 WHERE s.order_id = $1`,
			[id]
		),
		query<{ id: number; outcome: string; notes: string | null; created_at: string; agent: string | null }>(
			`SELECT a.id, a.outcome, a.notes, a.created_at, u.name AS agent
			 FROM call_attempts a LEFT JOIN users u ON u.id = a.agent_id
			 WHERE a.order_id = $1 ORDER BY a.created_at DESC`,
			[id]
		)
	]);
	return { order, items, events, shipment, calls };
}

export async function addOrderEvent(orderId: number, type: string, message: string, actor: string) {
	await query('INSERT INTO order_events (order_id, type, message, actor) VALUES ($1,$2,$3,$4)', [
		orderId,
		type,
		message,
		actor
	]);
}

export async function createManualOrder(input: {
	storeId: number;
	productId: number;
	quantity: number;
	fullName: string;
	phone: string;
	city: string;
	address?: string;
	shippingFee: number;
	paymentMethod: 'cod' | 'prepaid';
	actor: string;
}) {
	return transaction(async (client) => {
		const customerResult = await client.query<{ id: number }>(
			`INSERT INTO customers (full_name, phone, city, address) VALUES ($1,$2,$3,$4)
			 ON CONFLICT (phone) DO UPDATE SET full_name = EXCLUDED.full_name, city = EXCLUDED.city,
			 address = coalesce(EXCLUDED.address, customers.address) RETURNING id`,
			[input.fullName, input.phone, input.city, input.address ?? null]
		);
		const productResult = await client.query<{ id: number; sku: string; name: string; price: number; cost: number; stock: number }>(
			'SELECT id, sku, name, price, cost, stock FROM products WHERE id = $1 AND active = true FOR UPDATE', [input.productId]
		);
		const product = productResult.rows[0];
		if (!product) throw new Error('The selected product is unavailable');
		if (product.stock < input.quantity) throw new Error(`Only ${product.stock} units of ${product.name} are available`);
		const subtotal = Math.round(product.price * input.quantity * 100) / 100;
		const cogs = Math.round(product.cost * input.quantity * 100) / 100;
		const total = subtotal + input.shippingFee;
		const reference = `#MAN-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
		const orderResult = await client.query<{ id: number }>(
			`INSERT INTO orders (reference, store_id, customer_id, status, confirmation, payment_method, subtotal, shipping_fee, cod_fee, total, cogs, source)
			 VALUES ($1,$2,$3,'new','pending',$4,$5,$6,0,$7,$8,'manual') RETURNING id`,
			[reference, input.storeId, customerResult.rows[0].id, input.paymentMethod, subtotal, input.shippingFee, total, cogs]
		);
		const orderId = orderResult.rows[0].id;
		await client.query('INSERT INTO order_items (order_id, product_id, quantity, unit_price, unit_cost) VALUES ($1,$2,$3,$4,$5)', [
			orderId, product.id, input.quantity, product.price, product.cost
		]);
		await client.query('UPDATE products SET stock = stock - $2 WHERE id = $1', [product.id, input.quantity]);
		await client.query('INSERT INTO stock_movements (product_id, delta, reason) VALUES ($1,$2,$3)', [product.id, -input.quantity, `Manual order ${reference}`]);
		await client.query('INSERT INTO order_events (order_id, type, message, actor) VALUES ($1,$2,$3,$4)', [
			orderId, 'created', `Manual order entered: ${product.sku} × ${input.quantity}`, input.actor
		]);
		return { id: orderId, reference };
	});
}

export async function setOrderStatus(orderId: number, status: string, actor: string) {
	await query('UPDATE orders SET status = $2, updated_at = now() WHERE id = $1', [orderId, status]);
	await addOrderEvent(orderId, 'status', `Status changed to ${status}`, actor);
	await invalidateAnalytics();
}

export async function recordConfirmation(
	orderId: number,
	outcome: 'confirmed' | 'no_answer' | 'cancelled' | 'scheduled' | 'wrong_number',
	agentId: number,
	actor: string,
	notes?: string
) {
	const confirmation =
		outcome === 'confirmed'
			? 'confirmed'
			: outcome === 'cancelled' || outcome === 'wrong_number'
				? 'cancelled'
				: outcome === 'scheduled'
					? 'scheduled'
					: 'unreachable';
	const status = outcome === 'confirmed' ? 'confirmed' : outcome === 'cancelled' || outcome === 'wrong_number' ? 'cancelled' : 'new';
	await query(
		`UPDATE orders SET confirmation = $2, status = $3, call_attempts = call_attempts + 1,
		 assigned_agent_id = coalesce(assigned_agent_id, $4), updated_at = now() WHERE id = $1`,
		[orderId, confirmation, status, agentId]
	);
	await query('INSERT INTO call_attempts (order_id, agent_id, outcome, notes) VALUES ($1,$2,$3,$4)', [
		orderId,
		agentId,
		outcome,
		notes ?? null
	]);
	await addOrderEvent(orderId, 'confirmation', `Call outcome: ${outcome.replace('_', ' ')}`, actor);
	await invalidateAnalytics();
}

export function confirmationQueue() {
	return query<OrderRow>(
		`${ORDER_SELECT} WHERE o.confirmation IN ('pending','unreachable','scheduled') AND o.status = 'new'
		 ORDER BY o.call_attempts ASC, o.created_at ASC LIMIT 50`
	);
}

export function listCustomers(search = '') {
	const params: unknown[] = [];
	let where = '';
	if (search) {
		params.push(`%${search.toLowerCase()}%`);
		where = `WHERE lower(c.full_name) LIKE $1 OR c.phone LIKE $1 OR lower(c.city) LIKE $1`;
	}
	return query<Customer>(
		`SELECT c.*,
		    count(o.id)::int AS orders_count,
		    count(o.id) FILTER (WHERE o.status = 'delivered')::int AS delivered_count,
		    coalesce(sum(o.total) FILTER (WHERE o.status = 'delivered'), 0) AS total_spent
		 FROM customers c LEFT JOIN orders o ON o.customer_id = c.id
		 ${where}
		 GROUP BY c.id ORDER BY total_spent DESC, c.full_name LIMIT 100`,
		params
	);
}

export async function getCustomer(id: number) {
	const customer = await one<Customer>(
		`SELECT c.*,
		    count(o.id)::int AS orders_count,
		    count(o.id) FILTER (WHERE o.status = 'delivered')::int AS delivered_count,
		    coalesce(sum(o.total) FILTER (WHERE o.status = 'delivered'), 0) AS total_spent
		 FROM customers c LEFT JOIN orders o ON o.customer_id = c.id WHERE c.id = $1 GROUP BY c.id`,
		[id]
	);
	if (!customer) return null;
	const orders = await query<OrderRow>(`${ORDER_SELECT} WHERE o.customer_id = $1 ORDER BY o.created_at DESC`, [id]);
	return { customer, orders };
}

export function listProducts() {
	return query<Product>(
		`SELECT p.*, coalesce(sum(i.quantity) FILTER (WHERE o.status = 'delivered'), 0)::int AS units_sold
		 FROM products p
		 LEFT JOIN order_items i ON i.product_id = p.id
		 LEFT JOIN orders o ON o.id = i.order_id
		 GROUP BY p.id ORDER BY p.name`
	);
}

export async function adjustStock(productId: number, delta: number, reason: string, actorId: number) {
	await query('UPDATE products SET stock = greatest(0, stock + $2) WHERE id = $1', [productId, delta]);
	await query('INSERT INTO stock_movements (product_id, delta, reason, actor_id) VALUES ($1,$2,$3,$4)', [
		productId,
		delta,
		reason,
		actorId
	]);
}

export function listShipments(status = 'all') {
	const params: unknown[] = [];
	let where = '';
	if (status !== 'all') {
		params.push(status);
		where = 'WHERE s.status = $1';
	}
	return query<Shipment>(
		`SELECT s.id, s.order_id, o.reference, s.carrier, s.tracking_code, s.status, s.cod_amount,
		        s.cod_collected, s.shipped_at, s.delivered_at,
		        c.full_name AS customer_name, c.city AS customer_city, c.phone AS customer_phone
		 FROM shipments s JOIN orders o ON o.id = s.order_id JOIN customers c ON c.id = o.customer_id
		 ${where} ORDER BY s.created_at DESC LIMIT 80`,
		params
	);
}

export async function createShipment(orderId: number, carrier: string, actor: string) {
	const order = await one<{ total: number; reference: string }>('SELECT total, reference FROM orders WHERE id = $1', [
		orderId
	]);
	if (!order) return;
	const existing = await one<{ id: number }>('SELECT id FROM shipments WHERE order_id = $1', [orderId]);
	if (existing) return;
	const tracking = `TRK${Math.floor(Math.random() * 900000 + 100000)}${orderId}`;
	await query(
		`INSERT INTO shipments (order_id, carrier, tracking_code, status, cod_amount, shipped_at)
		 VALUES ($1,$2,$3,'label_created',$4, now())`,
		[orderId, carrier, tracking, order.total]
	);
	await query("UPDATE orders SET status = 'shipped', updated_at = now() WHERE id = $1", [orderId]);
	await addOrderEvent(orderId, 'fulfilment', `Shipment created with ${carrier} (${tracking})`, actor);
	await invalidateAnalytics();
}

export async function advanceShipment(shipmentId: number, status: string, actor: string) {
	const shipment = await one<{ order_id: number; cod_amount: number }>(
		'SELECT order_id, cod_amount FROM shipments WHERE id = $1',
		[shipmentId]
	);
	if (!shipment) return;
	const delivered = status === 'delivered';
	await query(
		`UPDATE shipments SET status = $2, cod_collected = $3,
		   delivered_at = CASE WHEN $3 THEN now() ELSE delivered_at END WHERE id = $1`,
		[shipmentId, status, delivered]
	);
	if (delivered) {
		await query("UPDATE orders SET status = 'delivered', updated_at = now() WHERE id = $1", [shipment.order_id]);
		await addOrderEvent(shipment.order_id, 'delivery', 'Delivered, COD cash collected', actor);
	} else if (status === 'returned') {
		await query("UPDATE orders SET status = 'returned', updated_at = now() WHERE id = $1", [shipment.order_id]);
		await query(
			"INSERT INTO returns (order_id, reason, status, refund_amount) VALUES ($1,'Delivery failed','requested',$2)",
			[shipment.order_id, shipment.cod_amount]
		);
		await addOrderEvent(shipment.order_id, 'delivery', 'Parcel returned by carrier', actor);
	} else {
		await addOrderEvent(shipment.order_id, 'delivery', `Carrier update: ${status.replace(/_/g, ' ')}`, actor);
	}
	await invalidateAnalytics();
}

export function listReturns() {
	return query<{
		id: number;
		reference: string;
		reason: string;
		status: string;
		refund_amount: number;
		created_at: string;
		customer_name: string;
		city: string;
	}>(
		`SELECT r.id, o.reference, r.reason, r.status, r.refund_amount, r.created_at,
		        c.full_name AS customer_name, c.city
		 FROM returns r JOIN orders o ON o.id = r.order_id JOIN customers c ON c.id = o.customer_id
		 ORDER BY r.created_at DESC LIMIT 60`
	);
}

export function setReturnStatus(id: number, status: string) {
	return query('UPDATE returns SET status = $2 WHERE id = $1', [id, status]);
}

export function listConversations() {
	return query<Conversation>(
		`SELECT w.id, w.customer_id, w.phone, w.status, w.unread, w.last_message_at,
		        c.full_name AS customer_name, c.city,
		        coalesce((SELECT body FROM whatsapp_messages m WHERE m.conversation_id = w.id ORDER BY created_at DESC LIMIT 1), '') AS last_message
		 FROM whatsapp_conversations w JOIN customers c ON c.id = w.customer_id
		 ORDER BY w.last_message_at DESC`
	);
}

export function conversationMessages(conversationId: number) {
	return query<WhatsAppMessage>(
		'SELECT id, direction, body, author, status, created_at FROM whatsapp_messages WHERE conversation_id = $1 ORDER BY created_at ASC, id ASC',
		[conversationId]
	);
}

export async function sendWhatsAppMessage(conversationId: number, body: string, author: string) {
	const conversation = await one<{ phone: string }>('SELECT phone FROM whatsapp_conversations WHERE id = $1', [conversationId]);
	if (!conversation) throw new Error('Conversation not found');
	const status = await deliverWhatsAppText(conversation.phone, body);
	await query(
		"INSERT INTO whatsapp_messages (conversation_id, direction, body, author, status) VALUES ($1,'out',$2,$3,$4)",
		[conversationId, body, author, status]
	);
	await query('UPDATE whatsapp_conversations SET last_message_at = now(), unread = 0 WHERE id = $1', [conversationId]);
}

export function markConversationRead(conversationId: number) {
	return query('UPDATE whatsapp_conversations SET unread = 0 WHERE id = $1', [conversationId]);
}

export function listAutomations() {
	return query<{
		id: number;
		name: string;
		description: string;
		trigger: string;
		action: string;
		enabled: boolean;
		runs: number;
	}>('SELECT * FROM automations ORDER BY id');
}

export function toggleAutomation(id: number, enabled: boolean) {
	return query('UPDATE automations SET enabled = $2 WHERE id = $1', [id, enabled]);
}

export function listUsers() {
	return query<{
		id: number;
		name: string;
		email: string;
		role: string;
		active: boolean;
		created_at: string;
		handled: number;
	}>(
		`SELECT u.id, u.name, u.email, u.role, u.active, u.created_at,
		        (SELECT count(*)::int FROM call_attempts a WHERE a.agent_id = u.id) AS handled
		 FROM users u ORDER BY u.id`
	);
}

export function setUserActive(id: number, active: boolean) {
	return query('UPDATE users SET active = $2 WHERE id = $1', [id, active]);
}

export function setUserRole(id: number, role: string) {
	return query('UPDATE users SET role = $2 WHERE id = $1', [id, role]);
}

export function listIntegrations() {
	return query<{
		id: number;
		provider: string;
		kind: string;
		status: string;
		account_ref: string | null;
		last_sync: string | null;
		store_name: string;
	}>(
		`SELECT i.id, i.provider, i.kind, i.status, i.account_ref, i.last_sync, s.name AS store_name
		 FROM integrations i JOIN stores s ON s.id = i.store_id ORDER BY i.kind, i.provider`
	);
}

export function setIntegrationStatus(id: number, status: string) {
	return query(
		"UPDATE integrations SET status = $2, last_sync = CASE WHEN $2 = 'connected' THEN now() ELSE last_sync END WHERE id = $1",
		[id, status]
	);
}

export function listStores() {
	return query<{ id: number; name: string; domain: string; currency: string }>(
		'SELECT id, name, domain, currency FROM stores ORDER BY id'
	);
}

function invalidateAnalytics() {
	return Promise.all([cacheDelete('analytics:overview'), cacheDelete('dashboard:summary')]);
}

export interface DashboardSummary {
	revenue7: number;
	revenue30: number;
	orders7: number;
	pendingConfirmation: number;
	inTransit: number;
	deliveryRate: number;
	confirmationRate: number;
	profit30: number;
	codOutstanding: number;
	lowStock: number;
	unreadChats: number;
	series: { day: string; orders: number; delivered: number; revenue: number }[];
	statusBreakdown: { status: string; count: number }[];
	topCities: { city: string; orders: number; delivered: number; revenue: number }[];
	agents: { name: string; handled: number; confirmed: number }[];
}

export function dashboardSummary(): Promise<DashboardSummary> {
	return cached<DashboardSummary>('dashboard:summary', 30, async () => {
		const [totals, series, statusBreakdown, topCities, agents] = await Promise.all([
			one<Record<string, number>>(`
				SELECT
				  coalesce(sum(total) FILTER (WHERE status = 'delivered' AND created_at > now() - interval '7 days'), 0) AS revenue7,
				  coalesce(sum(total) FILTER (WHERE status = 'delivered' AND created_at > now() - interval '30 days'), 0) AS revenue30,
				  coalesce(sum(total - cogs - shipping_fee) FILTER (WHERE status = 'delivered' AND created_at > now() - interval '30 days'), 0) AS profit30,
				  count(*) FILTER (WHERE created_at > now() - interval '7 days')::int AS orders7,
				  count(*) FILTER (WHERE confirmation IN ('pending','unreachable','scheduled') AND status = 'new')::int AS pending_confirmation,
				  count(*) FILTER (WHERE status = 'shipped')::int AS in_transit,
				  coalesce(sum(total) FILTER (WHERE status = 'shipped'), 0) AS cod_outstanding,
				  count(*) FILTER (WHERE status = 'delivered' AND created_at > now() - interval '30 days')::int AS delivered30,
				  count(*) FILTER (WHERE status IN ('delivered','returned','cancelled') AND created_at > now() - interval '30 days')::int AS closed30,
				  count(*) FILTER (WHERE confirmation = 'confirmed' AND created_at > now() - interval '30 days')::int AS confirmed30,
				  count(*) FILTER (WHERE created_at > now() - interval '30 days')::int AS all30
				FROM orders`),
			query<{ day: string; orders: number; delivered: number; revenue: number }>(`
				SELECT to_char(d.day, 'Mon DD') AS day,
				       count(o.id)::int AS orders,
				       count(o.id) FILTER (WHERE o.status = 'delivered')::int AS delivered,
				       coalesce(sum(o.total) FILTER (WHERE o.status = 'delivered'), 0) AS revenue
				FROM generate_series(current_date - interval '13 days', current_date, interval '1 day') d(day)
				LEFT JOIN orders o ON date_trunc('day', o.created_at) = d.day
				GROUP BY d.day ORDER BY d.day`),
			query<{ status: string; count: number }>(
				'SELECT status, count(*)::int AS count FROM orders GROUP BY status ORDER BY count DESC'
			),
			query<{ city: string; orders: number; delivered: number; revenue: number }>(`
				SELECT c.city,
				       count(o.id)::int AS orders,
				       count(o.id) FILTER (WHERE o.status = 'delivered')::int AS delivered,
				       coalesce(sum(o.total) FILTER (WHERE o.status = 'delivered'), 0) AS revenue
				FROM orders o JOIN customers c ON c.id = o.customer_id
				GROUP BY c.city ORDER BY revenue DESC LIMIT 8`),
			query<{ name: string; handled: number; confirmed: number }>(`
				SELECT u.name,
				       count(a.id)::int AS handled,
				       count(a.id) FILTER (WHERE a.outcome = 'confirmed')::int AS confirmed
				FROM users u JOIN call_attempts a ON a.agent_id = u.id
				GROUP BY u.name ORDER BY handled DESC`)
		]);
		const t = totals ?? {};
		const lowStock = await one<{ count: number }>(
			'SELECT count(*)::int AS count FROM products WHERE stock <= low_stock'
		);
		const unread = await one<{ count: number }>(
			'SELECT coalesce(sum(unread), 0)::int AS count FROM whatsapp_conversations'
		);
		return {
			revenue7: Number(t.revenue7 ?? 0),
			revenue30: Number(t.revenue30 ?? 0),
			profit30: Number(t.profit30 ?? 0),
			orders7: Number(t.orders7 ?? 0),
			pendingConfirmation: Number(t.pending_confirmation ?? 0),
			inTransit: Number(t.in_transit ?? 0),
			codOutstanding: Number(t.cod_outstanding ?? 0),
			deliveryRate: t.closed30 ? Math.round((Number(t.delivered30) / Number(t.closed30)) * 100) : 0,
			confirmationRate: t.all30 ? Math.round((Number(t.confirmed30) / Number(t.all30)) * 100) : 0,
			lowStock: lowStock?.count ?? 0,
			unreadChats: unread?.count ?? 0,
			series,
			statusBreakdown,
			topCities,
			agents
		};
	});
}

export interface AnalyticsOverview {
	summary: DashboardSummary;
	sources: { source: string; orders: number; delivered: number; revenue: number; profit: number }[];
	products: { name: string; sku: string; units: number; revenue: number; margin: number }[];
	returnsByReason: { reason: string; count: number }[];
	monthly: { month: string; revenue: number; profit: number; orders: number }[];
}

export function analyticsOverview(): Promise<AnalyticsOverview> {
	return cached<AnalyticsOverview>('analytics:overview', 30, async () => {
		const [summary, sources, products, returnsByReason, monthly] = await Promise.all([
			dashboardSummary(),
			query<{ source: string; orders: number; delivered: number; revenue: number; profit: number }>(`
				SELECT source,
				       count(*)::int AS orders,
				       count(*) FILTER (WHERE status = 'delivered')::int AS delivered,
				       coalesce(sum(total) FILTER (WHERE status = 'delivered'), 0) AS revenue,
				       coalesce(sum(total - cogs - shipping_fee) FILTER (WHERE status = 'delivered'), 0) AS profit
				FROM orders GROUP BY source ORDER BY revenue DESC`),
			query<{ name: string; sku: string; units: number; revenue: number; margin: number }>(`
				SELECT p.name, p.sku,
				       coalesce(sum(i.quantity) FILTER (WHERE o.status = 'delivered'), 0)::int AS units,
				       coalesce(sum(i.quantity * i.unit_price) FILTER (WHERE o.status = 'delivered'), 0) AS revenue,
				       coalesce(sum(i.quantity * (i.unit_price - i.unit_cost)) FILTER (WHERE o.status = 'delivered'), 0) AS margin
				FROM products p LEFT JOIN order_items i ON i.product_id = p.id LEFT JOIN orders o ON o.id = i.order_id
				GROUP BY p.id ORDER BY revenue DESC LIMIT 10`),
			query<{ reason: string; count: number }>(
				'SELECT reason, count(*)::int AS count FROM returns GROUP BY reason ORDER BY count DESC'
			),
			query<{ month: string; revenue: number; profit: number; orders: number }>(`
				SELECT to_char(date_trunc('month', created_at), 'Mon YYYY') AS month,
				       coalesce(sum(total) FILTER (WHERE status = 'delivered'), 0) AS revenue,
				       coalesce(sum(total - cogs - shipping_fee) FILTER (WHERE status = 'delivered'), 0) AS profit,
				       count(*)::int AS orders
				FROM orders GROUP BY date_trunc('month', created_at) ORDER BY date_trunc('month', created_at)`)
		]);
		return { summary, sources, products, returnsByReason, monthly };
	});
}
