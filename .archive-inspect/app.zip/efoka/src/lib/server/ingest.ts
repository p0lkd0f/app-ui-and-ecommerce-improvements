import { error } from '@sveltejs/kit';
import { one, query } from './db';
import { addOrderEvent } from './repo';

export interface StoreOrderPayload {
	store_domain?: string;
	customer: { full_name: string; phone: string; city: string; address?: string; email?: string };
	items: { sku: string; quantity: number }[];
	source?: string;
	shipping_fee?: number;
	payment_method?: 'cod' | 'prepaid';
}

/**
 * Turns a store webhook payload into a workspace order: upserts the customer,
 * prices the lines from the catalog and drops the order into the call queue.
 */
export async function ingestStoreOrder(provider: string, payload: StoreOrderPayload) {
	if (!payload.customer?.phone || !payload.items?.length) throw error(400, 'customer.phone and items are required');

	const store =
		(await one<{ id: number }>('SELECT id FROM stores WHERE domain = $1', [payload.store_domain ?? ''])) ??
		(await one<{ id: number }>('SELECT id FROM stores ORDER BY id LIMIT 1'));
	if (!store) throw error(500, 'No store configured');

	const customer = await one<{ id: number }>(
		`INSERT INTO customers (full_name, phone, email, city, address)
		 VALUES ($1,$2,$3,$4,$5)
		 ON CONFLICT (phone) DO UPDATE SET full_name = EXCLUDED.full_name, city = EXCLUDED.city,
		   address = coalesce(EXCLUDED.address, customers.address)
		 RETURNING id`,
		[
			payload.customer.full_name,
			payload.customer.phone,
			payload.customer.email ?? null,
			payload.customer.city,
			payload.customer.address ?? null
		]
	);
	if (!customer) throw error(500, 'Could not store customer');

	const skus = payload.items.map((item) => item.sku);
	const products = await query<{ id: number; sku: string; price: number; cost: number }>(
		'SELECT id, sku, price, cost FROM products WHERE sku = ANY($1)',
		[skus]
	);
	const missing = skus.filter((sku) => !products.some((p) => p.sku === sku));
	if (missing.length) throw error(400, `Unknown SKUs: ${missing.join(', ')}`);

	let subtotal = 0;
	let cogs = 0;
	for (const item of payload.items) {
		const product = products.find((p) => p.sku === item.sku)!;
		subtotal += product.price * item.quantity;
		cogs += product.cost * item.quantity;
	}
	const shipping = payload.shipping_fee ?? 35;
	const codFee = Math.round(subtotal * 0.02 * 100) / 100;

	const last = await one<{ reference: string }>("SELECT reference FROM orders ORDER BY id DESC LIMIT 1");
	const reference = `#${Number(last?.reference.replace('#', '') ?? 10000) + 1}`;

	const order = await one<{ id: number }>(
		`INSERT INTO orders (reference, store_id, customer_id, status, confirmation, payment_method,
		   subtotal, shipping_fee, cod_fee, total, cogs, source)
		 VALUES ($1,$2,$3,'new','pending',$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
		[
			reference,
			store.id,
			customer.id,
			payload.payment_method ?? 'cod',
			subtotal,
			shipping,
			codFee,
			subtotal + shipping,
			cogs,
			payload.source ?? provider
		]
	);
	if (!order) throw error(500, 'Could not store order');

	for (const item of payload.items) {
		const product = products.find((p) => p.sku === item.sku)!;
		await query(
			'INSERT INTO order_items (order_id, product_id, quantity, unit_price, unit_cost) VALUES ($1,$2,$3,$4,$5)',
			[order.id, product.id, item.quantity, product.price, product.cost]
		);
	}
	await addOrderEvent(order.id, 'created', `Order received from ${provider}`, 'webhook');

	return { id: order.id, reference, status: 'new', confirmation: 'pending', total: subtotal + shipping };
}
