import { env } from '$env/dynamic/private';

export interface MetaWhatsAppConfig {
	phoneNumberId: string;
	accessToken: string;
	businessAccountId: string;
	webhookVerifyToken?: string;
}

export interface WhatsAppMessage {
	from: string;
	to: string;
	message: {
		text?: string;
		image?: { url: string; caption?: string };
		document?: { url: string; filename?: string };
		template?: { name: string; language: { code: string } };
	};
}

export interface WhatsAppTemplate {
	name: string;
	category: 'MARKETING' | 'UTILITY' | 'AUTHENTICATION';
	language: string;
	components: Array<{
		type: 'HEADER' | 'BODY' | 'FOOTER' | 'BUTTONS';
		text?: string;
		buttons?: Array<{
			type: 'QUICK_REPLY' | 'URL';
			text: string;
			payload?: string;
			url?: string;
		}>;
	}>;
}

export interface WhatsAppWebhookEvent {
	object: string;
	entry: Array<{
		id: string;
		changes: Array<{
			value: {
				messaging_product: string;
				metadata: {
					display_phone_number: string;
					phone_number_id: string;
				};
				messages?: Array<{
					from: string;
					id: string;
					timestamp: string;
					text?: { body: string };
					image?: { mime_type: string; sha256: string; id: string };
					type: string;
				}>;
				statuses?: Array<{
					id: string;
					recipient_id: string;
					status: string;
					timestamp: string;
				}>;
			};
			field: string;
		}>;
	}>;
}

class MetaWhatsAppAPI {
	private config: MetaWhatsAppConfig;
	private baseUrl = 'https://graph.facebook.com/v18.0';

	constructor(config: MetaWhatsAppConfig) {
		this.config = config;
	}

	private get headers() {
		return {
			'Authorization': `Bearer ${this.config.accessToken}`,
			'Content-Type': 'application/json'
		};
	}

	async sendTextMessage(to: string, text: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.phoneNumberId}/messages`, {
				method: 'POST',
				headers: this.headers,
				body: JSON.stringify({
					messaging_product: 'whatsapp',
					to: to.replace(/[^\d]/g, ''),
					text: { body: text }
				})
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true, messageId: data.messages[0].id };
		} catch (error) {
			console.error('Error sending WhatsApp message:', error);
			return { success: false, error: 'Failed to send message' };
		}
	}

	async sendTemplateMessage(
		to: string,
		templateName: string,
		languageCode: string = 'en_US',
		components?: any[]
	): Promise<{ success: boolean; messageId?: string; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.phoneNumberId}/messages`, {
				method: 'POST',
				headers: this.headers,
				body: JSON.stringify({
					messaging_product: 'whatsapp',
					to: to.replace(/[^\d]/g, ''),
					type: 'template',
					template: {
						name: templateName,
						language: { code: languageCode },
						components: components || []
					}
				})
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true, messageId: data.messages[0].id };
		} catch (error) {
			console.error('Error sending WhatsApp template:', error);
			return { success: false, error: 'Failed to send template' };
		}
	}

	async sendImageMessage(
		to: string,
		imageUrl: string,
		caption?: string
	): Promise<{ success: boolean; messageId?: string; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.phoneNumberId}/messages`, {
				method: 'POST',
				headers: this.headers,
				body: JSON.stringify({
					messaging_product: 'whatsapp',
					to: to.replace(/[^\d]/g, ''),
					type: 'image',
					image: {
						link: imageUrl,
						caption: caption || ''
					}
				})
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true, messageId: data.messages[0].id };
		} catch (error) {
			console.error('Error sending WhatsApp image:', error);
			return { success: false, error: 'Failed to send image' };
		}
	}

	async sendDocumentMessage(
		to: string,
		documentUrl: string,
		filename?: string
	): Promise<{ success: boolean; messageId?: string; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.phoneNumberId}/messages`, {
				method: 'POST',
				headers: this.headers,
				body: JSON.stringify({
					messaging_product: 'whatsapp',
					to: to.replace(/[^\d]/g, ''),
					type: 'document',
					document: {
						link: documentUrl,
						filename: filename || 'document'
					}
				})
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true, messageId: data.messages[0].id };
		} catch (error) {
			console.error('Error sending WhatsApp document:', error);
			return { success: false, error: 'Failed to send document' };
		}
	}

	async markMessageAsRead(messageId: string): Promise<{ success: boolean; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${messageId}`, {
				method: 'POST',
				headers: this.headers,
				body: JSON.stringify({
					status: 'read'
				})
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true };
		} catch (error) {
			console.error('Error marking message as read:', error);
			return { success: false, error: 'Failed to mark as read' };
		}
	}

	async getMessageInfo(messageId: string): Promise<any> {
		try {
			const response = await fetch(`${this.baseUrl}/${messageId}`, {
				headers: this.headers
			});

			const data = await response.json();

			if (data.error) {
				throw new Error(data.error.message);
			}

			return data;
		} catch (error) {
			console.error('Error getting message info:', error);
			throw error;
		}
	}

	async getPhoneNumberInfo(): Promise<any> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.phoneNumberId}`, {
				headers: this.headers
			});

			const data = await response.json();

			if (data.error) {
				throw new Error(data.error.message);
			}

			return data;
		} catch (error) {
			console.error('Error getting phone number info:', error);
			throw error;
		}
	}

	async verifyWebhook(
		mode: string,
		token: string,
		challenge: string
	): Promise<{ success: boolean; challenge?: string }> {
		if (mode === 'subscribe' && token === this.config.webhookVerifyToken) {
			return { success: true, challenge };
		}

		return { success: false };
	}

	async createMessageTemplate(template: WhatsAppTemplate): Promise<{ success: boolean; templateId?: string; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.businessAccountId}/message_templates`, {
				method: 'POST',
				headers: this.headers,
				body: JSON.stringify(template)
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true, templateId: data.id };
		} catch (error) {
			console.error('Error creating message template:', error);
			return { success: false, error: 'Failed to create template' };
		}
	}

	async listMessageTemplates(): Promise<{ success: boolean; templates?: any[]; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${this.config.businessAccountId}/message_templates`, {
				headers: this.headers
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true, templates: data.data };
		} catch (error) {
			console.error('Error listing message templates:', error);
			return { success: false, error: 'Failed to list templates' };
		}
	}

	async deleteMessageTemplate(templateId: string): Promise<{ success: boolean; error?: string }> {
		try {
			const response = await fetch(`${this.baseUrl}/${templateId}`, {
				method: 'DELETE',
				headers: this.headers
			});

			const data = await response.json();

			if (data.error) {
				return { success: false, error: data.error.message };
			}

			return { success: true };
		} catch (error) {
			console.error('Error deleting message template:', error);
			return { success: false, error: 'Failed to delete template' };
		}
	}
}

// Factory function to create Meta WhatsApp API instance
export function createMetaWhatsAppAPI(): MetaWhatsAppAPI {
	const config: MetaWhatsAppConfig = {
		phoneNumberId: env.META_PHONE_NUMBER_ID || '',
		accessToken: env.META_ACCESS_TOKEN || '',
		businessAccountId: env.META_BUSINESS_ACCOUNT_ID || '',
		webhookVerifyToken: env.META_WEBHOOK_VERIFY_TOKEN
	};

	if (!config.phoneNumberId || !config.accessToken || !config.businessAccountId) {
		throw new Error('Meta WhatsApp API credentials not configured');
	}

	return new MetaWhatsAppAPI(config);
}

// Webhook event parser
export function parseWhatsAppWebhook(event: WhatsAppWebhookEvent): Array<{
	messageId: string;
	from: string;
	text?: string;
	image?: string;
	timestamp: Date;
}> {
	const results: Array<{
		messageId: string;
		from: string;
		text?: string;
		image?: string;
		timestamp: Date;
	}> = [];

	for (const entry of event.entry) {
		for (const change of entry.changes) {
			if (change.field === 'messages' && change.value.messages) {
				for (const message of change.value.messages) {
					results.push({
						messageId: message.id,
						from: message.from,
						text: message.text?.body,
						image: message.image?.id,
						timestamp: new Date(parseInt(message.timestamp) * 1000)
					});
				}
			}
		}
	}

	return results;
}

// Automation rules for WhatsApp
export interface WhatsAppAutomationRule {
	id: string;
	name: string;
	trigger: {
		type: 'keyword' | 'order_status' | 'time_based' | 'customer_action';
		conditions: Record<string, unknown>;
	};
	actions: Array<{
		type: 'send_message' | 'send_template' | 'update_status' | 'notify_team';
		config: Record<string, unknown>;
	}>;
	enabled: boolean;
	priority: number;
}

export class WhatsAppAutomationEngine {
	private rules: WhatsAppAutomationRule[] = [];

	constructor(rules: WhatsAppAutomationRule[] = []) {
		this.rules = rules;
	}

	addRule(rule: WhatsAppAutomationRule): void {
		this.rules.push(rule);
		this.rules.sort((a, b) => b.priority - a.priority);
	}

	removeRule(ruleId: string): void {
		this.rules = this.rules.filter(r => r.id !== ruleId);
	}

	async processMessage(message: { from: string; text?: string; orderId?: string }): Promise<Array<{
		ruleId: string;
		action: string;
		result: unknown;
	}>> {
		const results: Array<{ ruleId: string; action: string; result: unknown }> = [];

		for (const rule of this.rules) {
			if (!rule.enabled) continue;

			if (await this.matchesTrigger(rule.trigger, message)) {
				for (const action of rule.actions) {
					try {
						const result = await this.executeAction(action, message);
						results.push({
							ruleId: rule.id,
							action: action.type,
							result
						});
					} catch (error) {
						console.error(`Error executing action ${action.type} for rule ${rule.id}:`, error);
					}
				}
			}
		}

		return results;
	}

	private async matchesTrigger(trigger: WhatsAppAutomationRule['trigger'], message: { from: string; text?: string; orderId?: string }): Promise<boolean> {
		switch (trigger.type) {
			case 'keyword':
				if (message.text && trigger.conditions.keywords) {
					const keywords = trigger.conditions.keywords as string[];
					return keywords.some(keyword =>
						message.text!.toLowerCase().includes(keyword.toLowerCase())
					);
				}
				return false;

			case 'order_status':
				if (message.orderId && trigger.conditions.status) {
					// This would check actual order status in database
					return true;
				}
				return false;

			case 'time_based':
				if (trigger.conditions.time) {
					const triggerTime = new Date(trigger.conditions.time as string);
					return new Date() >= triggerTime;
				}
				return false;

			case 'customer_action':
				// Handle customer-specific triggers
				return true;

			default:
				return false;
		}
	}

	private async executeAction(action: WhatsAppAutomationRule['actions'][0], message: { from: string; text?: string; orderId?: string }): Promise<unknown> {
		switch (action.type) {
			case 'send_message':
				// Implementation would use MetaWhatsAppAPI
				return { sent: true };

			case 'send_template':
				// Implementation would use MetaWhatsAppAPI
				return { sent: true };

			case 'update_status':
				// Update order/conversation status in database
				return { updated: true };

			case 'notify_team':
				// Send notification to team members
				return { notified: true };

			default:
				throw new Error(`Unknown action type: ${action.type}`);
		}
	}
}
