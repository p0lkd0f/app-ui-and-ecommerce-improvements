import { createClient, type RedisClientType } from 'redis';

// Redis backs sessions and short-lived analytics caching. When it is not
// reachable the app degrades to an in-process store so the MVP still runs.
const url = process.env.REDIS_URL ?? 'redis://localhost:6379';

let client: RedisClientType | null = null;
let connecting: Promise<RedisClientType | null> | null = null;
const memory = new Map<string, { value: string; expiresAt: number }>();

async function getClient(): Promise<RedisClientType | null> {
	if (client?.isOpen) return client;
	if (!connecting) {
		const candidate: RedisClientType = createClient({ url });
		candidate.on('error', () => {});
		connecting = candidate
			.connect()
			.then(() => {
				client = candidate;
				return client;
			})
			.catch(() => null)
			.finally(() => {
				connecting = null;
			});
	}
	return connecting;
}

export async function cacheGet(key: string): Promise<string | null> {
	const redis = await getClient();
	if (redis) return redis.get(key);
	const hit = memory.get(key);
	if (!hit) return null;
	if (hit.expiresAt < Date.now()) {
		memory.delete(key);
		return null;
	}
	return hit.value;
}

export async function cacheSet(key: string, value: string, ttlSeconds: number): Promise<void> {
	const redis = await getClient();
	if (redis) {
		await redis.set(key, value, { EX: ttlSeconds });
		return;
	}
	memory.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
}

export async function cacheDelete(key: string): Promise<void> {
	const redis = await getClient();
	if (redis) {
		await redis.del(key);
		return;
	}
	memory.delete(key);
}

/** Atomic with Redis; best-effort in the single-process development fallback. */
export async function cacheIncrement(key: string, ttlSeconds: number): Promise<number> {
	const redis = await getClient();
	if (redis) {
		const value = await redis.incr(key);
		if (value === 1) await redis.expire(key, ttlSeconds);
		return value;
	}
	const current = Number(await cacheGet(key) ?? '0') + 1;
	await cacheSet(key, String(current), ttlSeconds);
	return current;
}

export async function cached<T>(key: string, ttlSeconds: number, load: () => Promise<T>): Promise<T> {
	const hit = await cacheGet(key);
	if (hit) return JSON.parse(hit) as T;
	const value = await load();
	await cacheSet(key, JSON.stringify(value), ttlSeconds);
	return value;
}
