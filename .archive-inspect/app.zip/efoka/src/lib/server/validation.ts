import { error } from '@sveltejs/kit';

export const ROLES = ['owner', 'manager', 'agent', 'packer'] as const;
export const ORDER_STATUSES = ['new', 'confirmed', 'packed', 'shipped', 'delivered', 'cancelled', 'returned'] as const;
export const SHIPMENT_STATUSES = ['label_created', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered', 'failed', 'returned'] as const;

export function requiredText(value: FormDataEntryValue | null, label: string, max = 160): string {
	const text = typeof value === 'string' ? value.trim().replace(/\s+/g, ' ') : '';
	if (!text || text.length > max) throw error(400, `${label} is required and must be ${max} characters or fewer`);
	return text;
}

export function positiveId(value: FormDataEntryValue | null): number {
	const id = Number(value);
	if (!Number.isSafeInteger(id) || id < 1) throw error(400, 'Invalid record identifier');
	return id;
}

export function oneOf<T extends readonly string[]>(value: FormDataEntryValue | null, choices: T, label: string): T[number] {
	if (typeof value !== 'string' || !choices.includes(value)) throw error(400, `Invalid ${label}`);
	return value as T[number];
}

export function workEmail(value: FormDataEntryValue | null): string {
	const email = requiredText(value, 'Email', 254).toLowerCase();
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw error(400, 'Enter a valid email address');
	return email;
}
