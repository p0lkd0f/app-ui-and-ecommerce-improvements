import pg from 'pg';

const { Pool, types } = pg;

// numeric/int8 come back as strings by default; the app works in numbers.
types.setTypeParser(1700, (v) => Number.parseFloat(v));
types.setTypeParser(20, (v) => Number.parseInt(v, 10));

const connectionString =
	process.env.DATABASE_URL ?? 'postgres://codcommerce:codcommerce@localhost:5432/codcommerce';

export const pool = new Pool({ connectionString, max: 10 });

export async function query<T>(text: string, params: unknown[] = []): Promise<T[]> {
	const result = await pool.query(text, params);
	return result.rows as T[];
}

export async function one<T>(text: string, params: unknown[] = []): Promise<T | null> {
	const rows = await query<T>(text, params);
	return rows[0] ?? null;
}

/** Runs related writes atomically so orders can never be created without their items. */
export async function transaction<T>(work: (client: pg.PoolClient) => Promise<T>): Promise<T> {
	const client = await pool.connect();
	try {
		await client.query('BEGIN');
		const result = await work(client);
		await client.query('COMMIT');
		return result;
	} catch (err) {
		await client.query('ROLLBACK');
		throw err;
	} finally {
		client.release();
	}
}
