import OpenAI from 'openai';
import { env } from '$env/dynamic/private';

// Initialize OpenAI client
let openaiClient: OpenAI | null = null;

function getOpenAIClient(): OpenAI {
	if (!openaiClient) {
		const apiKey = env.OPENAI_API_KEY;
		if (!apiKey) {
			throw new Error('OPENAI_API_KEY environment variable is not set');
		}
		openaiClient = new OpenAI({
			apiKey,
			organization: env.OPENAI_ORGANIZATION_ID
		});
	}
	return openaiClient;
}

export interface AIConversationContext {
	orderId?: string;
	customerId?: string;
	customerName?: string;
	orderStatus?: string;
	orderTotal?: number;
	storeName?: string;
	productInfo?: string;
	previousMessages?: Array<{ role: 'user' | 'assistant'; content: string }>;
}

export interface AIResponse {
	response: string;
	suggestedActions?: Array<{
		type: 'confirm_order' | 'cancel_order' | 'modify_order' | 'escalate' | 'schedule_call';
		label: string;
		data?: Record<string, unknown>;
	}>;
	confidence: number;
}

const SYSTEM_PROMPT = `You are an intelligent customer service AI assistant for Efoka.ma, an e-commerce operations platform. Your role is to help customers with their orders, provide accurate information, and assist with order-related queries.

Key capabilities:
- Order status tracking and updates
- Product information and recommendations
- Order modifications and cancellations
- Delivery and shipping information
- Payment and COD-related questions
- Returns and exchanges
- Escalation to human agents when needed

Guidelines:
- Be professional, friendly, and helpful
- Use clear, concise language
- Always verify order information before providing specific details
- If uncertain, ask clarifying questions
- Escalate to human agents for complex issues
- Maintain context of the conversation
- Respect customer privacy and data security

Available actions:
- confirm_order: Help confirm customer orders
- cancel_order: Assist with order cancellations
- modify_order: Help modify order details
- escalate: Transfer to human agent
- schedule_call: Schedule a callback

Format your responses naturally and include suggested actions when appropriate.`;

export async function generateAIResponse(
	userMessage: string,
	context: AIConversationContext = {}
): Promise<AIResponse> {
	try {
		const openai = getOpenAIClient();

		// Build conversation history
		const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
			{
				role: 'system',
				content: `${SYSTEM_PROMPT}\n\nCurrent context:\n${formatContext(context)}`
			}
		];

		// Add previous messages if available
		if (context.previousMessages) {
			messages.push(...context.previousMessages);
		}

		// Add current user message
		messages.push({
			role: 'user',
			content: userMessage
		});

		const completion = await openai.chat.completions.create({
			model: 'gpt-4-turbo-preview',
			messages,
			temperature: 0.7,
			max_tokens: 500,
			functions: [
				{
					name: 'suggest_action',
					description: 'Suggest an action to take based on the conversation',
					parameters: {
						type: 'object',
						properties: {
							actions: {
								type: 'array',
								items: {
									type: 'object',
									properties: {
										type: {
											type: 'string',
											enum: ['confirm_order', 'cancel_order', 'modify_order', 'escalate', 'schedule_call']
										},
										label: { type: 'string' },
										data: { type: 'object' }
									},
									required: ['type', 'label']
								}
							}
						},
						required: ['actions']
					}
				}
			],
			function_call: 'auto'
		});

		const responseMessage = completion.choices[0].message;
		const responseText = responseMessage.content || "I apologize, but I couldn't generate a response. Please try again.";

		let suggestedActions: AIResponse['suggestedActions'] = [];
		let confidence = 0.8;

		// Parse function call if present
		if (responseMessage.function_call) {
			try {
				const functionArgs = JSON.parse(responseMessage.function_call.arguments);
				if (functionArgs.actions) {
					suggestedActions = functionArgs.actions;
				}
			} catch (e) {
				console.error('Failed to parse function call arguments:', e);
			}
		}

		// Calculate confidence based on response quality
		if (responseText.toLowerCase().includes('uncertain') || responseText.toLowerCase().includes('not sure')) {
			confidence = 0.5;
		}

		return {
			response: responseText,
			suggestedActions,
			confidence
		};
	} catch (error) {
		console.error('OpenAI API error:', error);
		return {
			response: "I apologize, but I'm experiencing technical difficulties. Please try again or contact our support team.",
			suggestedActions: [
				{
					type: 'escalate',
					label: 'Connect with human agent'
				}
			],
			confidence: 0.3
		};
	}
}

function formatContext(context: AIConversationContext): string {
	const parts: string[] = [];

	if (context.storeName) parts.push(`Store: ${context.storeName}`);
	if (context.customerName) parts.push(`Customer: ${context.customerName}`);
	if (context.orderId) parts.push(`Order ID: ${context.orderId}`);
	if (context.orderStatus) parts.push(`Order Status: ${context.orderStatus}`);
	if (context.orderTotal) parts.push(`Order Total: ${context.orderTotal}`);
	if (context.productInfo) parts.push(`Product Info: ${context.productInfo}`);

	return parts.length > 0 ? parts.join('\n') : 'No specific context available';
}

export async function generateOrderConfirmationMessage(
	orderDetails: {
		orderId: string;
		customerName: string;
		products: Array<{ name: string; quantity: number; price: number }>;
		total: number;
		shippingAddress: string;
		estimatedDelivery: string;
	}
): Promise<string> {
	try {
		const openai = getOpenAIClient();

		const prompt = `Generate a friendly order confirmation message for the following order:

Order ID: ${orderDetails.orderId}
Customer: ${orderDetails.customerName}
Products: ${orderDetails.products.map(p => `${p.quantity}x ${p.name} (${p.price})`).join(', ')}
Total: ${orderDetails.total}
Shipping Address: ${orderDetails.shippingAddress}
Estimated Delivery: ${orderDetails.estimatedDelivery}

The message should be:
- Professional and friendly
- Include all key order details
- Mention the estimated delivery time
- Provide contact information for support
- Keep it concise but comprehensive`;

		const completion = await openai.chat.completions.create({
			model: 'gpt-4-turbo-preview',
			messages: [
				{
					role: 'system',
					content: 'You are a helpful e-commerce assistant generating order confirmation messages.'
				},
				{
					role: 'user',
					content: prompt
				}
			],
			temperature: 0.8,
			max_tokens: 300
		});

		return completion.choices[0].message.content || 'Order confirmed successfully!';
	} catch (error) {
		console.error('Error generating order confirmation:', error);
		return `Thank you for your order ${orderDetails.orderId}! Your order has been confirmed and will be delivered to ${orderDetails.shippingAddress} by ${orderDetails.estimatedDelivery}.`;
	}
}

export async function analyzeCustomerSentiment(
	message: string
): Promise<{ sentiment: 'positive' | 'neutral' | 'negative'; confidence: number; topics: string[] }> {
	try {
		const openai = getOpenAIClient();

		const completion = await openai.chat.completions.create({
			model: 'gpt-4-turbo-preview',
			messages: [
				{
					role: 'system',
					content: 'Analyze the sentiment of the customer message and identify key topics. Return as JSON with sentiment (positive/neutral/negative), confidence (0-1), and topics array.'
				},
				{
					role: 'user',
					content: message
				}
			],
			temperature: 0.3,
			max_tokens: 150,
			response_format: { type: 'json_object' }
		});

		const response = JSON.parse(completion.choices[0].message.content || '{}');
		return {
			sentiment: response.sentiment || 'neutral',
			confidence: response.confidence || 0.5,
			topics: response.topics || []
		};
	} catch (error) {
		console.error('Error analyzing sentiment:', error);
		return { sentiment: 'neutral', confidence: 0.5, topics: [] };
	}
}

export async function suggestProductRecommendations(
	customerHistory: {
		previousOrders: Array<{ products: string[]; total: number }>;
	 interests?: string[];
	 budget?: number;
	}
): Promise<Array<{ name: string; reason: string; price: number }>> {
	try {
		const openai = getOpenAIClient();

		const prompt = `Based on the customer's purchase history and preferences, suggest 3-5 product recommendations:

Previous Orders: ${customerHistory.previousOrders.map(o => o.products.join(', ')).join('; ')}
Interests: ${customerHistory.interests?.join(', ') || 'Not specified'}
Budget: ${customerHistory.budget || 'Not specified'}

Provide recommendations with product name, reason for recommendation, and estimated price. Return as JSON array.`;

		const completion = await openai.chat.completions.create({
			model: 'gpt-4-turbo-preview',
			messages: [
				{
					role: 'system',
					content: 'You are an e-commerce recommendation engine. Suggest products based on customer history and preferences.'
				},
				{
					role: 'user',
					content: prompt
				}
			],
			temperature: 0.7,
			max_tokens: 400,
			response_format: { type: 'json_object' }
		});

		const response = JSON.parse(completion.choices[0].message.content || '{}');
		return response.recommendations || [];
	} catch (error) {
		console.error('Error generating recommendations:', error);
		return [];
	}
}
