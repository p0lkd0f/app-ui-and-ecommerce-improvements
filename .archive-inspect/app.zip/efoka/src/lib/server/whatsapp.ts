/** WhatsApp Cloud API adapter. It never sends unless deployment secrets are configured. */
export async function deliverWhatsAppText(to: string, body: string): Promise<'queued' | 'sent' | 'failed'> {
	const token = process.env.WHATSAPP_ACCESS_TOKEN;
	const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
	if (!token || !phoneNumberId) return 'queued';
	try {
		const response = await fetch(`https://graph.facebook.com/v20.0/${encodeURIComponent(phoneNumberId)}/messages`, {
			method: 'POST',
			headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
			body: JSON.stringify({ messaging_product: 'whatsapp', to: to.replace(/\D/g, ''), type: 'text', text: { body } })
		});
		return response.ok ? 'sent' : 'failed';
	} catch {
		return 'failed';
	}
}
