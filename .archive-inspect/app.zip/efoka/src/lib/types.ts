export type Role = 'owner' | 'manager' | 'agent' | 'packer';

export type OrderStatus =
	| 'new'
	| 'confirmed'
	| 'packed'
	| 'shipped'
	| 'delivered'
	| 'cancelled'
	| 'returned';

export type ConfirmationStatus = 'pending' | 'confirmed' | 'unreachable' | 'cancelled' | 'scheduled';

export type ShipmentStatus =
	| 'label_created'
	| 'picked_up'
	| 'in_transit'
	| 'out_for_delivery'
	| 'delivered'
	| 'failed'
	| 'returned';

export interface SessionUser {
	id: number;
	name: string;
	email: string;
	role: Role;
}

export interface OrderRow {
	id: number;
	reference: string;
	status: OrderStatus;
	confirmation: ConfirmationStatus;
	payment_method: 'cod' | 'prepaid';
	total: number;
	subtotal: number;
	shipping_fee: number;
	cod_fee: number;
	cogs: number;
	source: string;
	call_attempts: number;
	created_at: string;
	customer_name: string;
	customer_phone: string;
	customer_city: string;
	customer_id: number;
	store_name: string;
	agent_name: string | null;
	items_count: number;
}

export interface OrderItem {
	id: number;
	product_id: number;
	sku: string;
	name: string;
	quantity: number;
	unit_price: number;
	unit_cost: number;
}

export interface OrderEvent {
	id: number;
	type: string;
	message: string;
	actor: string;
	created_at: string;
}

export interface Customer {
	id: number;
	full_name: string;
	phone: string;
	email: string | null;
	city: string;
	address: string | null;
	tags: string[];
	blacklisted: boolean;
	notes: string | null;
	created_at: string;
	orders_count: number;
	delivered_count: number;
	total_spent: number;
}

export interface Product {
	id: number;
	sku: string;
	name: string;
	category: string;
	price: number;
	cost: number;
	stock: number;
	low_stock: number;
	active: boolean;
	units_sold: number;
}

export interface Shipment {
	id: number;
	order_id: number;
	reference: string;
	carrier: string;
	tracking_code: string;
	status: ShipmentStatus;
	cod_amount: number;
	cod_collected: boolean;
	shipped_at: string | null;
	delivered_at: string | null;
	customer_name: string;
	customer_city: string;
	customer_phone: string;
}

export interface Conversation {
	id: number;
	customer_id: number;
	phone: string;
	status: 'open' | 'pending' | 'closed';
	unread: number;
	last_message_at: string;
	customer_name: string;
	city: string;
	last_message: string;
}

export interface WhatsAppMessage {
	id: number;
	direction: 'in' | 'out';
	body: string;
	author: string;
	status: string;
	created_at: string;
}
