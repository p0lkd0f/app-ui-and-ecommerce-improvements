<script lang="ts">
	import { browser } from '$app/environment';
	import { env } from '$env/dynamic/public';
	const HOTJAR_SITE_ID = env.PUBLIC_HOTJAR_SITE_ID ?? '';

	let visible = $state(Boolean(HOTJAR_SITE_ID) && browser && localStorage.getItem('analytics-consent') === null);

	function enableAnalytics() {
		if (!browser || !HOTJAR_SITE_ID) return;
		localStorage.setItem('analytics-consent', 'granted');
		const script = document.createElement('script');
		script.async = true;
		script.src = `https://static.hotjar.com/c/hotjar-${encodeURIComponent(HOTJAR_SITE_ID)}.js?sv=6`;
		document.head.appendChild(script);
		visible = false;
	}

	function declineAnalytics() {
		if (browser) localStorage.setItem('analytics-consent', 'declined');
		visible = false;
	}
</script>

{#if visible}
	<aside class="privacy-card" aria-label="Analytics preference">
		<strong>Help improve this workspace</strong>
		<p>With your permission, anonymous usage patterns are shared with Hotjar to improve the product. This is optional.</p>
		<div class="row"><button class="small" onclick={declineAnalytics}>No thanks</button><button class="small primary" onclick={enableAnalytics}>Allow analytics</button></div>
	</aside>
{/if}

<style>
	.privacy-card { position: fixed; right: 20px; bottom: 20px; z-index: 20; max-width: 360px; padding: 16px; border: 1px solid var(--line); border-radius: 14px; background: var(--panel); box-shadow: 0 12px 36px rgba(16, 23, 42, .18); }
	.privacy-card p { color: var(--muted); font-size: 12px; margin: 6px 0 12px; }
</style>
