<script lang="ts">
	import { label, tone as statusTone } from '$lib/format';
	import type { Snippet } from 'svelte';

	let {
		status,
		text,
		tone,
		children
	}: {
		status?: string;
		text?: string;
		tone?: string;
		children?: Snippet;
	} = $props();

	const displayText = $derived(
		text ?? (status ? label(status) : undefined)
	);

	const pillTone = $derived(
		tone ?? (status ? statusTone(status) : 'gray')
	);
</script>

<span class="pill {pillTone}">
	{#if children}
		{@render children()}
	{:else}
		{displayText}
	{/if}
</span>