<script lang="ts">
	let {
		label,
		value,
		foot,
		accent = ''
	}: { label: string; value: string | number; foot?: string; accent?: string } = $props();
</script>

<div class="panel stat">
	<div class="label">{label}</div>
	<div class="value" style={accent ? `color:${accent}` : ''}>{value}</div>
	{#if foot}<div class="foot">{foot}</div>{/if}
</div>
