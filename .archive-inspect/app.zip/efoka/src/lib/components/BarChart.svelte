<script lang="ts">
	import { money } from '$lib/format';

	let {
		series,
		height = 180
	}: { series: { day: string; orders: number; delivered: number; revenue: number }[]; height?: number } = $props();

	const max = $derived(Math.max(1, ...series.map((p) => p.orders)));
</script>

<div class="chart" style="height:{height}px">
	{#each series as point (point.day)}
		<div class="col" title="{point.day}: {point.orders} orders · {money(point.revenue)} delivered revenue">
			<div class="stack-bars">
				<div class="bar total" style="height:{(point.orders / max) * 100}%">
					<div class="bar delivered" style="height:{point.orders ? (point.delivered / point.orders) * 100 : 0}%"></div>
				</div>
			</div>
			<span class="tick">{point.day.split(' ')[1]}</span>
		</div>
	{/each}
</div>
<div class="legend tiny muted">
	<span><i class="sw total"></i> orders</span>
	<span><i class="sw delivered"></i> delivered</span>
</div>

<style>
	.chart {
		display: flex;
		align-items: flex-end;
		gap: 6px;
	}

	.col {
		flex: 1;
		display: flex;
		flex-direction: column;
		align-items: center;
		height: 100%;
		gap: 6px;
	}

	.stack-bars {
		flex: 1;
		width: 100%;
		display: flex;
		align-items: flex-end;
	}

	.bar {
		width: 100%;
		border-radius: 6px 6px 0 0;
		display: flex;
		align-items: flex-end;
	}

	.bar.total {
		background: #dbe4fb;
	}

	.bar.delivered {
		width: 100%;
		background: var(--brand);
		border-radius: 6px 6px 0 0;
	}

	.tick {
		font-size: 10.5px;
		color: var(--muted);
	}

	.legend {
		display: flex;
		gap: 14px;
		margin-top: 10px;
	}

	.sw {
		display: inline-block;
		width: 9px;
		height: 9px;
		border-radius: 3px;
		margin-right: 5px;
	}

	.sw.total {
		background: #dbe4fb;
	}

	.sw.delivered {
		background: var(--brand);
	}
</style>
