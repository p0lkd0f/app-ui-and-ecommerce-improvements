export const CURRENCY = 'MAD';

export function money(value: number | string | null | undefined, compact = false): string {
	const n = Number(value ?? 0);
	if (compact && Math.abs(n) >= 1000) return `${(n / 1000).toFixed(1)}k ${CURRENCY}`;
	return `${n.toLocaleString('en-US', { maximumFractionDigits: 0 })} ${CURRENCY}`;
}

export function date(value: string | Date | null | undefined): string {
	if (!value) return '—';
	return new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' });
}

export function dateTime(value: string | Date | null | undefined): string {
	if (!value) return '—';
	return new Date(value).toLocaleString('en-GB', {
		day: '2-digit',
		month: 'short',
		hour: '2-digit',
		minute: '2-digit'
	});
}

export function timeAgo(value: string | Date | null | undefined): string {
	if (!value) return '—';
	const diff = Date.now() - new Date(value).getTime();
	const minutes = Math.round(diff / 60000);
	if (minutes < 1) return 'just now';
	if (minutes < 60) return `${minutes}m ago`;
	const hours = Math.round(minutes / 60);
	if (hours < 24) return `${hours}h ago`;
	return `${Math.round(hours / 24)}d ago`;
}

export function initials(name: string): string {
	return name
		.split(' ')
		.slice(0, 2)
		.map((part) => part[0]?.toUpperCase() ?? '')
		.join('');
}

const TONES: Record<string, string> = {
	new: 'blue',
	pending: 'amber',
	scheduled: 'violet',
	confirmed: 'green',
	packed: 'violet',
	shipped: 'blue',
	in_transit: 'blue',
	picked_up: 'blue',
	label_created: 'grey',
	out_for_delivery: 'violet',
	delivered: 'green',
	cancelled: 'red',
	unreachable: 'amber',
	returned: 'red',
	failed: 'red',
	requested: 'amber',
	received: 'blue',
	restocked: 'green',
	refused: 'red',
	open: 'green',
	closed: 'grey',
	connected: 'green',
	disconnected: 'grey',
	error: 'red',
	cod: 'amber',
	prepaid: 'green',
	instagram: 'violet',
	sms: 'blue'
};

export function tone(status: string): string {
	return TONES[status] ?? 'grey';
}

export function label(status: string): string {
	return status.replace(/_/g, ' ');
}
