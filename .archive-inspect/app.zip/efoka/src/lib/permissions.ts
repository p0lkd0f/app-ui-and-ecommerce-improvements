import type { Role } from './types';

export const PERMISSIONS = [
	'orders.view',
	'orders.edit',
	'confirmation.handle',
	'whatsapp.reply',
	'shipping.manage',
	'inventory.manage',
	'analytics.view',
	'team.manage',
	'integrations.manage',
	'campaigns.view',
	'campaigns.manage'
] as const;

export type Permission = (typeof PERMISSIONS)[number];

const MATRIX: Record<Role, Permission[]> = {
	owner: [...PERMISSIONS],
	manager: [
		'orders.view',
		'orders.edit',
		'confirmation.handle',
		'whatsapp.reply',
		'shipping.manage',
		'inventory.manage',
		'analytics.view',
		'campaigns.view',
		'campaigns.manage'
	],
	agent: ['orders.view', 'confirmation.handle', 'whatsapp.reply'],
	packer: ['orders.view', 'shipping.manage', 'inventory.manage']
};

export function permissionsFor(role: Role): Permission[] {
	return MATRIX[role] ?? [];
}

export function can(role: Role, permission: Permission): boolean {
	return permissionsFor(role).includes(permission);
}

export const ROLE_LABELS: Record<Role, string> = {
	owner: 'Owner',
	manager: 'Manager',
	agent: 'Call agent',
	packer: 'Fulfilment'
};
