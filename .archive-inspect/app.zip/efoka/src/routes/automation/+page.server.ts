import { fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { listAutomations, toggleAutomation } from '$lib/server/repo';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
	const [automations, runs] = await Promise.all([
		listAutomations(),
		query<{ id: number; name: string; result: string; created_at: string; reference: string | null }>(
			`SELECT r.id, a.name, r.result, r.created_at, o.reference
			 FROM automation_runs r JOIN automations a ON a.id = r.automation_id
			 LEFT JOIN orders o ON o.id = r.order_id ORDER BY r.created_at DESC LIMIT 10`
		)
	]);
	return { automations, runs };
};

export const actions: Actions = {
	toggle: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await toggleAutomation(Number(form.get('id')), form.get('enabled') === 'true');
		return { success: 'Automation updated' };
	},
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const name = String(form.get('name') ?? '').trim();
		if (!name) return fail(400, { error: 'Name is required' });
		await query('INSERT INTO automations (name, description, trigger, action) VALUES ($1,$2,$3,$4)', [
			name,
			String(form.get('description') ?? ''),
			String(form.get('trigger')),
			String(form.get('action'))
		]);
		return { success: `${name} created` };
	}
};
