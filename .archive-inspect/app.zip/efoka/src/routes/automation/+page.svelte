<script lang="ts">
	import { dateTime } from '$lib/format';

	let { data, form } = $props();

	const TRIGGERS = ['order.created', 'call.no_answer', 'order.confirmed', 'order.shipped', 'order.delivered', 'return.requested'];
	const ACTIONS = ['order.confirm', 'order.hold', 'order.tag_risky', 'whatsapp.send_template', 'shipping.create_label', 'team.notify'];
</script>

{#if form?.success}<div class="notice">{form.success}</div>{/if}
{#if form?.error}<div class="error">{form.error}</div>{/if}

<div class="grid cols-3">
	<div class="panel" style="grid-column: span 2">
		<div class="panel-head"><h2>Automation rules</h2><span class="hint">when a trigger fires, the action runs automatically</span></div>
		<table>
			<thead><tr><th>Rule</th><th>Trigger</th><th>Action</th><th class="num">Runs</th><th>State</th></tr></thead>
			<tbody>
				{#each data.automations as rule (rule.id)}
					<tr>
						<td>
							<div style="font-weight:550">{rule.name}</div>
							<div class="muted tiny">{rule.description}</div>
						</td>
						<td><span class="pill grey mono">{rule.trigger}</span></td>
						<td><span class="pill blue mono">{rule.action}</span></td>
						<td class="num">{rule.runs}</td>
						<td>
							<form method="POST" action="?/toggle">
								<input type="hidden" name="id" value={rule.id} />
								<input type="hidden" name="enabled" value={(!rule.enabled).toString()} />
								<button class="small" class:success={!rule.enabled}>
									{rule.enabled ? 'Disable' : 'Enable'}
								</button>
							</form>
							<span class="pill {rule.enabled ? 'green' : 'grey'}" style="margin-top:4px">{rule.enabled ? 'active' : 'paused'}</span>
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>

	<div class="stack">
		<div class="panel">
			<div class="panel-head"><h2>New rule</h2></div>
			<div class="panel-body">
				<form method="POST" action="?/create" class="stack">
					<div class="field"><label for="name">Name</label><input id="name" name="name" required /></div>
					<div class="field"><label for="description">Description</label><input id="description" name="description" /></div>
					<div class="field">
						<label for="trigger">When</label>
						<select id="trigger" name="trigger">{#each TRIGGERS as trigger (trigger)}<option>{trigger}</option>{/each}</select>
					</div>
					<div class="field">
						<label for="action">Then</label>
						<select id="action" name="action">{#each ACTIONS as action (action)}<option>{action}</option>{/each}</select>
					</div>
					<button class="primary">Create rule</button>
				</form>
			</div>
		</div>

		<div class="panel">
			<div class="panel-head"><h2>Recent runs</h2></div>
			<div class="panel-body stack tiny">
				{#each data.runs as run (run.id)}
					<div class="spread">
						<span>{run.name} {run.reference ?? ''}</span>
						<span class="muted">{dateTime(run.created_at)}</span>
					</div>
				{:else}
					<span class="muted">No runs recorded in this environment yet.</span>
				{/each}
			</div>
		</div>
	</div>
</div>
