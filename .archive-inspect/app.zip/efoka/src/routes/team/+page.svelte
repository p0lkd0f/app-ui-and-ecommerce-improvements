<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Checkbox,
		Input,
		Label,
		Select,
		Table,
		TableBody,
		TableBodyCell,
		TableBodyRow,
		TableHead,
		TableHeadCell
	} from 'flowbite-svelte';

	import { date } from '$lib/format';
	import { PERMISSIONS, ROLE_LABELS, can } from '$lib/permissions';
	import type { Role } from '$lib/types';

	let { data, form } = $props();

	const ROLES: Role[] = ['owner', 'manager', 'agent', 'packer'];

	let search = $state('');
	let roleFilter = $state('all');
	let statusFilter = $state('all');
	let showPassword = $state(false);

	let filteredUsers = $derived(
		data.users.filter((member: any) => {
			const term = search.trim().toLowerCase();

			const matchesSearch =
				!term ||
				String(member.name ?? '').toLowerCase().includes(term) ||
				String(member.email ?? '').toLowerCase().includes(term);

			const matchesRole =
				roleFilter === 'all' || member.role === roleFilter;

			const matchesStatus =
				statusFilter === 'all' ||
				(statusFilter === 'active' && member.active) ||
				(statusFilter === 'suspended' && !member.active);

			return matchesSearch && matchesRole && matchesStatus;
		})
	);

	let activeMembers = $derived(
		data.users.filter((member: any) => member.active).length
	);

	let suspendedMembers = $derived(
		data.users.filter((member: any) => !member.active).length
	);

	let totalHandled = $derived(
		data.users.reduce(
			(total: number, member: any) =>
				total + Number(member.handled ?? 0),
			0
		)
	);

	let roleCounts = $derived(
		ROLES.map((role) => ({
			role,
			count: data.users.filter((member: any) => member.role === role)
				.length
		}))
	);

	function initials(name: string) {
		return String(name ?? '')
			.trim()
			.split(/\s+/)
			.slice(0, 2)
			.map((part) => part[0]?.toUpperCase() ?? '')
			.join('');
	}

	function roleColor(role: Role) {
		switch (role) {
			case 'owner':
				return 'purple';
			case 'manager':
				return 'blue';
			case 'agent':
				return 'green';
			case 'packer':
				return 'yellow';
			default:
				return 'gray';
		}
	}

	function resetFilters() {
		search = '';
		roleFilter = 'all';
		statusFilter = 'all';
	}
</script>

<svelte:head>
	<title>Team · Efoka</title>
	<meta
		name="description"
		content="Manage Efoka workspace members, roles and permissions."
	/>
</svelte:head>

<!-- Header -->
<div class="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-start">
	<div>
		<div class="mb-2 flex items-center gap-2">
			<Badge color="blue">Workspace</Badge>

			<Badge color="gray">
				{data.users.length} members
			</Badge>
		</div>

		<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
			Team
		</h1>

		<p class="mt-2 max-w-2xl text-sm leading-6 text-gray-500 dark:text-gray-400">
			Manage your team, assign roles and control workspace access.
		</p>
	</div>

	<div class="flex flex-wrap gap-2">
		<Badge color="green">
			{activeMembers} active
		</Badge>

		{#if suspendedMembers > 0}
			<Badge color="red">
				{suspendedMembers} suspended
			</Badge>
		{/if}
	</div>
</div>

<!-- Feedback -->
{#if form?.success}
	<div
		class="mb-6 rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-300"
	>
		{form.success}
	</div>
{/if}

{#if form?.error}
	<div
		class="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-300"
	>
		{form.error}
	</div>
{/if}

<!-- Overview -->
<div class="mb-6 grid gap-4 md:grid-cols-3">
	<Card>
		<div class="flex items-start justify-between">
			<div>
				<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Team members
				</div>

				<div class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{data.users.length}
				</div>
			</div>

			<Badge color="blue">Total</Badge>
		</div>

		<div class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			{activeMembers} active · {suspendedMembers} suspended
		</div>
	</Card>

	<Card>
		<div class="flex items-start justify-between">
			<div>
				<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Active members
				</div>

				<div class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{activeMembers}
				</div>
			</div>

			<Badge color="green">Active</Badge>
		</div>

		<div class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			People currently allowed to access the workspace
		</div>
	</Card>

	<Card>
		<div class="flex items-start justify-between">
			<div>
				<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Calls handled
				</div>

				<div class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{totalHandled.toLocaleString()}
				</div>
			</div>

			<Badge color="gray">Team total</Badge>
		</div>

		<div class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			Recorded handled calls across team members
		</div>
	</Card>
</div>

<!-- Main workspace -->
<div class="grid gap-6 xl:grid-cols-12">
	<!-- Members -->
	<div class="xl:col-span-8">
		<Card>
			<div class="mb-5">
				<div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
					<div>
						<h2 class="text-lg font-bold text-gray-900 dark:text-white">
							Team members
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Search and manage access for every workspace member.
						</p>
					</div>

					<Button
						size="sm"
						color="alternative"
						onclick={resetFilters}
					>
						Reset filters
					</Button>
				</div>

				<!-- Filters -->
				<div class="mt-5 grid gap-3 md:grid-cols-[1fr_180px_180px]">
					<div>
						<Label for="member-search" class="sr-only">
							Search members
						</Label>

						<Input
							id="member-search"
							bind:value={search}
							placeholder="Search name or email..."
						/>
					</div>

					<Select bind:value={roleFilter}>
						<option value="all">All roles</option>

						{#each ROLES as role (role)}
							<option value={role}>
								{ROLE_LABELS[role]}
							</option>
						{/each}
					</Select>

					<Select bind:value={statusFilter}>
						<option value="all">All statuses</option>
						<option value="active">Active</option>
						<option value="suspended">Suspended</option>
					</Select>
				</div>
			</div>

			{#if filteredUsers.length > 0}
				<div class="overflow-x-auto">
					<Table hoverable={true}>
						<TableHead>
							<TableHeadCell>Member</TableHeadCell>
							<TableHeadCell>Role</TableHeadCell>
							<TableHeadCell>Activity</TableHeadCell>
							<TableHeadCell>Joined</TableHeadCell>
							<TableHeadCell>Access</TableHeadCell>
						</TableHead>

						<TableBody>
							{#each filteredUsers as member (member.id)}
								<TableBodyRow>
									<TableBodyCell>
										<div class="flex items-center gap-3">
											<div
												class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary-100 text-sm font-bold text-primary-700 dark:bg-primary-900/40 dark:text-primary-300"
											>
												{initials(member.name)}
											</div>

											<div class="min-w-0">
												<div class="truncate font-semibold text-gray-900 dark:text-white">
													{member.name}
												</div>

												<div class="truncate text-xs text-gray-500 dark:text-gray-400">
													{member.email}
												</div>
											</div>
										</div>
									</TableBodyCell>

									<TableBodyCell>
										<form
											method="POST"
											action="?/role"
											class="flex items-center gap-2"
										>
											<input
												type="hidden"
												name="id"
												value={member.id}
											/>

											<Select
												name="role"
												class="min-w-[130px]"
											>
												{#each ROLES as role (role)}
													<option
														value={role}
														selected={role === member.role}
													>
														{ROLE_LABELS[role]}
													</option>
												{/each}
											</Select>

											<Button size="xs" color="alternative">
												Save
											</Button>
										</form>
									</TableBodyCell>

									<TableBodyCell>
										<div class="font-semibold text-gray-900 dark:text-white">
											{Number(member.handled ?? 0).toLocaleString()}
										</div>

										<div class="text-xs text-gray-500 dark:text-gray-400">
											calls handled
										</div>
									</TableBodyCell>

									<TableBodyCell>
										<span class="text-xs text-gray-500 dark:text-gray-400">
											{date(member.created_at)}
										</span>
									</TableBodyCell>

									<TableBodyCell>
										<form method="POST" action="?/toggle">
											<input
												type="hidden"
												name="id"
												value={member.id}
											/>

											<input
												type="hidden"
												name="active"
												value={(!member.active).toString()}
											/>

											{#if member.active}
												<Button size="xs" color="red">
													Suspend
												</Button>
											{:else}
												<Button size="xs" color="green">
													Reactivate
												</Button>
											{/if}
										</form>
									</TableBodyCell>
								</TableBodyRow>
							{/each}
						</TableBody>
					</Table>
				</div>
			{:else}
				<div class="rounded-xl border border-dashed border-gray-300 p-10 text-center dark:border-gray-700">
					<div class="text-3xl">⌕</div>

					<h3 class="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
						No members found
					</h3>

					<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
						Try changing the search or filters.
					</p>
				</div>
			{/if}
		</Card>
	</div>

	<!-- Invite -->
	<div class="xl:col-span-4">
		<Card>
			<div class="mb-5">
				<div class="flex items-center justify-between gap-3">
					<div>
						<h2 class="text-lg font-bold text-gray-900 dark:text-white">
							Add member
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Create a new workspace account.
						</p>
					</div>

					<Badge color="blue">
						New
					</Badge>
				</div>
			</div>

			<form method="POST" action="?/invite" class="space-y-5">
				<div>
					<Label for="name" class="mb-2 block">
						Full name
					</Label>

					<Input
						id="name"
						name="name"
						placeholder="John Smith"
						required
						autocomplete="name"
					/>
				</div>

				<div>
					<Label for="email" class="mb-2 block">
						Work email
					</Label>

					<Input
						id="email"
						name="email"
						type="email"
						placeholder="john@example.com"
						required
						autocomplete="email"
					/>
				</div>

				<div>
					<Label for="new-role" class="mb-2 block">
						Role
					</Label>

					<Select id="new-role" name="role">
						{#each ROLES as role (role)}
							<option value={role}>
								{ROLE_LABELS[role]}
							</option>
						{/each}
					</Select>
				</div>

				<div>
					<Label for="password" class="mb-2 block">
						Temporary password
					</Label>

					<div class="relative">
						<Input
							id="password"
							name="password"
							type={showPassword ? 'text' : 'password'}
							minlength={12}
							autocomplete="new-password"
							placeholder="Minimum 12 characters"
							required
						/>

						<button
							type="button"
							class="absolute right-2 top-1/2 -translate-y-1/2 rounded px-2 py-1 text-xs font-medium text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-700 dark:hover:text-white"
							onclick={() => (showPassword = !showPassword)}
						>
							{showPassword ? 'Hide' : 'Show'}
						</button>
					</div>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						Use at least 12 characters.
					</p>
				</div>

				<Button type="submit" color="primary" class="w-full">
					Add team member
				</Button>
			</form>
		</Card>

		<!-- Role summary -->
		<Card class="mt-6">
			<div class="mb-4">
				<h2 class="text-base font-bold text-gray-900 dark:text-white">
					Role distribution
				</h2>

				<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
					Current workspace members by role.
				</p>
			</div>

			<div class="space-y-3">
				{#each roleCounts as item (item.role)}
					<div class="flex items-center justify-between">
						<div class="flex items-center gap-2">
							<Badge color={roleColor(item.role)}>
								{ROLE_LABELS[item.role]}
							</Badge>
						</div>

						<span class="text-sm font-semibold text-gray-900 dark:text-white">
							{item.count}
						</span>
					</div>
				{/each}
			</div>
		</Card>
	</div>
</div>

<!-- Permissions -->
<Card class="mt-6">
	<div class="mb-5 flex flex-col justify-between gap-3 lg:flex-row lg:items-start">
		<div>
			<h2 class="text-lg font-bold text-gray-900 dark:text-white">
				Permission matrix
			</h2>

			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				Review exactly what each role can do in the workspace.
			</p>
		</div>

		<Badge color="gray">
			{PERMISSIONS.length} permissions
		</Badge>
	</div>

	<div class="overflow-x-auto">
		<Table hoverable={true}>
			<TableHead>
				<TableHeadCell>
					Permission
				</TableHeadCell>

				{#each ROLES as role (role)}
					<TableHeadCell class="text-center">
						{ROLE_LABELS[role]}
					</TableHeadCell>
				{/each}
			</TableHead>

			<TableBody>
				{#each PERMISSIONS as permission (permission)}
					<TableBodyRow>
						<TableBodyCell>
							<span class="font-mono text-xs text-gray-700 dark:text-gray-300">
								{permission}
							</span>
						</TableBodyCell>

						{#each ROLES as role (role)}
							<TableBodyCell class="text-center">
								{#if can(role, permission)}
									<span
										class="inline-flex items-center justify-center rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-800 dark:bg-green-900/30 dark:text-green-300"
									>
										✓ Allowed
									</span>
								{:else}
									<span
										class="inline-flex items-center justify-center rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-500 dark:bg-gray-800 dark:text-gray-400"
									>
										— No access
									</span>
								{/if}
							</TableBodyCell>
						{/each}
					</TableBodyRow>
				{/each}
			</TableBody>
		</Table>
	</div>
</Card>

<!-- Security note -->
<div class="mt-6 rounded-xl border border-blue-200 bg-blue-50 p-4 dark:border-blue-900 dark:bg-blue-900/20">
	<div class="flex gap-3">
		<div class="text-lg text-blue-600 dark:text-blue-400">
			ⓘ
		</div>

		<div>
			<div class="text-sm font-semibold text-blue-900 dark:text-blue-200">
				Access management
			</div>

			<p class="mt-1 text-xs leading-5 text-blue-700 dark:text-blue-300">
				Role changes and account suspension are submitted directly to the
				server actions. The permission matrix is derived from your existing
				<code>PERMISSIONS</code>, <code>ROLE_LABELS</code> and
				<code>can()</code> definitions.
			</p>
		</div>
	</div>
</div>