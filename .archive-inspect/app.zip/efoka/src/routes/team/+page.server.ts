import { error, fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { hashPassword } from '$lib/server/password';
import { listUsers, setUserActive, setUserRole } from '$lib/server/repo';
import { oneOf, positiveId, requiredText, ROLES, workEmail } from '$lib/server/validation';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user || !can(locals.user.role, 'team.manage')) throw error(403, 'Only owners can manage the team');
	return { users: await listUsers() };
};

export const actions: Actions = {
	invite: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'team.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		try {
			const name = requiredText(form.get('name'), 'Name', 100);
			const email = workEmail(form.get('email'));
			const password = requiredText(form.get('password'), 'Temporary password', 128);
			if (password.length < 12) return fail(400, { error: 'Use a temporary password with at least 12 characters' });
			const role = oneOf(form.get('role'), ROLES, 'role');
			const result = await query<{ id: number }>(
				'INSERT INTO users (name, email, password_hash, role) VALUES ($1,$2,$3,$4) ON CONFLICT (email) DO NOTHING RETURNING id',
				[name, email, hashPassword(password), role]
			);
			if (!result.length) return fail(409, { error: 'A member already uses that email address' });
			return { success: `${name} was added to the workspace` };
		} catch (err) {
			return fail(400, { error: err instanceof Error ? err.message : 'Could not add member' });
		}
	},
	role: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'team.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('id'));
		const role = oneOf(form.get('role'), ROLES, 'role');
		if (id === locals.user.id && role !== 'owner') return fail(400, { error: 'You cannot remove your own owner access' });
		const target = await query<{ role: string; active: boolean }>('SELECT role, active FROM users WHERE id = $1', [id]);
		if (!target.length) return fail(404, { error: 'Member not found' });
		if (target[0].role === 'owner' && target[0].active && role !== 'owner') {
			const owners = await query<{ count: number }>("SELECT count(*)::int AS count FROM users WHERE role = 'owner' AND active = true");
			if ((owners[0]?.count ?? 0) <= 1) return fail(400, { error: 'Keep at least one active owner in the workspace' });
		}
		await setUserRole(id, role);
		return { success: 'Role updated' };
	},
	toggle: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'team.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('id'));
		if (id === locals.user.id && form.get('active') !== 'true') return fail(400, { error: 'You cannot suspend your own account' });
		const target = await query<{ role: string; active: boolean }>('SELECT role, active FROM users WHERE id = $1', [id]);
		if (!target.length) return fail(404, { error: 'Member not found' });
		if (target[0].role === 'owner' && target[0].active && form.get('active') !== 'true') {
			const owners = await query<{ count: number }>("SELECT count(*)::int AS count FROM users WHERE role = 'owner' AND active = true");
			if ((owners[0]?.count ?? 0) <= 1) return fail(400, { error: 'Keep at least one active owner in the workspace' });
		}
		await setUserActive(id, form.get('active') === 'true');
		return { success: 'Access updated' };
	}
};
