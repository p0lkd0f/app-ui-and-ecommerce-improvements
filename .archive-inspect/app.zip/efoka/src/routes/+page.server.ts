import { confirmationQueue, dashboardSummary, listOrders } from '$lib/server/repo';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
	const [summary, latest, queue] = await Promise.all([
		dashboardSummary(),
		listOrders({ limit: 8 }),
		confirmationQueue()
	]);
	return { summary, latest, queue: queue.slice(0, 6) };
};
