import { redirect, type RequestHandler } from '@sveltejs/kit';
import { beginGoogleAuth, STATE_COOKIE } from '$lib/server/google';

export const GET: RequestHandler = ({ cookies, url }) => {
	const { state, url: googleUrl } = beginGoogleAuth(url.origin);
	cookies.set(STATE_COOKIE, state, { path: '/auth/google', httpOnly: true, sameSite: 'lax', secure: url.protocol === 'https:', maxAge: 600 });
	throw redirect(302, googleUrl);
};
