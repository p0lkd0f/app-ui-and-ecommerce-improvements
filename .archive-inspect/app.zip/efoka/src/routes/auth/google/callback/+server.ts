import { redirect, type RequestHandler } from '@sveltejs/kit';
import { createSession, SESSION_COOKIE } from '$lib/server/session';
import { STATE_COOKIE, stateMatches, workspaceGoogleUser } from '$lib/server/google';

export const GET: RequestHandler = async ({ cookies, url }) => {
	const state = cookies.get(STATE_COOKIE);
	cookies.delete(STATE_COOKIE, { path: '/auth/google' });
	if (!stateMatches(state, url.searchParams.get('state'))) throw redirect(303, '/login?error=google_state');
	const code = url.searchParams.get('code');
	if (!code) throw redirect(303, '/login?error=google_failed');
	const user = await workspaceGoogleUser(code, url.origin);
	const session = await createSession(user);
	cookies.set(SESSION_COOKIE, session, { path: '/', httpOnly: true, sameSite: 'lax', secure: url.protocol === 'https:', maxAge: 60 * 60 * 8 });
	throw redirect(303, '/');
};
