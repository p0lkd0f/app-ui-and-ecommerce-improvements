<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Input,
		Table,
		TableBody,
		TableBodyCell,
		TableBodyRow,
		TableHead,
		TableHeadCell
	} from 'flowbite-svelte';

	import Pill from '$lib/components/Pill.svelte';
	import { date } from '$lib/format';

	let { data, form } = $props();

	let search = $state('');
	let channel = $state('all');
	let status = $state('all');

	let filteredTemplates = $derived(
		data.templates.filter((template: any) => {
			const term = search.trim().toLowerCase();

			const matchesSearch =
				!term ||
				template.name.toLowerCase().includes(term) ||
				template.category.toLowerCase().includes(term) ||
				template.body.toLowerCase().includes(term);

			const matchesChannel =
				channel === 'all' ||
				template.channel === channel;

			const matchesStatus =
				status === 'all' ||
				(status === 'active'
					? template.active
					: !template.active);

			return matchesSearch && matchesChannel && matchesStatus;
		})
	);

	function clearFilters() {
		search = '';
		channel = 'all';
		status = 'all';
	}
</script>

<svelte:head>
	<title>Automation · Efoka</title>
	<meta
		name="description"
		content="Manage messaging automation resources and approved templates."
	/>
</svelte:head>

<div class="mb-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
	<div>
		<div class="mb-2 flex items-center gap-2">
			<Badge color="purple">Automation</Badge>
			<Badge color="gray">Messaging</Badge>
		</div>

		<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
			Automation
		</h1>

		<p class="mt-2 max-w-2xl text-sm leading-6 text-gray-500 dark:text-gray-400">
			Manage the approved messaging resources used by your customer
			communication workflows.
		</p>
	</div>

	<Button href="/templates" color="primary">
		Manage templates
	</Button>
</div>

{#if form?.success}
	<div
		class="mb-5 rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-300"
	>
		{form.success}
	</div>
{/if}

{#if form?.error}
	<div
		class="mb-5 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-300"
	>
		{form.error}
	</div>
{/if}

<!-- Real database statistics -->
<div class="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
	<Card>
		<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
			Total templates
		</div>

		<div class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
			{data.stats.total}
		</div>

		<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
			Stored messaging templates
		</div>
	</Card>

	<Card>
		<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
			Active templates
		</div>

		<div class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
			{data.stats.active}
		</div>

		<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
			Available to active workflows
		</div>
	</Card>

	<Card>
		<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
			WhatsApp
		</div>

		<div class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
			{data.stats.whatsapp}
		</div>

		<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
			WhatsApp templates
		</div>
	</Card>

	<Card>
		<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
			Other channels
		</div>

		<div class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
			{data.stats.instagram + data.stats.sms}
		</div>

		<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
			Instagram + SMS
		</div>
	</Card>
</div>

<!-- Automation status -->
<Card class="mb-5">
	<div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
		<div>
			<div class="flex items-center gap-2">
				<div
					class="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300"
				>
					⚡
				</div>

				<div>
					<h2 class="font-bold text-gray-900 dark:text-white">
						Messaging automation
					</h2>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						Your template library is connected and available to
						the messaging workflow.
					</p>
				</div>
			</div>
		</div>

		<Badge color={data.stats.active > 0 ? 'green' : 'gray'}>
			{data.stats.active > 0 ? 'Ready' : 'No active templates'}
		</Badge>
	</div>
</Card>

<!-- Template library -->
<Card class="!p-0 overflow-hidden">
	<div
		class="flex flex-col gap-4 border-b border-gray-200 p-5 dark:border-gray-700 lg:flex-row lg:items-end lg:justify-between"
	>
		<div>
			<h2 class="text-lg font-bold text-gray-900 dark:text-white">
				Template library
			</h2>

			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				Approved messages available to your communication workflows.
			</p>
		</div>

		<div class="flex flex-col gap-2 sm:flex-row">
			<Input
				type="search"
				bind:value={search}
				placeholder="Search templates..."
				class="w-full sm:w-64"
			/>

			<select
				bind:value={channel}
				class="rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
			>
				<option value="all">All channels</option>
				<option value="whatsapp">WhatsApp</option>
				<option value="instagram">Instagram</option>
				<option value="sms">SMS</option>
			</select>

			<select
				bind:value={status}
				class="rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
			>
				<option value="all">All status</option>
				<option value="active">Active</option>
				<option value="inactive">Inactive</option>
			</select>

			<Button
				size="sm"
				color="alternative"
				onclick={clearFilters}
			>
				Clear
			</Button>
		</div>
	</div>

	<div class="overflow-x-auto">
		<Table hoverable>
			<TableHead>
				<TableHeadCell>Template</TableHeadCell>
				<TableHeadCell>Channel</TableHeadCell>
				<TableHeadCell>Category</TableHeadCell>
				<TableHeadCell>Message</TableHeadCell>
				<TableHeadCell>Created</TableHeadCell>
				<TableHeadCell>Status</TableHeadCell>
				<TableHeadCell class="text-right">Action</TableHeadCell>
			</TableHead>

			<TableBody>
				{#each filteredTemplates as template (template.id)}
					<TableBodyRow>
						<TableBodyCell>
							<div class="font-semibold text-gray-900 dark:text-white">
								{template.name}
							</div>

							<div class="mt-1 font-mono text-[10px] text-gray-400">
								#{template.id}
							</div>
						</TableBodyCell>

						<TableBodyCell>
							<Pill status={template.channel} />
						</TableBodyCell>

						<TableBodyCell>
							<Badge color="gray">
								{template.category}
							</Badge>
						</TableBodyCell>

						<TableBodyCell>
							<div class="max-w-xl">
								<p
									class="line-clamp-2 whitespace-pre-wrap text-sm text-gray-600 dark:text-gray-300"
								>
									{template.body}
								</p>
							</div>
						</TableBodyCell>

						<TableBodyCell>
							<span class="whitespace-nowrap text-xs text-gray-500 dark:text-gray-400">
								{date(template.created_at)}
							</span>
						</TableBodyCell>

						<TableBodyCell>
							{#if template.active}
								<Badge color="green">Active</Badge>
							{:else}
								<Badge color="gray">Inactive</Badge>
							{/if}
						</TableBodyCell>

						<TableBodyCell class="text-right">
							<form
								method="POST"
								action="?/remove"
								onsubmit={(event) => {
									if (
										!confirm(
											`Remove "${template.name}"?`
										)
									) {
										event.preventDefault();
									}
								}}
							>
								<input
									type="hidden"
									name="id"
									value={template.id}
								/>

								<Button
									type="submit"
									size="xs"
									color="red"
								>
									Remove
								</Button>
							</form>
						</TableBodyCell>
					</TableBodyRow>
				{:else}
					<TableBodyRow>
						<TableBodyCell colspan={7}>
							<div class="px-6 py-14 text-center">
								<div
									class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400"
								>
									⌕
								</div>

								<h3 class="mt-4 text-sm font-semibold text-gray-900 dark:text-white">
									No templates found
								</h3>

								<p class="mx-auto mt-1 max-w-sm text-xs leading-5 text-gray-500 dark:text-gray-400">
									No stored templates match the current
									search and filters.
								</p>

								<Button
									class="mt-4"
									size="sm"
									color="alternative"
									onclick={clearFilters}
								>
									Clear filters
								</Button>
							</div>
						</TableBodyCell>
					</TableBodyRow>
				{/each}
			</TableBody>
		</Table>
	</div>

	<div
		class="flex items-center justify-between border-t border-gray-200 px-5 py-3 dark:border-gray-700"
	>
		<span class="text-xs text-gray-500 dark:text-gray-400">
			Showing {filteredTemplates.length} of {data.templates.length}
		</span>

		<a
			href="/templates"
			class="text-sm font-medium text-primary-600 hover:underline dark:text-primary-500"
		>
			Manage templates →
		</a>
	</div>
</Card>

<!-- Automation roadmap, without pretending features exist -->
<div class="mt-5 grid gap-4 md:grid-cols-3">
	<Card>
		<div class="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
			1
		</div>

		<h3 class="font-semibold text-gray-900 dark:text-white">
			Trigger
		</h3>

		<p class="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">
			Connect a real business event such as an order status change,
			delivery update, or customer message.
		</p>
	</Card>

	<Card>
		<div class="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
			2
		</div>

		<h3 class="font-semibold text-gray-900 dark:text-white">
			Template
		</h3>

		<p class="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">
			Use one of the active templates from the shared message
			template library.
		</p>
	</Card>

	<Card>
		<div class="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
			3
		</div>

		<h3 class="font-semibold text-gray-900 dark:text-white">
			Action
		</h3>

		<p class="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">
			Execute a server-side workflow and record its result instead of
			simulating the action in the browser.
		</p>
	</Card>
</div>