import { error, fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user || !can(locals.user.role, 'whatsapp.reply')) {
		throw error(403, 'Not allowed');
	}

	const [templates, templateStats] = await Promise.all([
		query<{
			id: number;
			name: string;
			channel: string;
			body: string;
			category: string;
			active: boolean;
			created_at: string;
		}>(
			`SELECT
				id,
				name,
				channel,
				body,
				category,
				active,
				created_at
			FROM message_templates
			ORDER BY active DESC, category, name`
		),

		query<{
			total: number;
			active: number;
			whatsapp: number;
			instagram: number;
			sms: number;
		}>(
			`SELECT
				count(*)::int AS total,
				count(*) FILTER (WHERE active)::int AS active,
				count(*) FILTER (WHERE channel = 'whatsapp')::int AS whatsapp,
				count(*) FILTER (WHERE channel = 'instagram')::int AS instagram,
				count(*) FILTER (WHERE channel = 'sms')::int AS sms
			FROM message_templates`
		)
	]);

	return {
		user: locals.user,
		templates,
		stats: templateStats[0] ?? {
			total: 0,
			active: 0,
			whatsapp: 0,
			instagram: 0,
			sms: 0
		}
	};
};

export const actions: Actions = {
	remove: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'whatsapp.reply')) {
			return fail(403, { error: 'Not allowed' });
		}

		const form = await request.formData();
		const id = Number(form.get('id'));

		if (!Number.isInteger(id) || id <= 0) {
			return fail(400, { error: 'Invalid template ID' });
		}

		await query(
			'DELETE FROM message_templates WHERE id = $1',
			[id]
		);

		return {
			success: 'Template removed'
		};
	}
};