import { fail, redirect } from '@sveltejs/kit';
import { createHash } from 'node:crypto';
import { cacheDelete, cacheGet, cacheIncrement } from '$lib/server/cache';
import { createSession, login, SESSION_COOKIE } from '$lib/server/session';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
	const reason = url.searchParams.get('error');
	return { authError: reason === 'google_state' ? 'Google sign-in expired. Please try again.' : reason === 'google_failed' ? 'Google sign-in was not completed. Please try again.' : null };
};

export const actions: Actions = {
	default: async ({ request, cookies, url, getClientAddress }) => {
		const form = await request.formData();
		const email = String(form.get('email') ?? '').trim().toLowerCase().slice(0, 254);
		const password = String(form.get('password') ?? '');
		const fingerprint = createHash('sha256').update(`${getClientAddress()}|${email}`).digest('hex');
		const rateKey = `login:${fingerprint}`;
		if (Number(await cacheGet(rateKey) ?? '0') >= 10) return fail(429, { email, error: 'Too many attempts. Try again in 15 minutes.' });

		const user = await login(email, password);
		if (!user) {
			const failures = await cacheIncrement(rateKey, 15 * 60);
			if (failures > 10) return fail(429, { email, error: 'Too many attempts. Try again in 15 minutes.' });
			return fail(401, { email, error: 'Wrong email or password.' });
		}
		await cacheDelete(rateKey);

		const token = await createSession(user);
		cookies.set(SESSION_COOKIE, token, {
			path: '/', httpOnly: true, sameSite: 'lax', secure: url.protocol === 'https:', maxAge: 60 * 60 * 8
		});
		const redirectTo = url.searchParams.get('redirectTo');
		throw redirect(303, redirectTo?.startsWith('/') && !redirectTo.startsWith('//') ? redirectTo : '/');
	}
};
