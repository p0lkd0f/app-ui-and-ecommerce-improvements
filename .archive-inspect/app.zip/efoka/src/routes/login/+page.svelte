<script lang="ts">
	import { Card, Button, Input, Label, Checkbox } from 'flowbite-svelte';

	let { form, data } = $props();

	let email = $state('');
	let password = $state('');
	let showPassword = $state(false);
	let isLoading = $state(false);
	let rememberMe = $state(false);

	async function handleSubmit() {
		isLoading = true;
		// Form submission handled by server action
	}
</script>

<svelte:head>
	<title>Sign in | Efoka.ma</title>
	<meta
		name="description"
		content="Sign in to Efoka.ma to manage your e-commerce operations."
	/>
</svelte:head>

<div class="login-page">
	<div class="login-container">

		<!-- Brand -->
		<div class="brand-header">
			<div class="brand-mark">
				<span>🚀</span>
			</div>

			<div>
				<div class="brand-name">Efoka.ma</div>
				<div class="brand-tagline">Commerce Operations</div>
			</div>
		</div>

		<!-- Main card -->
		<Card class="login-card">

			<div class="login-heading">
				<h1>Welcome back</h1>
				<p>
					Sign in to continue managing your commerce operations.
				</p>
			</div>

			<!-- Errors -->
			{#if form?.error}
				<div class="error-message" role="alert">
					<div class="error-icon">!</div>
					<div>{form.error}</div>
				</div>
			{/if}

			{#if data?.authError}
				<div class="error-message" role="alert">
					<div class="error-icon">!</div>
					<div>{data.authError}</div>
				</div>
			{/if}

			<form method="POST" onsubmit={handleSubmit} class="login-form">

				<!-- Email -->
				<div class="form-group">
					<Label for="email" class="form-label">
						Email address
					</Label>

					<div class="input-wrapper">
						<div class="input-icon">
							<svg
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="1.8"
								aria-hidden="true"
							>
								<path
									d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
								/>
								<path d="m22 6-10 7L2 6" />
							</svg>
						</div>

						<Input
							id="email"
							name="email"
							type="email"
							bind:value={email}
							placeholder="you@company.com"
							required
							class="modern-input"
						/>
					</div>
				</div>

				<!-- Password -->
				<div class="form-group">
					<div class="password-label-row">
						<Label for="password" class="form-label">
							Password
						</Label>

						<a href="/forgot-password" class="forgot-link">
							Forgot password?
						</a>
					</div>

					<div class="input-wrapper">
						<div class="input-icon">
							<svg
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="1.8"
								aria-hidden="true"
							>
								<rect x="3" y="11" width="18" height="10" rx="2" />
								<path d="M7 11V7a5 5 0 0 1 10 0v4" />
							</svg>
						</div>

						<Input
							id="password"
							name="password"
							type={showPassword ? 'text' : 'password'}
							bind:value={password}
							placeholder="Enter your password"
							required
							class="modern-input password-input"
						/>

						<button
							type="button"
							class="password-toggle"
							onclick={() => (showPassword = !showPassword)}
							aria-label={showPassword ? 'Hide password' : 'Show password'}
						>
							{#if showPassword}
								<svg
									viewBox="0 0 24 24"
									fill="none"
									stroke="currentColor"
									stroke-width="1.8"
									aria-hidden="true"
								>
									<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z" />
									<circle cx="12" cy="12" r="2.5" />
								</svg>
							{:else}
								<svg
									viewBox="0 0 24 24"
									fill="none"
									stroke="currentColor"
									stroke-width="1.8"
									aria-hidden="true"
								>
									<path d="M3 3l18 18" />
									<path d="M10.6 10.6a2 2 0 0 0 2.8 2.8" />
									<path d="M9.9 4.2A10.8 10.8 0 0 1 12 4c6.5 0 10 6 10 6a18 18 0 0 1-3.1 3.8" />
									<path d="M6.2 6.2C3.5 8 2 10 2 10s3.5 6 10 6c1.1 0 2.1-.2 3-.5" />
								</svg>
							{/if}
						</button>
					</div>
				</div>

				<!-- Remember -->
				<div class="form-options">
					<Checkbox bind:checked={rememberMe}>
						<span class="remember-text">Remember me</span>
					</Checkbox>
				</div>

				<!-- Submit -->
				<Button
					type="submit"
					class="login-button"
					disabled={isLoading}
					loading={isLoading}
				>
					{isLoading ? 'Signing in...' : 'Sign in'}
				</Button>
			</form>

			<!-- Divider -->
			<div class="divider">
				<span>OR CONTINUE WITH</span>
			</div>

			<!-- Social login -->
			<div class="social-grid">

				<a href="/auth/google" class="social-button">
					<span class="google-icon">G</span>
					<span>Google</span>
				</a>

				<a href="/auth/meta" class="social-button">
					<span class="meta-icon">M</span>
					<span>Meta</span>
				</a>

			</div>

			<!-- Signup -->
			<div class="signup">
				<span>New to Efoka.ma?</span>
				<a href="/signup">Create account</a>
			</div>

		</Card>

		<!-- Footer -->
		<div class="security-note">
			<svg
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="1.8"
				aria-hidden="true"
			>
				<path d="M12 3 5 6v5c0 4.8 2.9 8.7 7 10 4.1-1.3 7-5.2 7-10V6l-7-3z" />
				<path d="m9 12 2 2 4-4" />
			</svg>

			<span>Your connection is secure</span>
		</div>

	</div>
</div>

<style>
	:global(body) {
		margin: 0;
		background:
			radial-gradient(
				circle at 50% 0%,
				rgba(99, 102, 241, 0.12),
				transparent 38%
			),
			#f8fafc;
	}

	.login-page {
		min-height: 100vh;
		display: flex;
		align-items: center;
		justify-content: center;
		padding: 40px 20px;
		box-sizing: border-box;
	}

	.login-container {
		width: 100%;
		max-width: 440px;
	}

	.brand-header {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 12px;
		margin-bottom: 24px;
	}

	.brand-mark {
		width: 48px;
		height: 48px;
		display: grid;
		place-items: center;
		border-radius: 14px;
		background: linear-gradient(
			135deg,
			#4f46e5,
			#7c3aed
		);
		box-shadow:
			0 10px 25px rgba(79, 70, 229, 0.25),
			0 3px 8px rgba(79, 70, 229, 0.15);
	}

	.brand-mark span {
		font-size: 24px;
		line-height: 1;
	}

	.brand-name {
		font-size: 22px;
		font-weight: 800;
		letter-spacing: -0.03em;
		color: #312e81;
	}

	.brand-tagline {
		margin-top: 2px;
		font-size: 11px;
		font-weight: 500;
		color: #64748b;
		letter-spacing: 0.02em;
	}

	:global(.login-card) {
		width: 100%;
		box-sizing: border-box;
		border: 1px solid #e2e8f0;
		border-radius: 20px;
		background: rgba(255, 255, 255, 0.98);
		box-shadow:
			0 25px 50px -12px rgba(15, 23, 42, 0.12),
			0 8px 20px rgba(15, 23, 42, 0.04);
	}

	.login-heading {
		text-align: center;
		margin-bottom: 28px;
	}

	.login-heading h1 {
		margin: 0;
		font-size: 27px;
		line-height: 1.2;
		font-weight: 750;
		letter-spacing: -0.035em;
		color: #0f172a;
	}

	.login-heading p {
		margin: 9px auto 0;
		max-width: 330px;
		font-size: 14px;
		line-height: 1.6;
		color: #64748b;
	}

	.error-message {
		display: flex;
		align-items: center;
		gap: 10px;
		margin-bottom: 20px;
		padding: 12px 14px;
		border: 1px solid #fecaca;
		border-radius: 10px;
		background: #fef2f2;
		color: #b91c1c;
		font-size: 13px;
	}

	.error-icon {
		width: 20px;
		height: 20px;
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 50%;
		background: #dc2626;
		color: white;
		font-size: 12px;
		font-weight: 800;
	}

	.login-form {
		display: flex;
		flex-direction: column;
		gap: 20px;
	}

	.form-group {
		width: 100%;
	}

	:global(.form-label) {
		display: block;
		margin-bottom: 8px;
		font-size: 13px;
		font-weight: 600;
		color: #334155;
	}

	.password-label-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		margin-bottom: 8px;
	}

	.password-label-row :global(.form-label) {
		margin-bottom: 0;
	}

	.forgot-link {
		font-size: 12px;
		font-weight: 600;
		color: #4f46e5;
		text-decoration: none;
		white-space: nowrap;
	}

	.forgot-link:hover {
		color: #4338ca;
		text-decoration: underline;
	}

	.input-wrapper {
		position: relative;
	}

	.input-icon {
		position: absolute;
		z-index: 2;
		left: 13px;
		top: 50%;
		transform: translateY(-50%);
		width: 18px;
		height: 18px;
		color: #94a3b8;
		pointer-events: none;
	}

	.input-icon svg {
		width: 100%;
		height: 100%;
	}

	:global(.modern-input input) {
		height: 46px;
		padding-left: 42px !important;
		padding-right: 42px !important;
		border-radius: 10px !important;
		border-color: #dbe2ea !important;
		background: #fff !important;
		font-size: 14px !important;
		color: #0f172a !important;
		box-shadow: none !important;
	}

	:global(.modern-input input::placeholder) {
		color: #94a3b8;
	}

	:global(.modern-input input:focus) {
		border-color: #6366f1 !important;
		box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.12) !important;
	}

	.password-toggle {
		position: absolute;
		z-index: 3;
		right: 10px;
		top: 50%;
		transform: translateY(-50%);
		width: 30px;
		height: 30px;
		display: grid;
		place-items: center;
		border: 0;
		border-radius: 7px;
		background: transparent;
		color: #94a3b8;
		cursor: pointer;
	}

	.password-toggle:hover {
		background: #f1f5f9;
		color: #475569;
	}

	.password-toggle svg {
		width: 17px;
		height: 17px;
	}

	.form-options {
		display: flex;
		align-items: center;
		margin-top: -4px;
	}

	.remember-text {
		font-size: 13px;
		color: #475569;
	}

	:global(.login-button) {
		width: 100% !important;
		height: 46px !important;
		border: 0 !important;
		border-radius: 10px !important;
		background: linear-gradient(
			135deg,
			#4f46e5,
			#7c3aed
		) !important;
		box-shadow:
			0 8px 18px rgba(79, 70, 229, 0.22),
			0 3px 8px rgba(124, 58, 237, 0.12);
		font-size: 14px !important;
		font-weight: 700 !important;
		transition:
			transform 0.15s ease,
			box-shadow 0.15s ease;
	}

	:global(.login-button:hover:not(:disabled)) {
		transform: translateY(-1px);
		box-shadow:
			0 12px 24px rgba(79, 70, 229, 0.28),
			0 4px 10px rgba(124, 58, 237, 0.16);
	}

	:global(.login-button:active:not(:disabled)) {
		transform: translateY(0);
	}

	.divider {
		display: flex;
		align-items: center;
		gap: 14px;
		margin: 27px 0 20px;
		color: #94a3b8;
		font-size: 10px;
		font-weight: 600;
		letter-spacing: 0.08em;
	}

	.divider::before,
	.divider::after {
		content: '';
		height: 1px;
		flex: 1;
		background: #e2e8f0;
	}

	.social-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 12px;
	}

	.social-button {
		height: 44px;
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 9px;
		border: 1px solid #dbe2ea;
		border-radius: 10px;
		background: #fff;
		color: #334155;
		font-size: 13px;
		font-weight: 600;
		text-decoration: none;
		transition:
			background 0.15s ease,
			border-color 0.15s ease,
			transform 0.15s ease;
	}

	.social-button:hover {
		background: #f8fafc;
		border-color: #cbd5e1;
		transform: translateY(-1px);
	}

	.google-icon,
	.meta-icon {
		font-size: 18px;
		font-weight: 800;
	}

	.google-icon {
		color: #4285f4;
	}

	.meta-icon {
		color: #0866ff;
	}

	.signup {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 5px;
		margin-top: 25px;
		font-size: 13px;
		color: #64748b;
	}

	.signup a {
		color: #4f46e5;
		font-weight: 700;
		text-decoration: none;
	}

	.signup a:hover {
		text-decoration: underline;
	}

	.security-note {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 6px;
		margin-top: 18px;
		color: #94a3b8;
		font-size: 11px;
	}

	.security-note svg {
		width: 14px;
		height: 14px;
	}

	@media (max-width: 480px) {
		.login-page {
			padding: 24px 14px;
			align-items: flex-start;
		}

		.login-container {
			margin-top: 20px;
		}

		.brand-header {
			margin-bottom: 20px;
		}

		:global(.login-card) {
			border-radius: 16px;
		}

		.login-heading h1 {
			font-size: 24px;
		}

		.social-grid {
			grid-template-columns: 1fr;
		}
	}
</style>