<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { timeAgo } from '$lib/format';

	let { data } = $props();

	type ChatMessage = {
		role: 'user' | 'assistant';
		content: string;
		timestamp: Date;
	};

	type Conversation = {
		id: number;
		customer: string;
		phone: string;
		orderId: string;
		status: 'active' | 'waiting';
		messageCount: number;
		lastActivity: Date;
	};

	let chatMessages = $state<ChatMessage[]>([
		{
			role: 'assistant',
			content:
				"Hello! I'm your AI assistant for Efoka.ma. I can help you with order inquiries, product information, delivery tracking, and more. How can I assist you today?",
			timestamp: new Date()
		}
	]);

	let currentMessage = $state('');
	let isTyping = $state(false);
	let selectedOrder = $state<string | null>(null);
	let selectedCustomer = $state<string | null>(null);

	let aiSettings = $state({
		model: 'gpt-4-turbo-preview',
		temperature: 0.7,
		maxTokens: 500,
		autoResponse: true,
		sentimentAnalysis: true,
		confidenceThreshold: 0.6
	});

	let performanceMetrics = $state({
		totalConversations: 1247,
		avgResponseTime: '2.3s',
		satisfactionRate: '94%',
		resolutionRate: '89%',
		escalationRate: '11%',
		sentimentScore: 4.2
	});

	let recentConversations = $state([
		{
			id: 1,
			customer: 'Amine T.',
			summary: 'Order status inquiry - resolved',
			sentiment: 'positive',
			duration: '3m 45s',
			timestamp: new Date(Date.now() - 1800000)
		},
		{
			id: 2,
			customer: 'Fatima M.',
			summary: 'Product question - recommended similar items',
			sentiment: 'positive',
			duration: '5m 12s',
			timestamp: new Date(Date.now() - 3600000)
		},
		{
			id: 3,
			customer: 'Karim L.',
			summary: 'Delivery delay complaint - escalated',
			sentiment: 'negative',
			duration: '8m 30s',
			timestamp: new Date(Date.now() - 7200000)
		}
	]);

	let activeConversations = $state<Conversation[]>([
		{
			id: 101,
			customer: 'Youssef B.',
			phone: '+212 661 234 567',
			orderId: 'EFK-789',
			status: 'active',
			messageCount: 5,
			lastActivity: new Date()
		},
		{
			id: 102,
			customer: 'Sara K.',
			phone: '+212 662 345 678',
			orderId: 'EFK-790',
			status: 'waiting',
			messageCount: 2,
			lastActivity: new Date(Date.now() - 300000)
		}
	]);

	async function sendMessage() {
		const message = currentMessage.trim();

		if (!message || isTyping) {
			return;
		}

		currentMessage = '';
		isTyping = true;

		chatMessages = [
			...chatMessages,
			{
				role: 'user',
				content: message,
				timestamp: new Date()
			}
		];

		// Demo response. Replace with your API call when the backend is ready.
		await new Promise((resolve) => setTimeout(resolve, 1500));

		chatMessages = [
			...chatMessages,
			{
				role: 'assistant',
				content: generateMockResponse(message),
				timestamp: new Date()
			}
		];

		isTyping = false;
	}

	function generateMockResponse(userMessage: string): string {
		const lowerMessage = userMessage.toLowerCase();

		if (lowerMessage.includes('order') && lowerMessage.includes('status')) {
			return 'I can help you check your order status. Could you please provide your order ID or the phone number associated with your order?';
		}

		if (
			lowerMessage.includes('delivery') ||
			lowerMessage.includes('shipping')
		) {
			return "For delivery inquiries, I can track your package in real-time. Please share your tracking number or order ID, and I'll provide you with the current delivery status and estimated arrival time.";
		}

		if (
			lowerMessage.includes('return') ||
			lowerMessage.includes('exchange')
		) {
			return "I'd be happy to help you with returns or exchanges. Our policy allows returns within 14 days of delivery. Could you tell me which order you'd like to return and the reason?";
		}

		if (
			lowerMessage.includes('product') ||
			lowerMessage.includes('recommend')
		) {
			return "Based on our current inventory and trending items, I'd recommend checking out our new collection. Would you like me to suggest specific products based on your preferences?";
		}

		if (lowerMessage.includes('cancel')) {
			return "I can help you cancel your order. Please note that orders can only be cancelled before they've been shipped. Could you provide your order ID so I can check the current status?";
		}

		return "Thank you for your message. I'm here to help with any questions about your orders, products, deliveries, or account. Could you please provide more details about what you need assistance with?";
	}

	function selectConversation(conversation: Conversation) {
		selectedCustomer = conversation.customer;
		selectedOrder = conversation.orderId;
	}

	function clearChat() {
		chatMessages = [
			{
				role: 'assistant',
				content: 'Chat cleared. How can I help you today?',
				timestamp: new Date()
			}
		];

		selectedCustomer = null;
		selectedOrder = null;
	}

	function useQuickMessage(message: string) {
		currentMessage = message;
	}

	function saveAISettings() {
		console.log('AI settings saved', aiSettings);
	}
</script>

<div class="grid cols-3">
	<div
		class="panel chat-panel"
		style="grid-column: span 2;"
	>
		<div class="panel-head">
			<div>
				<h2>AI Agent Chat</h2>

				<div class="row">
					<span class="status-dot online" aria-hidden="true"></span>
					<span class="tiny muted">Online</span>
				</div>
			</div>

			<div class="row">
				{#if selectedOrder}
					<span class="pill blue">Order: {selectedOrder}</span>
				{/if}

				{#if selectedCustomer}
					<span class="pill green">{selectedCustomer}</span>
				{/if}

				<button
					class="small"
					type="button"
					onclick={clearChat}
				>
					Clear Chat
				</button>
			</div>
		</div>

		<div class="panel-body chat-body">
			<div
				class="chat-messages"
				aria-live="polite"
				aria-label="AI conversation"
			>
				{#each chatMessages as message (message.timestamp.getTime())}
					<div
						class="message {message.role}"
						style:align-self={message.role === 'user'
							? 'flex-end'
							: 'flex-start'}
					>
						<div class="message-content">
							<p>{message.content}</p>

							<span class="message-time tiny muted">
								{timeAgo(message.timestamp)}
							</span>
						</div>
					</div>
				{/each}

				{#if isTyping}
					<div
						class="message assistant"
						style="align-self:flex-start;"
						aria-label="AI is typing"
					>
						<div class="message-content typing">
							<div class="typing-indicator" aria-hidden="true">
								<span></span>
								<span></span>
								<span></span>
							</div>
						</div>
					</div>
				{/if}
			</div>

			<div class="chat-input">
				<div class="row">
					<label class="sr-only" for="ai-message">
						Message
					</label>

					<input
						id="ai-message"
						type="text"
						bind:value={currentMessage}
						placeholder="Type your message..."
						autocomplete="off"
						disabled={isTyping}
						onkeydown={(event) => {
							if (event.key === 'Enter') {
								sendMessage();
							}
						}}
						style="flex:1;"
					/>

					<button
						class="primary"
						type="button"
						onclick={sendMessage}
						disabled={!currentMessage.trim() || isTyping}
					>
						{isTyping ? '...' : 'Send'}
					</button>
				</div>

				<div class="row quick-actions">
					<button
						class="small"
						type="button"
						onclick={() =>
							useQuickMessage('What is my order status?')}
					>
						Order Status
					</button>

					<button
						class="small"
						type="button"
						onclick={() => useQuickMessage('Track my delivery')}
					>
						Track Delivery
					</button>

					<button
						class="small"
						type="button"
						onclick={() =>
							useQuickMessage('I want to return an item')}
					>
						Returns
					</button>

					<button
						class="small"
						type="button"
						onclick={() => useQuickMessage('Recommend products')}
					>
						Recommendations
					</button>
				</div>
			</div>
		</div>
	</div>

	<div class="panel conversation-panel">
		<div class="panel-head">
			<h2>Active Conversations</h2>
			<span class="pill gradient">
				{activeConversations.length} Active
			</span>
		</div>

		<div class="panel-body conversation-list">
			{#each activeConversations as conversation (conversation.id)}
				<button
					class="conversation-item"
					type="button"
					onclick={() => selectConversation(conversation)}
				>
					<div class="spread">
						<strong>{conversation.customer}</strong>

						<span
							class="pill {conversation.status === 'active'
								? 'green'
								: 'amber'}"
						>
							{conversation.status}
						</span>
					</div>

					<div class="tiny muted conversation-phone">
						{conversation.phone}
					</div>

					<div class="spread conversation-meta">
						<span class="tiny">
							Order: {conversation.orderId}
						</span>

						<span class="tiny muted">
							{conversation.messageCount} messages
						</span>
					</div>

					<div class="tiny muted conversation-last">
						Last active:
						{timeAgo(conversation.lastActivity)}
					</div>
				</button>
			{/each}
		</div>
	</div>
</div>

<div class="grid cols-4" style="margin-top:18px;">
	<div class="panel stat">
		<div class="panel-body">
			<div class="label">Total Conversations</div>
			<div class="value">
				{performanceMetrics.totalConversations}
			</div>
			<div class="foot">This month</div>
		</div>
	</div>

	<div class="panel stat">
		<div class="panel-body">
			<div class="label">Avg Response Time</div>
			<div class="value">
				{performanceMetrics.avgResponseTime}
			</div>
			<div class="foot strong">↓ 15% from last month</div>
		</div>
	</div>

	<div class="panel stat">
		<div class="panel-body">
			<div class="label">Satisfaction Rate</div>
			<div class="value">
				{performanceMetrics.satisfactionRate}
			</div>
			<div class="foot strong">↑ 3% from last month</div>
		</div>
	</div>

	<div class="panel stat">
		<div class="panel-body">
			<div class="label">Resolution Rate</div>
			<div class="value">
				{performanceMetrics.resolutionRate}
			</div>
			<div class="foot">AI-only resolutions</div>
		</div>
	</div>
</div>

<div class="grid cols-2" style="margin-top:18px;">
	<div class="panel">
		<div class="panel-head">
			<h2>Recent Conversations</h2>
			<a class="hint" href="/analytics">View all →</a>
		</div>

		<div class="panel-body">
			<table>
				<thead>
					<tr>
						<th>Customer</th>
						<th>Summary</th>
						<th>Sentiment</th>
						<th>Duration</th>
					</tr>
				</thead>

				<tbody>
					{#each recentConversations as conversation (conversation.id)}
						<tr>
							<td>{conversation.customer}</td>
							<td>{conversation.summary}</td>
							<td>
								<Pill status={conversation.sentiment} />
							</td>
							<td>{conversation.duration}</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>
	</div>

	<div class="panel">
		<div class="panel-head">
			<h2>AI Configuration</h2>

			<button
				class="small"
				type="button"
				onclick={saveAISettings}
			>
				Save Settings
			</button>
		</div>

		<div class="panel-body stack">
			<div class="field">
				<label for="ai-model">AI Model</label>

				<select id="ai-model" bind:value={aiSettings.model}>
					<option value="gpt-4-turbo-preview">
						GPT-4 Turbo (Recommended)
					</option>
					<option value="gpt-4">GPT-4</option>
					<option value="gpt-3.5-turbo">
						GPT-3.5 Turbo
					</option>
				</select>
			</div>

			<div class="field">
				<label for="temperature">
					Temperature: {aiSettings.temperature}
				</label>

				<input
					id="temperature"
					type="range"
					min="0"
					max="1"
					step="0.1"
					bind:value={aiSettings.temperature}
				/>
			</div>

			<div class="field">
				<label for="max-tokens">
					Max Tokens: {aiSettings.maxTokens}
				</label>

				<input
					id="max-tokens"
					type="number"
					min="100"
					max="1000"
					step="50"
					bind:value={aiSettings.maxTokens}
				/>
			</div>

			<div class="checkbox-row">
				<input
					type="checkbox"
					id="auto-response"
					bind:checked={aiSettings.autoResponse}
				/>

				<label for="auto-response">
					Auto-response enabled
				</label>
			</div>

			<div class="checkbox-row">
				<input
					type="checkbox"
					id="sentiment-analysis"
					bind:checked={aiSettings.sentimentAnalysis}
				/>

				<label for="sentiment-analysis">
					Sentiment analysis
				</label>
			</div>

			<div class="field">
				<label for="confidence-threshold">
					Confidence Threshold:
					{aiSettings.confidenceThreshold}
				</label>

				<input
					id="confidence-threshold"
					type="range"
					min="0"
					max="1"
					step="0.1"
					bind:value={aiSettings.confidenceThreshold}
				/>
			</div>
		</div>
	</div>
</div>

<style>
	.chat-panel,
	.conversation-panel {
		display: flex;
		flex-direction: column;
		height: 600px;
	}

	.chat-body {
		flex: 1;
		display: flex;
		flex-direction: column;
		overflow: hidden;
		padding: 0;
	}

	.chat-messages {
		flex: 1;
		overflow-y: auto;
		padding: 16px;
		display: flex;
		flex-direction: column;
		gap: 12px;
		scroll-behavior: smooth;
	}

	.message {
		max-width: 80%;
		animation: fade-in 0.3s ease-in-out;
	}

	.message.user {
		align-self: flex-end;
	}

	.message.assistant {
		align-self: flex-start;
	}

	.message.user .message-content {
		background: linear-gradient(
			135deg,
			var(--gradient-start),
			var(--gradient-end)
		);
		color: white;
		border-radius: 18px 18px 4px 18px;
		padding: 12px 16px;
	}

	.message.assistant .message-content {
		background: var(--panel);
		border: 1px solid var(--line);
		border-radius: 18px 18px 18px 4px;
		padding: 12px 16px;
	}

	.message-content p {
		margin: 0 0 4px;
		line-height: 1.4;
	}

	.message-time {
		font-size: 10px;
		opacity: 0.8;
	}

	.typing-indicator {
		display: flex;
		gap: 4px;
		padding: 4px 0;
	}

	.typing-indicator span {
		width: 8px;
		height: 8px;
		background: var(--muted);
		border-radius: 50%;
		animation: typing 1.4s infinite ease-in-out;
	}

	.typing-indicator span:nth-child(2) {
		animation-delay: 0.2s;
	}

	.typing-indicator span:nth-child(3) {
		animation-delay: 0.4s;
	}

	.chat-input {
		padding: 16px;
		border-top: 1px solid var(--line);
	}

	.quick-actions {
		margin-top: 8px;
		gap: 8px;
		flex-wrap: wrap;
	}

	.conversation-list {
		flex: 1;
		overflow-y: auto;
	}

	.conversation-item {
		width: 100%;
		padding: 12px;
		margin-bottom: 10px;
		border: 1px solid var(--line);
		border-radius: 10px;
		background: var(--panel);
		color: var(--ink);
		text-align: left;
		cursor: pointer;
		transition:
			background 0.2s ease,
			border-color 0.2s ease,
			transform 0.2s ease;
	}

	.conversation-item:hover,
	.conversation-item:focus-visible {
		border-color: var(--brand);
		background: var(--brand-soft);
		transform: translateY(-1px);
		outline: none;
	}

	.conversation-phone {
		margin-top: 4px;
	}

	.conversation-meta {
		margin-top: 8px;
	}

	.conversation-last {
		margin-top: 4px;
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.field label {
		font-size: 12px;
		color: var(--muted);
		font-weight: 550;
	}

	.checkbox-row {
		display: flex;
		align-items: center;
		gap: 8px;
	}

	.checkbox-row label {
		cursor: pointer;
	}

	.sr-only {
		position: absolute;
		width: 1px;
		height: 1px;
		padding: 0;
		margin: -1px;
		overflow: hidden;
		clip: rect(0, 0, 0, 0);
		white-space: nowrap;
		border: 0;
	}

	@keyframes fade-in {
		from {
			opacity: 0;
			transform: translateY(4px);
		}

		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	@keyframes typing {
		0%,
		60%,
		100% {
			transform: translateY(0);
		}

		30% {
			transform: translateY(-8px);
		}
	}
</style>