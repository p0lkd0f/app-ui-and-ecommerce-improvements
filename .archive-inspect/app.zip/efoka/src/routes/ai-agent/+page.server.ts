import { redirect } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user) {
		throw redirect(302, '/login');
	}

	// Check if user has permission to access AI features
	// This would be implemented based on your permission system

	return {
		user: locals.user,
		// Additional data can be loaded here from your database
	};
};
