import { fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { adjustStock, listProducts } from '$lib/server/repo';
import { positiveId, requiredText } from '$lib/server/validation';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
	const [products, movements] = await Promise.all([
		listProducts(),
		query<{ id: number; name: string; delta: number; reason: string; created_at: string; actor: string | null }>(
			`SELECT m.id, p.name, m.delta, m.reason, m.created_at, u.name AS actor
			 FROM stock_movements m JOIN products p ON p.id = m.product_id LEFT JOIN users u ON u.id = m.actor_id
			 ORDER BY m.created_at DESC LIMIT 12`
		)
	]);
	return { products, movements };
};

export const actions: Actions = {
	adjust: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'inventory.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const delta = Number(form.get('delta'));
		if (!Number.isInteger(delta) || delta === 0 || Math.abs(delta) > 100000) return fail(400, { error: 'Enter a whole, non-zero adjustment' });
		const reason = typeof form.get('reason') === 'string' && String(form.get('reason')).trim()
			? requiredText(form.get('reason'), 'Reason', 160) : 'manual adjustment';
		await adjustStock(positiveId(form.get('productId')), delta, reason, locals.user.id);
		return { success: 'Stock updated' };
	},
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'inventory.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		try {
			const sku = requiredText(form.get('sku'), 'SKU', 64).toUpperCase();
			const name = requiredText(form.get('name'), 'Product name', 160);
			const category = requiredText(form.get('category'), 'Category', 64);
			const price = Number(form.get('price'));
			const cost = Number(form.get('cost'));
			const stock = Number(form.get('stock'));
			if (![price, cost, stock].every(Number.isFinite) || price < 0 || cost < 0 || !Number.isInteger(stock) || stock < 0) return fail(400, { error: 'Price and cost must be non-negative; stock must be a whole number' });
			const inserted = await query<{ id: number }>(
				'INSERT INTO products (sku, name, category, price, cost, stock) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (sku) DO NOTHING RETURNING id',
				[sku, name, category, price, cost, stock]
			);
			if (!inserted.length) return fail(409, { error: 'A product already uses that SKU' });
			return { success: `${name} added` };
		} catch (err) { return fail(400, { error: err instanceof Error ? err.message : 'Could not add product' }); }
	}
};
