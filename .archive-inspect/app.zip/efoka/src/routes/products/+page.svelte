<script lang="ts">
	import Stat from '$lib/components/Stat.svelte';
	import Pill from '$lib/components/Pill.svelte';
	import { dateTime, money } from '$lib/format';

	let { data, form } = $props();

	const stockValue = $derived(
		data.products.reduce((sum, product) => sum + product.stock * product.cost, 0)
	);

	const lowStock = $derived(
		data.products.filter((product) => product.stock > 0 && product.stock <= product.low_stock)
	);

	const outOfStock = $derived(
		data.products.filter((product) => product.stock === 0)
	);

	const totalUnits = $derived(
		data.products.reduce((sum, product) => sum + product.stock, 0)
	);

	const totalSold = $derived(
		data.products.reduce((sum, product) => sum + product.units_sold, 0)
	);

	const averageMargin = $derived(
		data.products.length
			? Math.round(
					data.products.reduce((sum, product) => {
						if (!product.price) return sum;
						return sum + ((product.price - product.cost) / product.price) * 100;
					}, 0) / data.products.filter((product) => product.price > 0).length || 0
				)
			: 0
	);

	function margin(product: { price: number; cost: number }) {
		if (!product.price) return 0;
		return Math.round(((product.price - product.cost) / product.price) * 100);
	}

	function stockState(product: { stock: number; low_stock: number }) {
		if (product.stock === 0) return 'out';
		if (product.stock <= product.low_stock) return 'low';
		return 'healthy';
	}

	function stockLabel(product: { stock: number; low_stock: number }) {
		if (product.stock === 0) return 'Out of stock';
		if (product.stock <= product.low_stock) return 'Low stock';
		return 'Healthy';
	}
</script>

<svelte:head>
	<title>Products · Inventory</title>
	<meta
		name="description"
		content="Manage products, inventory levels, pricing and stock movements."
	/>
</svelte:head>

{#if form?.success}
	<div class="notice" role="status">
		{form.success}
	</div>
{/if}

{#if form?.error}
	<div class="error" role="alert">
		{form.error}
	</div>
{/if}

<!-- Page header -->
<div class="page-header">
	<div>
		<div class="eyebrow">Inventory</div>
		<h1>Products</h1>
		<p class="muted">
			Manage your catalog, monitor stock and record inventory movements.
		</p>
	</div>

	<a href="#add-product" class="btn primary">
		<span aria-hidden="true">+</span>
		Add product
	</a>
</div>

<!-- Overview -->
<div class="grid cols-3">
	<Stat
		label="Active SKUs"
		value={data.products.length}
		foot={`${totalUnits} units currently in stock`}
	/>

	<Stat
		label="Stock value"
		value={money(stockValue)}
		foot="Inventory value at cost"
	/>

	<Stat
		label="Low stock"
		value={lowStock.length}
		foot={lowStock.length
			? lowStock.map((product) => product.sku).slice(0, 3).join(', ')
			: 'All stock levels healthy'}
	/>
</div>

<!-- Secondary metrics -->
<div class="metric-strip">
	<div class="metric">
		<span class="metric-label">Out of stock</span>
		<strong class:red={outOfStock.length > 0}>{outOfStock.length}</strong>
	</div>

	<div class="metric">
		<span class="metric-label">Units sold</span>
		<strong>{totalSold}</strong>
	</div>

	<div class="metric">
		<span class="metric-label">Average margin</span>
		<strong>{averageMargin}%</strong>
	</div>

	<div class="metric">
		<span class="metric-label">Products</span>
		<strong>{data.products.length}</strong>
	</div>
</div>

<!-- Inventory -->
<section class="panel inventory-panel">
	<div class="panel-head inventory-head">
		<div>
			<h2>Inventory</h2>
			<p class="hint">
				Adjust stock after supplier deliveries, returns or physical counts.
			</p>
		</div>

		<div class="inventory-summary">
			{#if outOfStock.length}
				<Pill tone="red">{outOfStock.length} out</Pill>
			{/if}

			{#if lowStock.length}
				<Pill tone="amber">{lowStock.length} low</Pill>
			{/if}

			{#if !outOfStock.length && !lowStock.length}
				<Pill tone="green">Stock healthy</Pill>
			{/if}
		</div>
	</div>

	<div class="table-wrap">
		<table>
			<thead>
				<tr>
					<th>SKU</th>
					<th>Product</th>
					<th>Category</th>
					<th class="num">Price</th>
					<th class="num">Cost</th>
					<th class="num">Margin</th>
					<th class="num">Stock</th>
					<th class="num">Sold</th>
					<th>Adjust stock</th>
				</tr>
			</thead>

			<tbody>
				{#each data.products as product (product.id)}
					<tr>
						<!-- SKU -->
						<td>
							<span class="mono sku">{product.sku}</span>
						</td>

						<!-- Product -->
						<td>
							<div class="product-name">{product.name}</div>
						</td>

						<!-- Category -->
						<td>
							<span class="muted">{product.category}</span>
						</td>

						<!-- Price -->
						<td class="num">
							{money(product.price)}
						</td>

						<!-- Cost -->
						<td class="num">
							{money(product.cost)}
						</td>

						<!-- Margin -->
						<td class="num">
							<span class:negative={margin(product) < 0}>
								{margin(product)}%
							</span>
						</td>

						<!-- Stock -->
						<td class="num">
							<div class="stock-cell">
								<strong>{product.stock}</strong>

								<Pill
									tone={stockState(product) === 'out'
										? 'red'
										: stockState(product) === 'low'
											? 'amber'
											: 'green'}
								>
									{stockLabel(product)}
								</Pill>
							</div>
						</td>

						<!-- Sold -->
						<td class="num">
							{product.units_sold}
						</td>

						<!-- Adjustment -->
						<td>
							<form method="POST" action="?/adjust" class="adjust-form">
								<input
									type="hidden"
									name="productId"
									value={product.id}
								/>

								<div class="adjust-input">
									<label for={`delta-${product.id}`}>
										Stock change
									</label>

									<input
										id={`delta-${product.id}`}
										name="delta"
										type="number"
										value="10"
										step="1"
										required
									/>
								</div>

								<div class="adjust-input reason-input">
									<label for={`reason-${product.id}`}>
										Reason
									</label>

									<input
										id={`reason-${product.id}`}
										name="reason"
										placeholder="Delivery, count..."
										required
									/>
								</div>

								<button class="small primary" type="submit">
									Apply
								</button>
							</form>
						</td>
					</tr>
				{:else}
					<tr>
						<td colspan="9">
							<div class="empty-state">
								<div class="empty-icon" aria-hidden="true">📦</div>
								<strong>No products yet</strong>
								<p class="muted">
									Add your first product below to start tracking inventory.
								</p>
								<a href="#add-product" class="btn primary">
									Add product
								</a>
							</div>
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>
</section>

<!-- Lower content -->
<div class="grid cols-2 lower-grid">
	<!-- Add product -->
	<section class="panel" id="add-product">
		<div class="panel-head">
			<div>
				<h2>Add product</h2>
				<p class="hint">
					Create a new active SKU in your catalog.
				</p>
			</div>
		</div>

		<div class="panel-body">
			<form method="POST" action="?/create" class="product-form">
				<div class="field">
					<label for="sku">SKU</label>
					<input
						id="sku"
						name="sku"
						placeholder="SKU-001"
						autocomplete="off"
						required
					/>
				</div>

				<div class="field">
					<label for="name">Product name</label>
					<input
						id="name"
						name="name"
						placeholder="Product name"
						required
					/>
				</div>

				<div class="field">
					<label for="category">Category</label>
					<input
						id="category"
						name="category"
						value="general"
						placeholder="general"
					/>
				</div>

				<div class="field">
					<label for="stock">Opening stock</label>
					<input
						id="stock"
						name="stock"
						type="number"
						min="0"
						step="1"
						value="0"
					/>
				</div>

				<div class="field">
					<label for="price">Selling price</label>
					<div class="input-with-prefix">
						<span>DH</span>
						<input
							id="price"
							name="price"
							type="number"
							min="0"
							step="0.01"
							value="0"
							required
						/>
					</div>
				</div>

				<div class="field">
					<label for="cost">Unit cost</label>
					<div class="input-with-prefix">
						<span>DH</span>
						<input
							id="cost"
							name="cost"
							type="number"
							min="0"
							step="0.01"
							value="0"
							required
						/>
					</div>
				</div>

				<div class="form-footer">
					<p class="hint">
						The product will be created as an active SKU.
					</p>

					<button class="primary" type="submit">
						Add product
					</button>
				</div>
			</form>
		</div>
	</section>

	<!-- Recent movements -->
	<section class="panel">
		<div class="panel-head">
			<div>
				<h2>Recent stock movements</h2>
				<p class="hint">
					The latest inventory adjustments recorded in the system.
				</p>
			</div>
		</div>

		<div class="movement-list">
			{#each data.movements as movement (movement.id)}
				<div class="movement">
					<div class="movement-indicator">
						<span class:negative={movement.delta < 0}>
							{movement.delta > 0 ? '+' : ''}
							{movement.delta}
						</span>
					</div>

					<div class="movement-content">
						<div class="movement-top">
							<strong>{movement.name}</strong>

							<span
								class:positive={movement.delta > 0}
								class:negative={movement.delta < 0}
								class="movement-delta"
							>
								{movement.delta > 0 ? '+' : ''}
								{movement.delta}
							</span>
						</div>

						<div class="movement-meta">
							<span>{movement.reason || 'Manual adjustment'}</span>
							<span>·</span>
							<span>{movement.actor ?? 'system'}</span>
							<span>·</span>
							<span>{dateTime(movement.created_at)}</span>
						</div>
					</div>
				</div>
			{:else}
				<div class="empty-state compact">
					<div class="empty-icon" aria-hidden="true">↕</div>
					<strong>No stock movements</strong>
					<p class="muted">
						Manual inventory adjustments will appear here.
					</p>
				</div>
			{/each}
		</div>
	</section>
</div>

<style>
	.page-header {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 24px;
		margin-bottom: 24px;
	}

	.page-header h1 {
		margin: 2px 0 6px;
		font-size: 28px;
		letter-spacing: -0.02em;
	}

	.page-header p {
		margin: 0;
	}

	.eyebrow {
		font-size: 12px;
		font-weight: 700;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		opacity: 0.65;
	}

	.metric-strip {
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		gap: 1px;
		margin: 16px 0 24px;
		overflow: hidden;
		border: 1px solid var(--border, #ddd);
		border-radius: 12px;
	}

	.metric {
		display: flex;
		flex-direction: column;
		gap: 4px;
		padding: 16px 18px;
		background: var(--surface, white);
	}

	.metric-label {
		font-size: 12px;
		opacity: 0.65;
	}

	.metric strong {
		font-size: 20px;
	}

	.metric strong.red {
		color: var(--red);
	}

	.inventory-panel {
		margin-top: 8px;
	}

	.inventory-head {
		align-items: center;
	}

	.inventory-summary {
		display: flex;
		align-items: center;
		gap: 8px;
	}

	.table-wrap {
		overflow-x: auto;
	}

	.sku {
		font-size: 12px;
	}

	.product-name {
		font-weight: 600;
		min-width: 150px;
	}

	.stock-cell {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		gap: 8px;
	}

	.negative {
		color: var(--red);
	}

	.positive {
		color: var(--green);
	}

	.adjust-form {
		display: flex;
		align-items: flex-end;
		gap: 8px;
		min-width: 330px;
	}

	.adjust-input {
		display: flex;
		flex-direction: column;
		gap: 4px;
	}

	.adjust-input label {
		font-size: 10px;
		font-weight: 600;
		opacity: 0.65;
	}

	.adjust-input input {
		width: 82px;
	}

	.adjust-input.reason-input input {
		width: 140px;
	}

	.lower-grid {
		margin-top: 24px;
		align-items: start;
	}

	.product-form {
		display: grid;
		grid-template-columns: repeat(2, minmax(0, 1fr));
		gap: 16px;
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.field label {
		font-size: 13px;
		font-weight: 600;
	}

	.field input {
		width: 100%;
	}

	.input-with-prefix {
		display: flex;
		align-items: center;
		overflow: hidden;
		border: 1px solid var(--border, #ddd);
		border-radius: 8px;
	}

	.input-with-prefix span {
		padding-left: 10px;
		font-size: 12px;
		opacity: 0.6;
	}

	.input-with-prefix input {
		border: 0;
		border-radius: 0;
	}

	.form-footer {
		display: flex;
		grid-column: 1 / -1;
		align-items: center;
		justify-content: space-between;
		gap: 16px;
		margin-top: 4px;
		padding-top: 16px;
		border-top: 1px solid var(--border, #ddd);
	}

	.form-footer p {
		margin: 0;
	}

	.movement-list {
		padding: 4px 18px 18px;
	}

	.movement {
		display: flex;
		gap: 12px;
		padding: 14px 0;
		border-bottom: 1px solid var(--border, #ddd);
	}

	.movement:last-child {
		border-bottom: 0;
	}

	.movement-indicator {
		display: grid;
		flex: 0 0 36px;
		height: 36px;
		place-items: center;
		border-radius: 10px;
		background: var(--surface-muted, #f5f5f5);
		font-weight: 700;
		font-size: 12px;
	}

	.movement-content {
		flex: 1;
		min-width: 0;
	}

	.movement-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
	}

	.movement-delta {
		font-weight: 700;
	}

	.movement-meta {
		display: flex;
		flex-wrap: wrap;
		gap: 5px;
		margin-top: 4px;
		font-size: 11px;
		opacity: 0.6;
	}

	.empty-state {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		min-height: 220px;
		padding: 32px;
		text-align: center;
	}

	.empty-state.compact {
		min-height: 180px;
	}

	.empty-state strong {
		margin-top: 10px;
	}

	.empty-state p {
		max-width: 360px;
		margin: 6px 0 16px;
	}

	.empty-icon {
		display: grid;
		width: 48px;
		height: 48px;
		place-items: center;
		border-radius: 14px;
		background: var(--surface-muted, #f5f5f5);
		font-size: 20px;
	}

	@media (max-width: 1000px) {
		.metric-strip {
			grid-template-columns: repeat(2, 1fr);
		}

		.adjust-form {
			min-width: 290px;
		}
	}

	@media (max-width: 760px) {
		.page-header {
			flex-direction: column;
		}

		.page-header .btn {
			width: 100%;
			justify-content: center;
		}

		.metric-strip {
			grid-template-columns: 1fr 1fr;
		}

		.product-form {
			grid-template-columns: 1fr;
		}

		.form-footer {
			flex-direction: column;
			align-items: stretch;
		}

		.form-footer button {
			justify-content: center;
		}

		.lower-grid {
			grid-template-columns: 1fr;
		}
	}

	@media (max-width: 480px) {
		.metric-strip {
			grid-template-columns: 1fr;
		}
	}
</style>