import { error, fail, redirect } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { oneOf, positiveId, requiredText } from '$lib/server/validation';
import type { Actions, PageServerLoad } from './$types';

const CAMPAIGN_TYPES = ['promotional', 'announcement', 'automation', 'reminder'] as const;

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user) throw redirect(302, '/login');
	if (!can(locals.user.role, 'campaigns.view')) throw error(403, 'Not allowed');

	const [campaigns, performance, templateRows, customerCount] = await Promise.all([
		query<{
			id: number;
			name: string;
			type: string;
			status: string;
			recipient_count: number;
			sent_count: number;
			delivered_count: number;
			read_count: number;
			conversion_count: number;
			revenue: number;
			cost: number;
			scheduled_date: string | null;
		}> (
			`SELECT id, name, type, status, recipient_count, sent_count,
				delivered_count, read_count, conversion_count, revenue, cost,
				scheduled_date
			 FROM marketing_campaigns
			 ORDER BY created_at DESC`
		),
		query<{
			date: string;
			sent: number;
			delivered: number;
			read: number;
			conversions: number;
		}>(
			`SELECT
				to_char(created_at::date, 'YYYY-MM-DD') AS date,
				coalesce(sum(sent_count), 0)::int AS sent,
				coalesce(sum(delivered_count), 0)::int AS delivered,
				coalesce(sum(read_count), 0)::int AS read,
				coalesce(sum(conversion_count), 0)::int AS conversions
			 FROM marketing_campaigns
			 GROUP BY created_at::date
			 ORDER BY created_at::date DESC
			 LIMIT 30`
		),
		query<{
			id: number;
			name: string;
			body: string;
			category: string;
		}>('SELECT id, name, body, category FROM message_templates WHERE active = true ORDER BY category, name'),
		query<{ count: number }>('SELECT count(*)::int AS count FROM customers')
	]);

	const totalCampaigns = campaigns.length;
	const activeCampaigns = campaigns.filter((campaign) => campaign.status === 'active').length;
	const totalMessages = campaigns.reduce((sum, campaign) => sum + Number(campaign.sent_count ?? 0), 0);
	const totalRevenue = campaigns.reduce((sum, campaign) => sum + Number(campaign.revenue ?? 0), 0);
	const totalCost = campaigns.reduce((sum, campaign) => sum + Number(campaign.cost ?? 0), 0);
	const totalSent = campaigns.reduce((sum, campaign) => sum + Number(campaign.sent_count ?? 0), 0);
	const totalDelivered = campaigns.reduce((sum, campaign) => sum + Number(campaign.delivered_count ?? 0), 0);
	const totalConversions = campaigns.reduce((sum, campaign) => sum + Number(campaign.conversion_count ?? 0), 0);

	return {
		user: locals.user,
		campaigns: campaigns.map((campaign) => ({
			id: campaign.id,
			name: campaign.name,
			type: campaign.type,
			status: campaign.status,
			recipientCount: Number(campaign.recipient_count ?? 0),
			sentCount: Number(campaign.sent_count ?? 0),
			deliveredCount: Number(campaign.delivered_count ?? 0),
			readCount: Number(campaign.read_count ?? 0),
			conversionCount: Number(campaign.conversion_count ?? 0),
			revenue: Number(campaign.revenue ?? 0),
			cost: Number(campaign.cost ?? 0),
			scheduledDate: campaign.scheduled_date
	})),
		analytics: {
			totalCampaigns,
			activeCampaigns,
			totalMessages,
			totalRevenue,
			totalCost,
			avgDeliveryRate: totalSent ? (totalDelivered / totalSent) * 100 : 0,
			avgConversionRate: totalSent ? (totalConversions / totalSent) * 100 : 0,
			roi: totalCost ? ((totalRevenue - totalCost) / totalCost) * 100 : 0
		},
		audienceSegments: [
			{
				id: 'all',
				name: 'All customers',
				count: Number(customerCount[0]?.count ?? 0),
				description: 'Every customer currently stored in Efoka.'
			}
		],
		messageTemplates: templateRows.map((template) => ({
			id: template.id,
			name: template.name,
			category: template.category,
			content: template.body,
			preview: template.body
		})),
		performance: performance.map((item) => ({
			date: item.date,
			sent: Number(item.sent ?? 0),
			delivered: Number(item.delivered ?? 0),
			read: Number(item.read ?? 0),
			conversions: Number(item.conversions ?? 0)
		}))
	};
};

export const actions: Actions = {
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'campaigns.manage')) {
			return fail(403, { error: 'Not allowed' });
		}

		try {
			const form = await request.formData();
			const name = requiredText(form.get('name'), 'Campaign name', 255);
			const type = oneOf(form.get('type'), CAMPAIGN_TYPES, 'campaign type');
			const audience = requiredText(form.get('audience'), 'Audience', 100);
			const message = requiredText(form.get('message'), 'Message', 1000);
			const scheduledDate = requiredText(form.get('scheduledDate'), 'Schedule', 100);
			const templateValue = form.get('template');
			const templateId = templateValue ? positiveId(templateValue) : null;

			if (audience !== 'all') return fail(400, { error: 'Unknown audience segment' });

			const customerCount = await query<{ count: number }>('SELECT count(*)::int AS count FROM customers');
			await query(
				`INSERT INTO marketing_campaigns
					(name, type, status, audience_segment, recipient_count, scheduled_date, template_id, message, created_by)
				 VALUES ($1, $2, 'scheduled', $3, $4, $5, $6, $7, $8)`,
				[name, type, audience, customerCount[0]?.count ?? 0, scheduledDate, templateId, message, locals.user.id]
			);

			return { success: `${name} was created` };
		} catch (err) {
			return fail(400, { error: err instanceof Error ? err.message : 'Could not create campaign' });
		}
	},

	launch: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'campaigns.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('campaignId'));
		await query("UPDATE marketing_campaigns SET status = 'active', updated_at = now() WHERE id = $1 AND status = 'scheduled'", [id]);
		return { success: 'Campaign launched' };
	},

	pause: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'campaigns.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('campaignId'));
		await query("UPDATE marketing_campaigns SET status = 'paused', updated_at = now() WHERE id = $1 AND status = 'active'", [id]);
		return { success: 'Campaign paused' };
	},

	delete: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'campaigns.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('campaignId'));
		await query('DELETE FROM marketing_campaigns WHERE id = $1', [id]);
		return { success: 'Campaign deleted' };
	}
};
