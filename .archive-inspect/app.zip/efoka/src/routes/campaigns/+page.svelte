<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { money, timeAgo } from '$lib/format';

	let { data, form } = $props();

	let showCreateModal = $state(false);
	let statusFilter = $state('all');
	let typeFilter = $state('all');
	let dateFilter = $state('all');

	let newCampaign = $state({
		name: '',
		type: 'promotional',
		audience: '',
		message: '',
		template: '',
		scheduledDate: ''
	});

	const campaigns = $derived(data.campaigns ?? []);
	const analytics = $derived(data.analytics ?? null);
	const audienceSegments = $derived(data.audienceSegments ?? []);
	const messageTemplates = $derived(data.messageTemplates ?? []);
	const performance = $derived(data.performance ?? []);

	const filteredCampaigns = $derived(
		campaigns.filter((campaign) => {
			const matchesStatus =
				statusFilter === 'all' || campaign.status === statusFilter;

			const matchesType =
				typeFilter === 'all' || campaign.type === typeFilter;

			return matchesStatus && matchesType;
		})
	);

	const performanceMax = $derived(
		Math.max(
			1,
			...performance.flatMap((item) => [
				item.sent ?? 0,
				item.delivered ?? 0,
				item.read ?? 0,
				item.conversions ?? 0
			])
		)
	);

	const selectedTemplate = $derived(
		messageTemplates.find((template) => String(template.id) === newCampaign.template)
	);

	function openCreateModal() {
		newCampaign = {
			name: '',
			type: 'promotional',
			audience: audienceSegments[0]?.id ?? '',
			message: '',
			template: '',
			scheduledDate: ''
		};

		showCreateModal = true;
	}

	function closeCreateModal() {
		showCreateModal = false;
	}

	function applyTemplate() {
		if (selectedTemplate?.content) {
			newCampaign.message = selectedTemplate.content;
		} else if (selectedTemplate?.preview) {
			newCampaign.message = selectedTemplate.preview;
		}
	}

	function calculateROI(revenue: number, cost: number) {
		if (!cost) return 0;
		return ((revenue - cost) / cost) * 100;
	}

	function calculateDeliveryRate(sent: number, delivered: number) {
		if (!sent) return 0;
		return (delivered / sent) * 100;
	}

	function calculateReadRate(delivered: number, read: number) {
		if (!delivered) return 0;
		return (read / delivered) * 100;
	}
</script>

{#if form?.success}
	<div class="notice" role="status">{form.success}</div>
{/if}

{#if form?.error}
	<div class="error" role="alert">{form.error}</div>
{/if}

<!-- Header -->
<div class="page-header">
	<div>
		<h1>Campaigns</h1>
		<p class="muted">
			Manage WhatsApp campaigns, audiences, templates and performance.
		</p>
	</div>

	<button class="primary" type="button" onclick={openCreateModal}>
		+ New Campaign
	</button>
</div>

<!-- Analytics -->
{#if analytics}
	<div class="grid cols-4">
		<div class="panel stat">
			<div class="panel-body">
				<div class="label">Total campaigns</div>
				<div class="value">
					{analytics.totalCampaigns?.toLocaleString() ?? '0'}
				</div>
				<div class="foot">
					{analytics.activeCampaigns?.toLocaleString() ?? '0'} active
				</div>
			</div>
		</div>

		<div class="panel stat">
			<div class="panel-body">
				<div class="label">Messages sent</div>
				<div class="value">
					{analytics.totalMessages?.toLocaleString() ?? '0'}
				</div>
				<div class="foot">
					{analytics.avgDeliveryRate?.toFixed?.(1) ?? '0'}% delivery rate
				</div>
			</div>
		</div>

		<div class="panel stat">
			<div class="panel-body">
				<div class="label">Campaign revenue</div>
				<div class="value">
					{money(analytics.totalRevenue ?? 0)}
				</div>
				<div class="foot">
					{analytics.avgConversionRate?.toFixed?.(1) ?? '0'}% conversion
				</div>
			</div>
		</div>

		<div class="panel stat">
			<div class="panel-body">
				<div class="label">Average ROI</div>
				<div class="value">
					{analytics.roi?.toFixed?.(1) ?? '0'}%
				</div>
				<div class="foot">
					{money(analytics.totalCost ?? 0)} total cost
				</div>
			</div>
		</div>
	</div>
{/if}

<!-- Campaign list -->
<div class="panel section">
	<div class="panel-head">
		<div>
			<h2>WhatsApp Campaigns</h2>
			<span class="hint">
				{filteredCampaigns.length} campaign{filteredCampaigns.length === 1 ? '' : 's'}
			</span>
		</div>
	</div>

	<div class="panel-body">
		<div class="advanced-filter">
			<div class="filter-group">
				<label for="campaign-status">Status</label>
				<select id="campaign-status" bind:value={statusFilter}>
					<option value="all">All statuses</option>
					<option value="active">Active</option>
					<option value="scheduled">Scheduled</option>
					<option value="completed">Completed</option>
					<option value="paused">Paused</option>
				</select>
			</div>

			<div class="filter-group">
				<label for="campaign-type">Type</label>
				<select id="campaign-type" bind:value={typeFilter}>
					<option value="all">All types</option>
					<option value="promotional">Promotional</option>
					<option value="announcement">Announcement</option>
					<option value="automation">Automation</option>
					<option value="reminder">Reminder</option>
				</select>
			</div>

			<div class="filter-group">
				<label for="campaign-date">Date</label>
				<select id="campaign-date" bind:value={dateFilter}>
					<option value="all">All time</option>
					<option value="week">This week</option>
					<option value="month">This month</option>
				</select>
			</div>
		</div>
	</div>

	<div class="table-wrap">
		<table>
			<thead>
				<tr>
					<th>Campaign</th>
					<th>Type</th>
					<th>Status</th>
					<th class="num">Audience</th>
					<th class="num">Sent</th>
					<th class="num">Delivered</th>
					<th class="num">Read</th>
					<th class="num">Conversions</th>
					<th class="num">Revenue</th>
					<th class="num">ROI</th>
					<th>Actions</th>
				</tr>
			</thead>

			<tbody>
				{#each filteredCampaigns as campaign (campaign.id)}
					<tr>
						<td>
							<strong>{campaign.name}</strong>

							{#if campaign.scheduledDate}
								<div class="tiny muted">
									{timeAgo(campaign.scheduledDate)}
								</div>
							{/if}
						</td>

						<td>
							<span class="pill blue">{campaign.type}</span>
						</td>

						<td>
							<Pill status={campaign.status} />
						</td>

						<td class="num">
							{(campaign.recipientCount ?? 0).toLocaleString()}
						</td>

						<td class="num">
							{(campaign.sentCount ?? 0).toLocaleString()}
						</td>

						<td class="num">
							{(campaign.deliveredCount ?? 0).toLocaleString()}

							<div class="tiny muted">
								{calculateDeliveryRate(
									campaign.sentCount ?? 0,
									campaign.deliveredCount ?? 0
								).toFixed(1)}%
							</div>
						</td>

						<td class="num">
							{(campaign.readCount ?? 0).toLocaleString()}

							<div class="tiny muted">
								{calculateReadRate(
									campaign.deliveredCount ?? 0,
									campaign.readCount ?? 0
								).toFixed(1)}%
							</div>
						</td>

						<td class="num">
							{(campaign.conversionCount ?? 0).toLocaleString()}
						</td>

						<td class="num">
							{money(campaign.revenue ?? 0)}
						</td>

						<td class="num">
							<span class:positive={calculateROI(
								campaign.revenue ?? 0,
								campaign.cost ?? 0
							) > 0}>
								{calculateROI(
									campaign.revenue ?? 0,
									campaign.cost ?? 0
								).toFixed(1)}%
							</span>
						</td>

						<td>
							<div class="row actions">
								{#if campaign.status === 'scheduled'}
									<form method="POST" action="?/launch">
										<input
											type="hidden"
											name="campaignId"
											value={campaign.id}
										/>
										<button class="small primary" type="submit">
											Launch
										</button>
									</form>
								{:else if campaign.status === 'active'}
									<form method="POST" action="?/pause">
										<input
											type="hidden"
											name="campaignId"
											value={campaign.id}
										/>
										<button class="small" type="submit">
											Pause
										</button>
									</form>
								{/if}

								<form method="POST" action="?/delete">
									<input
										type="hidden"
										name="campaignId"
										value={campaign.id}
									/>
									<button
										class="small danger"
										type="submit"
										aria-label="Delete {campaign.name}"
									>
										Delete
									</button>
								</form>
							</div>
						</td>
					</tr>
				{:else}
					<tr>
						<td colspan="11" class="empty">
							No campaigns match the selected filters.
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>
</div>

<!-- Performance -->
{#if performance.length > 0}
	<div class="panel section">
		<div class="panel-head">
			<div>
				<h2>Campaign Performance</h2>
				<span class="hint">Recent delivery and conversion activity</span>
			</div>
		</div>

		<div class="panel-body">
			<div class="legend">
				<span><i class="legend-dot sent"></i> Sent</span>
				<span><i class="legend-dot delivered"></i> Delivered</span>
				<span><i class="legend-dot read"></i> Read</span>
				<span><i class="legend-dot conversions"></i> Conversions</span>
			</div>

			<div class="performance-chart">
				{#each performance as item (item.date)}
					<div class="chart-column">
						<div class="chart-values">
							<span>{item.conversions ?? 0}</span>
						</div>

						<div class="bars">
							<div
								class="bar sent"
								style={`height:${((item.sent ?? 0) / performanceMax) * 100}%`}
								title={`Sent: ${item.sent ?? 0}`}
							></div>

							<div
								class="bar delivered"
								style={`height:${((item.delivered ?? 0) / performanceMax) * 100}%`}
								title={`Delivered: ${item.delivered ?? 0}`}
							></div>

							<div
								class="bar read"
								style={`height:${((item.read ?? 0) / performanceMax) * 100}%`}
								title={`Read: ${item.read ?? 0}`}
							></div>

							<div
								class="bar conversions"
								style={`height:${((item.conversions ?? 0) / performanceMax) * 100}%`}
								title={`Conversions: ${item.conversions ?? 0}`}
							></div>
						</div>

						<div class="chart-label">
							{item.date}
						</div>
					</div>
				{/each}
			</div>
		</div>
	</div>
{/if}

<!-- Audiences + Templates -->
<div class="grid cols-2 section">
	<div class="panel">
		<div class="panel-head">
			<div>
				<h2>Audience Segments</h2>
				<span class="hint">{audienceSegments.length} segments</span>
			</div>

			<a class="btn small" href="/customers">
				Manage
			</a>
		</div>

		<div class="panel-body stack">
			{#each audienceSegments as segment (segment.id)}
				<div class="list-card">
					<div class="spread">
						<strong>{segment.name}</strong>
						<span class="pill blue">
							{(segment.count ?? 0).toLocaleString()}
						</span>
					</div>

					{#if segment.description}
						<div class="tiny muted">
							{segment.description}
						</div>
					{/if}
				</div>
			{:else}
				<div class="empty">No audience segments available.</div>
			{/each}
		</div>
	</div>

	<div class="panel">
		<div class="panel-head">
			<div>
				<h2>Message Templates</h2>
				<span class="hint">{messageTemplates.length} templates</span>
			</div>

			<a class="btn small" href="/templates">
				Manage
			</a>
		</div>

		<div class="panel-body stack">
			{#each messageTemplates as template (template.id)}
				<div class="list-card">
					<div class="spread">
						<strong>{template.name}</strong>
						<span class="pill violet">{template.category}</span>
					</div>

					<div class="tiny muted truncate">
						{template.preview ?? template.content ?? ''}
					</div>
				</div>
			{:else}
				<div class="empty">No message templates available.</div>
			{/each}
		</div>
	</div>
</div>

<!-- Create campaign modal -->
{#if showCreateModal}
	<div
		class="modal-overlay"
		role="presentation"
		onclick={(event) => {
			if (event.currentTarget === event.target) closeCreateModal();
		}}
	>
		<div
			class="modal-content"
			role="dialog"
			aria-modal="true"
			aria-labelledby="create-campaign-title"
		>
			<div class="spread modal-header">
				<div>
					<h2 id="create-campaign-title">Create campaign</h2>
					<p class="muted tiny">
						Create a campaign using your configured audience and templates.
					</p>
				</div>

				<button
					class="small"
					type="button"
					aria-label="Close"
					onclick={closeCreateModal}
				>
					×
				</button>
			</div>

			<form method="POST" action="?/create" class="stack">
				<div class="field">
					<label for="campaign-name">Campaign name</label>
					<input
						id="campaign-name"
						name="name"
						bind:value={newCampaign.name}
						required
						maxlength="120"
						placeholder="Campaign name"
					/>
				</div>

				<div class="grid cols-2">
					<div class="field">
						<label for="campaign-type-create">Campaign type</label>
						<select
							id="campaign-type-create"
							name="type"
							bind:value={newCampaign.type}
						>
							<option value="promotional">Promotional</option>
							<option value="announcement">Announcement</option>
							<option value="automation">Automation</option>
							<option value="reminder">Reminder</option>
						</select>
					</div>

					<div class="field">
						<label for="campaign-schedule">Schedule</label>
						<input
							id="campaign-schedule"
							name="scheduledDate"
							type="datetime-local"
							bind:value={newCampaign.scheduledDate}
							required
						/>
					</div>
				</div>

				<div class="field">
					<label for="campaign-audience">Audience</label>
					<select
						id="campaign-audience"
						name="audience"
						bind:value={newCampaign.audience}
						required
					>
						<option value="" disabled>Select an audience</option>

						{#each audienceSegments as segment (segment.id)}
							<option value={segment.id}>
								{segment.name}
								({(segment.count ?? 0).toLocaleString()})
							</option>
						{/each}
					</select>
				</div>

				<div class="field">
					<label for="campaign-template">Template</label>

					<select
						id="campaign-template"
						name="template"
						bind:value={newCampaign.template}
						onchange={applyTemplate}
					>
						<option value="">No template</option>

						{#each messageTemplates as template (template.id)}
							<option value={template.id}>
								{template.name}
							</option>
						{/each}
					</select>
				</div>

				<div class="field">
					<div class="spread">
						<label for="campaign-message">Message</label>
						<span class="tiny muted">
							{newCampaign.message.length}/1000
						</span>
					</div>

					<textarea
						id="campaign-message"
						name="message"
						bind:value={newCampaign.message}
						rows="6"
						maxlength="1000"
						required
						placeholder="Write the campaign message..."
					></textarea>
				</div>

				<div class="modal-actions">
					<button type="button" onclick={closeCreateModal}>
						Cancel
					</button>

					<button class="primary" type="submit">
						Create campaign
					</button>
				</div>
			</form>
		</div>
	</div>
{/if}

<style>
	.page-header {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 16px;
		margin-bottom: 18px;
	}

	.page-header h1 {
		margin: 0 0 4px;
	}

	.section {
		margin-top: 18px;
	}

	.advanced-filter {
		display: grid;
		grid-template-columns: repeat(3, minmax(160px, 1fr));
		gap: 12px;
	}

	.filter-group {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.filter-group label,
	.field label {
		font-size: 12px;
		font-weight: 550;
		color: var(--muted);
	}

	.table-wrap {
		overflow-x: auto;
	}

	.actions {
		flex-wrap: nowrap;
	}

	.positive {
		color: var(--green);
		font-weight: 600;
	}

	.legend {
		display: flex;
		flex-wrap: wrap;
		gap: 16px;
		margin-bottom: 18px;
		font-size: 12px;
		color: var(--muted);
	}

	.legend span {
		display: inline-flex;
		align-items: center;
		gap: 6px;
	}

	.legend-dot {
		width: 8px;
		height: 8px;
		border-radius: 50%;
		display: inline-block;
	}

	.legend-dot.sent,
	.bar.sent {
		background: var(--green);
	}

	.legend-dot.delivered,
	.bar.delivered {
		background: var(--brand);
	}

	.legend-dot.read,
	.bar.read {
		background: var(--violet);
	}

	.legend-dot.conversions,
	.bar.conversions {
		background: var(--amber);
	}

	.performance-chart {
		height: 280px;
		display: flex;
		align-items: stretch;
		gap: 10px;
		overflow-x: auto;
		padding-top: 10px;
	}

	.chart-column {
		flex: 1;
		min-width: 70px;
		display: flex;
		flex-direction: column;
	}

	.chart-values {
		height: 24px;
		text-align: center;
		font-size: 11px;
		color: var(--muted);
	}

	.bars {
		flex: 1;
		display: flex;
		align-items: flex-end;
		gap: 3px;
		min-height: 180px;
	}

	.bar {
		flex: 1;
		min-height: 2px;
		border-radius: 4px 4px 2px 2px;
		transition: opacity 0.15s ease;
	}

	.bar:hover {
		opacity: 0.75;
	}

	.chart-label {
		padding-top: 8px;
		text-align: center;
		font-size: 11px;
		color: var(--muted);
	}

	.list-card {
		padding: 12px;
		border: 1px solid var(--line);
		border-radius: 10px;
	}

	.truncate {
		margin-top: 5px;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.modal-overlay {
		position: fixed;
		inset: 0;
		z-index: 1000;
		display: grid;
		place-items: center;
		padding: 20px;
		background: rgba(0, 0, 0, 0.5);
	}

	.modal-content {
		width: min(620px, 100%);
		max-height: min(760px, 90vh);
		overflow-y: auto;
		padding: 24px;
		background: var(--panel);
		border: 1px solid var(--line);
		border-radius: 16px;
		box-shadow: var(--shadow-lg);
	}

	.modal-header {
		margin-bottom: 20px;
	}

	.modal-header h2 {
		margin: 0;
	}

	.modal-actions {
		display: flex;
		justify-content: flex-end;
		gap: 10px;
		margin-top: 8px;
	}

	@media (max-width: 900px) {
		.advanced-filter {
			grid-template-columns: 1fr;
		}

		.page-header {
			flex-direction: column;
		}

		.page-header > button {
			width: 100%;
		}
	}

	@media (max-width: 640px) {
		.modal-overlay {
			padding: 10px;
		}

		.modal-content {
			padding: 18px;
		}

		.modal-actions {
			flex-direction: column-reverse;
		}

		.modal-actions button {
			width: 100%;
		}
	}
</style>