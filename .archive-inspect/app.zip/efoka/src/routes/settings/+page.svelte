<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Helper,
		Input,
		Label,
		Select,
		Spinner,
		Toggle
	} from 'flowbite-svelte';

	let { data } = $props();

	type Tab = 'general' | 'notifications' | 'security' | 'integrations';

	let activeTab = $state<Tab>('general');
	let saving = $state(false);
	let saved = $state(false);

	let settings = $state({
		workspaceName: 'Efoka.ma Operations',
		workspaceDomain: 'efoka.ma',
		timezone: 'Africa/Casablanca',
		currency: 'MAD',
		dateFormat: 'DD/MM/YYYY',
		language: 'en',

		notifications: {
			emailAlerts: true,
			smsAlerts: false,
			pushNotifications: true,
			weeklyReports: true
		},

		security: {
			twoFactorRequired: false,
			sessionTimeout: 24,
			ipRestriction: false,
			allowedIPs: [] as string[]
		},

		integrations: {
			autoSyncOrders: true,
			autoSyncInventory: true,
			webhookEnabled: true
		}
	});

	const tabs = [
		{
			id: 'general' as Tab,
			label: 'General',
			description: 'Workspace identity and localization'
		},
		{
			id: 'notifications' as Tab,
			label: 'Notifications',
			description: 'Alerts and reporting preferences'
		},
		{
			id: 'security' as Tab,
			label: 'Security',
			description: 'Authentication and access controls'
		},
		{
			id: 'integrations' as Tab,
			label: 'Integrations',
			description: 'Automation and external services'
		}
	];

	const currentTab = $derived(
		tabs.find((tab) => tab.id === activeTab) ?? tabs[0]
	);

	function selectTab(tab: Tab) {
		activeTab = tab;
		saved = false;
	}

	function saveSettings() {
		saving = true;
		saved = false;

		/*
		 * Replace this with the real SvelteKit form action once
		 * settings persistence is connected server-side.
		 */
		setTimeout(() => {
			saving = false;
			saved = true;
		}, 500);
	}
</script>

<svelte:head>
	<title>Settings · Efoka</title>
	<meta
		name="description"
		content="Manage Efoka workspace, notification, security and integration settings."
	/>
</svelte:head>

<div class="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-start">
	<div>
		<div class="mb-2 flex items-center gap-2">
			<Badge color="blue">Workspace</Badge>

			<Badge color="gray">
				{settings.workspaceDomain}
			</Badge>
		</div>

		<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
			Settings
		</h1>

		<p class="mt-2 max-w-2xl text-sm leading-6 text-gray-500 dark:text-gray-400">
			Configure your workspace, notifications, security policies and
			integrations from one place.
		</p>
	</div>

	<div class="flex items-center gap-3">
		{#if saved}
			<Badge color="green">
				Settings saved
			</Badge>
		{/if}

		<Button color="primary" disabled={saving} onclick={saveSettings}>
			{#if saving}
				<Spinner size="4" class="me-2" />
				Saving...
			{:else}
				Save changes
			{/if}
		</Button>
	</div>
</div>

<div class="grid gap-6 lg:grid-cols-12">
	<!-- Navigation -->
	<Card class="lg:col-span-3">
		<div class="mb-5">
			<h2 class="text-base font-semibold text-gray-900 dark:text-white">
				Workspace settings
			</h2>

			<p class="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
				Manage how your Efoka workspace behaves.
			</p>
		</div>

		<nav class="space-y-2" aria-label="Settings navigation">
			{#each tabs as tab (tab.id)}
				<button
					type="button"
					class:settings-nav-active={activeTab === tab.id}
					class="settings-nav-item w-full rounded-xl p-3 text-left transition"
					onclick={() => selectTab(tab.id)}
				>
					<div class="flex items-start gap-3">
						<div
							class:settings-icon-active={activeTab === tab.id}
							class="settings-icon"
						>
							{#if tab.id === 'general'}
								◉
							{:else if tab.id === 'notifications'}
								◌
							{:else if tab.id === 'security'}
								◆
							{:else}
								↗
							{/if}
						</div>

						<div class="min-w-0">
							<div
								class={activeTab === tab.id
									? 'text-sm font-semibold text-primary-700 dark:text-primary-300'
									: 'text-sm font-semibold text-gray-900 dark:text-white'}
							>
								{tab.label}
							</div>

							<div
								class={activeTab === tab.id
									? 'mt-1 text-xs leading-5 text-primary-600 dark:text-primary-400'
									: 'mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400'}
							>
								{tab.description}
							</div>
						</div>
					</div>
				</button>
			{/each}
		</nav>

		<div class="mt-6 rounded-xl border border-gray-200 bg-gray-50 p-4 dark:border-gray-700 dark:bg-gray-800/50">
			<div class="text-xs font-semibold uppercase tracking-wide text-gray-400">
				Workspace
			</div>

			<div class="mt-2 truncate text-sm font-semibold text-gray-900 dark:text-white">
				{settings.workspaceName}
			</div>

			<div class="mt-1 truncate text-xs text-gray-500 dark:text-gray-400">
				{settings.workspaceDomain}
			</div>
		</div>
	</Card>

	<!-- Settings content -->
	<div class="space-y-6 lg:col-span-9">
		<Card>
			<div class="border-b border-gray-200 pb-5 dark:border-gray-700">
				<div class="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
					<div>
						<h2 class="text-xl font-bold text-gray-900 dark:text-white">
							{currentTab.label}
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							{currentTab.description}
						</p>
					</div>

					<Badge color="gray">
						{activeTab}
					</Badge>
				</div>
			</div>

			<!-- GENERAL -->
			{#if activeTab === 'general'}
				<div class="space-y-7 pt-6">
					<div>
						<h3 class="section-title">
							Workspace identity
						</h3>

						<p class="section-description">
							Basic information used throughout your operations workspace.
						</p>
					</div>

					<div class="grid gap-5 md:grid-cols-2">
						<div>
							<Label for="workspace-name" class="mb-2 block">
								Workspace name
							</Label>

							<Input
								id="workspace-name"
								bind:value={settings.workspaceName}
								placeholder="My workspace"
							/>

							<Helper class="mt-1">
								The name shown to members of your workspace.
							</Helper>
						</div>

						<div>
							<Label for="workspace-domain" class="mb-2 block">
								Workspace domain
							</Label>

							<Input
								id="workspace-domain"
								bind:value={settings.workspaceDomain}
								placeholder="example.com"
							/>

							<Helper class="mt-1">
								Your primary workspace domain.
							</Helper>
						</div>
					</div>

					<div>
						<h3 class="section-title">
							Localization
						</h3>

						<p class="section-description">
							Control how dates, currencies and regional information are
							displayed.
						</p>
					</div>

					<div class="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
						<div>
							<Label for="timezone" class="mb-2 block">
								Timezone
							</Label>

							<Select id="timezone" bind:value={settings.timezone}>
								<option value="Africa/Casablanca">
									Africa/Casablanca
								</option>
								<option value="Europe/Paris">
									Europe/Paris
								</option>
								<option value="America/New_York">
									America/New_York
								</option>
							</Select>
						</div>

						<div>
							<Label for="currency" class="mb-2 block">
								Currency
							</Label>

							<Select id="currency" bind:value={settings.currency}>
								<option value="MAD">
									MAD — Moroccan Dirham
								</option>
								<option value="USD">
									USD — US Dollar
								</option>
								<option value="EUR">
									EUR — Euro
								</option>
							</Select>
						</div>

						<div>
							<Label for="language" class="mb-2 block">
								Language
							</Label>

							<Select id="language" bind:value={settings.language}>
								<option value="en">English</option>
								<option value="fr">French</option>
								<option value="ar">Arabic</option>
							</Select>
						</div>
					</div>

					<div>
						<Label for="date-format" class="mb-2 block">
							Date format
						</Label>

						<Select
							id="date-format"
							bind:value={settings.dateFormat}
							class="max-w-sm"
						>
							<option value="DD/MM/YYYY">
								DD/MM/YYYY
							</option>

							<option value="MM/DD/YYYY">
								MM/DD/YYYY
							</option>

							<option value="YYYY-MM-DD">
								YYYY-MM-DD
							</option>
						</Select>
					</div>
				</div>
			{/if}

			<!-- NOTIFICATIONS -->
			{#if activeTab === 'notifications'}
				<div class="space-y-4 pt-6">
					<div class="mb-6">
						<h3 class="section-title">
							Notification channels
						</h3>

						<p class="section-description">
							Choose where Efoka should send operational and account
							notifications.
						</p>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title">
								Email alerts
							</div>

							<div class="setting-description">
								Receive important account and operational alerts by email.
							</div>
						</div>

						<Toggle
							bind:checked={settings.notifications.emailAlerts}
						/>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title">
								SMS alerts
							</div>

							<div class="setting-description">
								Send urgent operational alerts to your phone.
							</div>
						</div>

						<Toggle
							bind:checked={settings.notifications.smsAlerts}
						/>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title">
								Push notifications
							</div>

							<div class="setting-description">
								Show browser notifications for real-time events.
							</div>
						</div>

						<Toggle
							bind:checked={settings.notifications.pushNotifications}
						/>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title flex items-center gap-2">
								Weekly reports

								<Badge color="blue">
									Recommended
								</Badge>
							</div>

							<div class="setting-description">
								Receive a weekly summary of orders, returns and performance.
							</div>
						</div>

						<Toggle
							bind:checked={settings.notifications.weeklyReports}
						/>
					</div>

					<div class="mt-6 rounded-xl border border-blue-200 bg-blue-50 p-4 dark:border-blue-900 dark:bg-blue-900/20">
						<div class="flex gap-3">
							<div class="text-lg text-blue-600 dark:text-blue-400">
								ⓘ
							</div>

							<div>
								<div class="text-sm font-semibold text-blue-900 dark:text-blue-200">
									Notification delivery
								</div>

								<p class="mt-1 text-xs leading-5 text-blue-700 dark:text-blue-300">
									Notification preferences are applied to future operational
									events. Critical security notifications may still be
									delivered regardless of these settings.
								</p>
							</div>
						</div>
					</div>
				</div>
			{/if}

			<!-- SECURITY -->
			{#if activeTab === 'security'}
				<div class="space-y-6 pt-6">
					<div>
						<h3 class="section-title">
							Authentication
						</h3>

						<p class="section-description">
							Control how members authenticate and how long sessions remain
							active.
						</p>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title flex items-center gap-2">
								Require two-factor authentication

								{#if settings.security.twoFactorRequired}
									<Badge color="green">Enabled</Badge>
								{:else}
									<Badge color="yellow">Optional</Badge>
								{/if}
							</div>

							<div class="setting-description">
								Require workspace members to use two-factor authentication
								when signing in.
							</div>
						</div>

						<Toggle
							bind:checked={settings.security.twoFactorRequired}
						/>
					</div>

					<div class="max-w-md">
						<Label for="session-timeout" class="mb-2 block">
							Session timeout
						</Label>

						<div class="flex items-center gap-3">
							<Input
								id="session-timeout"
								type="number"
								min="1"
								max="168"
								bind:value={settings.security.sessionTimeout}
							/>

							<span class="whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
								hours
							</span>
						</div>

						<Helper class="mt-1">
							Choose between 1 and 168 hours.
						</Helper>
					</div>

					<div class="border-t border-gray-200 pt-6 dark:border-gray-700">
						<h3 class="section-title">
							Network access
						</h3>

						<p class="section-description">
							Restrict workspace access to approved IP addresses.
						</p>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title flex items-center gap-2">
								IP restriction

								{#if settings.security.ipRestriction}
									<Badge color="green">Active</Badge>
								{:else}
									<Badge color="gray">Disabled</Badge>
								{/if}
							</div>

							<div class="setting-description">
								Only allow sign-ins from configured IP addresses.
							</div>
						</div>

						<Toggle
							bind:checked={settings.security.ipRestriction}
						/>
					</div>

					<div
						class:opacity-50={!settings.security.ipRestriction}
						class="rounded-xl border border-gray-200 p-5 transition dark:border-gray-700"
					>
						<div class="mb-4">
							<div class="text-sm font-semibold text-gray-900 dark:text-white">
								Allowed IP addresses
							</div>

							<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
								Configure the addresses allowed to access this workspace.
							</div>
						</div>

						<div class="flex gap-3">
							<Input
								placeholder="192.168.1.0/24"
								disabled={!settings.security.ipRestriction}
							/>

							<Button
								color="alternative"
								disabled={!settings.security.ipRestriction}
							>
								Add
							</Button>
						</div>

						{#if settings.security.allowedIPs.length === 0}
							<div class="mt-4 rounded-lg bg-gray-50 p-4 text-center dark:bg-gray-800">
								<div class="text-sm font-medium text-gray-700 dark:text-gray-300">
									No IP restrictions configured
								</div>

								<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									Access is currently allowed from any network.
								</div>
							</div>
						{:else}
							<div class="mt-4 space-y-2">
								{#each settings.security.allowedIPs as ip (ip)}
									<div class="flex items-center justify-between rounded-lg border border-gray-200 px-3 py-2 dark:border-gray-700">
										<span class="font-mono text-sm text-gray-700 dark:text-gray-300">
											{ip}
										</span>

										<Button size="xs" color="alternative">
											Remove
										</Button>
									</div>
								{/each}
							</div>
						{/if}
					</div>
				</div>
			{/if}

			<!-- INTEGRATIONS -->
			{#if activeTab === 'integrations'}
				<div class="space-y-4 pt-6">
					<div class="mb-6">
						<h3 class="section-title">
							Automation
						</h3>

						<p class="section-description">
							Control automatic synchronization and webhook processing.
						</p>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title flex items-center gap-2">
								Auto-sync orders

								{#if settings.integrations.autoSyncOrders}
									<Badge color="green">Active</Badge>
								{/if}
							</div>

							<div class="setting-description">
								Automatically synchronize incoming orders with the workspace.
							</div>
						</div>

						<Toggle
							bind:checked={settings.integrations.autoSyncOrders}
						/>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title flex items-center gap-2">
								Auto-sync inventory

								{#if settings.integrations.autoSyncInventory}
									<Badge color="green">Active</Badge>
								{/if}
							</div>

							<div class="setting-description">
								Keep inventory quantities synchronized automatically.
							</div>
						</div>

						<Toggle
							bind:checked={settings.integrations.autoSyncInventory}
						/>
					</div>

					<div class="setting-row">
						<div>
							<div class="setting-title flex items-center gap-2">
								Webhooks

								{#if settings.integrations.webhookEnabled}
									<Badge color="green">Enabled</Badge>
								{:else}
									<Badge color="gray">Disabled</Badge>
								{/if}
							</div>

							<div class="setting-description">
								Allow external services to send events into Efoka.
							</div>
						</div>

						<Toggle
							bind:checked={settings.integrations.webhookEnabled}
						/>
					</div>

					<div class="mt-6 grid gap-4 md:grid-cols-3">
						<div class="integration-card">
							<div class="integration-status">
								<span
									class:status-active={settings.integrations.autoSyncOrders}
									class="status-dot"
								></span>

								Orders
							</div>

							<div class="mt-2 text-xs text-gray-500 dark:text-gray-400">
								Order synchronization
							</div>
						</div>

						<div class="integration-card">
							<div class="integration-status">
								<span
									class:status-active={settings.integrations.autoSyncInventory}
									class="status-dot"
								></span>

								Inventory
							</div>

							<div class="mt-2 text-xs text-gray-500 dark:text-gray-400">
								Inventory synchronization
							</div>
						</div>

						<div class="integration-card">
							<div class="integration-status">
								<span
									class:status-active={settings.integrations.webhookEnabled}
									class="status-dot"
								></span>

								Webhooks
							</div>

							<div class="mt-2 text-xs text-gray-500 dark:text-gray-400">
								Event delivery
							</div>
						</div>
					</div>
				</div>
			{/if}
		</Card>

		<!-- Bottom save card -->
		<Card>
			<div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
				<div>
					<div class="text-sm font-semibold text-gray-900 dark:text-white">
						Workspace configuration
					</div>

					<p class="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
						Changes are currently kept in the page state until the
						server-side settings action is connected.
					</p>
				</div>

				<div class="flex items-center gap-3">
					{#if saved}
						<Badge color="green">
							Ready
						</Badge>
					{/if}

					<Button color="primary" disabled={saving} onclick={saveSettings}>
						{#if saving}
							<Spinner size="4" class="me-2" />
							Saving...
						{:else}
							Save changes
						{/if}
					</Button>
				</div>
			</div>
		</Card>
	</div>
</div>

<style>
	.settings-nav-item {
		border: 1px solid transparent;
		background: transparent;
	}

	.settings-nav-item:hover {
		background: rgb(249 250 251);
		border-color: rgb(229 231 235);
	}

	:global(.dark) .settings-nav-item:hover {
		background: rgb(31 41 55 / 0.6);
		border-color: rgb(55 65 81);
	}

	.settings-nav-active {
		background: rgb(239 246 255);
		border-color: rgb(191 219 254);
	}

	:global(.dark) .settings-nav-active {
		background: rgb(30 58 138 / 0.2);
		border-color: rgb(30 64 175);
	}

	.settings-icon {
		display: flex;
		height: 34px;
		width: 34px;
		flex-shrink: 0;
		align-items: center;
		justify-content: center;
		border-radius: 9px;
		background: rgb(243 244 246);
		color: rgb(107 114 128);
		font-size: 14px;
		font-weight: 700;
	}

	:global(.dark) .settings-icon {
		background: rgb(55 65 81);
		color: rgb(156 163 175);
	}

	.settings-icon-active {
		background: rgb(219 234 254);
		color: rgb(29 78 216);
	}

	:global(.dark) .settings-icon-active {
		background: rgb(30 64 175 / 0.4);
		color: rgb(147 197 253);
	}

	.section-title {
		font-size: 15px;
		font-weight: 700;
		color: rgb(17 24 39);
	}

	:global(.dark) .section-title {
		color: white;
	}

	.section-description {
		margin-top: 4px;
		font-size: 12px;
		line-height: 1.5;
		color: rgb(107 114 128);
	}

	:global(.dark) .section-description {
		color: rgb(156 163 175);
	}

	.setting-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 24px;
		border: 1px solid rgb(229 231 235);
		border-radius: 12px;
		padding: 18px;
		transition:
			border-color 160ms ease,
			background-color 160ms ease;
	}

	.setting-row:hover {
		border-color: rgb(209 213 219);
		background: rgb(249 250 251);
	}

	:global(.dark) .setting-row {
		border-color: rgb(55 65 81);
	}

	:global(.dark) .setting-row:hover {
		border-color: rgb(75 85 99);
		background: rgb(31 41 55 / 0.45);
	}

	.setting-title {
		font-size: 14px;
		font-weight: 600;
		color: rgb(17 24 39);
	}

	:global(.dark) .setting-title {
		color: white;
	}

	.setting-description {
		margin-top: 4px;
		max-width: 620px;
		font-size: 12px;
		line-height: 1.5;
		color: rgb(107 114 128);
	}

	:global(.dark) .setting-description {
		color: rgb(156 163 175);
	}

	.integration-card {
		border: 1px solid rgb(229 231 235);
		border-radius: 12px;
		padding: 16px;
	}

	:global(.dark) .integration-card {
		border-color: rgb(55 65 81);
	}

	.integration-status {
		display: flex;
		align-items: center;
		gap: 8px;
		font-size: 13px;
		font-weight: 600;
		color: rgb(17 24 39);
	}

	:global(.dark) .integration-status {
		color: white;
	}

	.status-dot {
		display: inline-block;
		height: 8px;
		width: 8px;
		border-radius: 9999px;
		background: rgb(156 163 175);
	}

	.status-active {
		background: rgb(34 197 94);
		box-shadow: 0 0 0 3px rgb(34 197 94 / 12%);
	}

	@media (max-width: 640px) {
		.setting-row {
			align-items: flex-start;
		}
	}
</style>