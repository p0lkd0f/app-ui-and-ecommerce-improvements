<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { dateTime, money, timeAgo } from '$lib/format';

	let { data, form } = $props();

	const detail = $derived(data.detail);

	let priorityFilter = $state('all');
	let statusFilter = $state('all');
	let selectedOrders = $state<Set<number>>(new Set());

	const filteredQueue = $derived(
		data.queue.filter((order: any) => {
			const matchesPriority =
				priorityFilter === 'all' ||
				String(order.priority ?? 'medium').toLowerCase() === priorityFilter;

			const matchesStatus =
				statusFilter === 'all' ||
				String(order.confirmation ?? '').toLowerCase() === statusFilter;

			return matchesPriority && matchesStatus;
		})
	);

	const selectedCount = $derived(selectedOrders.size);

	const allVisibleSelected = $derived(
		filteredQueue.length > 0 &&
			filteredQueue.every((order: any) => selectedOrders.has(order.id))
	);

	function toggleOrderSelection(orderId: number) {
		const next = new Set(selectedOrders);

		if (next.has(orderId)) {
			next.delete(orderId);
		} else {
			next.add(orderId);
		}

		selectedOrders = next;
	}

	function toggleAllVisible(event: Event) {
		const checkbox = event.currentTarget as HTMLInputElement;
		const next = new Set(selectedOrders);

		if (checkbox.checked) {
			for (const order of filteredQueue) {
				next.add(order.id);
			}
		} else {
			for (const order of filteredQueue) {
				next.delete(order.id);
			}
		}

		selectedOrders = next;
	}

	function bulkConfirm() {
		// Bulk confirmation still requires a corresponding server action.
		// The existing ?/log action is intentionally left unchanged.
	}

	function autoAssign() {
		// Auto-assignment remains handled by the existing application workflow.
	}
</script>

{#if form?.success}
	<div class="notice" role="status">{form.success}</div>
{/if}

{#if form?.error}
	<div class="error" role="alert">{form.error}</div>
{/if}

<div class="confirmation-layout">
	<!-- Queue -->
	<section class="panel queue-panel">
		<div class="panel-head">
			<div class="queue-heading">
				<div>
					<div class="eyebrow">Operations</div>
					<h2>Call Queue</h2>
					<p class="hint">
						{filteredQueue.length} of {data.queue.length} orders waiting
					</p>
				</div>

				<div class="queue-actions">
					{#if selectedCount > 0}
						<button
							type="button"
							class="small primary"
							onclick={bulkConfirm}
						>
							Confirm Selected ({selectedCount})
						</button>
					{/if}

					<button type="button" class="small" onclick={autoAssign}>
						Auto-assign
					</button>

					<button type="button" class="small">
						Export list
					</button>
				</div>
			</div>

			<div class="advanced-filter">
				<div class="filter-group">
					<label for="priority-filter">Priority</label>

					<select id="priority-filter" bind:value={priorityFilter}>
						<option value="all">All Priorities</option>
						<option value="high">High</option>
						<option value="medium">Medium</option>
						<option value="low">Low</option>
					</select>
				</div>

				<div class="filter-group">
					<label for="status-filter">Status</label>

					<select id="status-filter" bind:value={statusFilter}>
						<option value="all">All Status</option>
						<option value="pending">Pending</option>
						<option value="confirmed">Confirmed</option>
						<option value="unreachable">Unreachable</option>
					</select>
				</div>
			</div>
		</div>

		<div class="table-wrap">
			<table>
				<thead>
					<tr>
						<th class="checkbox-cell">
							<input
								id="select-all-orders"
								type="checkbox"
								checked={allVisibleSelected}
								onchange={toggleAllVisible}
								aria-label="Select all visible orders"
							/>
						</th>

						<th>Order</th>
						<th>Customer</th>
						<th>Age</th>
						<th>State</th>
						<th class="num">Total</th>
						<th></th>
					</tr>
				</thead>

				<tbody>
					{#each filteredQueue as order (order.id)}
						<tr
							class:selected-row={detail?.order.id === order.id}
						>
							<td class="checkbox-cell">
								<input
									type="checkbox"
									checked={selectedOrders.has(order.id)}
									onchange={() => toggleOrderSelection(order.id)}
									aria-label={`Select order ${order.reference}`}
								/>
							</td>

							<td>
								<a
									class="mono order-reference"
									href="/orders/{order.id}"
								>
									{order.reference}
								</a>
							</td>

							<td>
								<div class="customer-name">
									{order.customer_name}
								</div>

								<div class="muted tiny mono">
									{order.customer_phone}
									<span aria-hidden="true"> · </span>
									{order.customer_city}
								</div>
							</td>

							<td class="tiny muted">
								{timeAgo(order.created_at)}
							</td>

							<td>
								<Pill
									status={order.confirmation}
									text={`${order.confirmation} · ${order.call_attempts}`}
								/>
							</td>

							<td class="num">
								{money(order.total)}
							</td>

							<td class="action-cell">
								<a
									class="btn small"
									href="/confirmation?order={order.id}"
								>
									Open
								</a>
							</td>
						</tr>
					{:else}
						<tr>
							<td colspan="7" class="empty">
								<div class="empty-state">
									<div class="empty-icon">✓</div>
									<strong>Nothing left to confirm</strong>
									<span class="muted tiny">
										No orders match the current filters.
									</span>
								</div>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>
	</section>

	<!-- Detail column -->
	<aside class="detail-column">
		{#if detail}
			<section class="panel calling-panel">
				<div class="panel-head">
					<div>
						<div class="eyebrow">Current call</div>
						<h2>Calling {detail.order.customer_name}</h2>
					</div>

					<Pill
						status={detail.order.confirmation}
					/>
				</div>

				<div class="panel-body stack">
					<div class="customer-contact">
						<div class="phone-number mono">
							{detail.order.customer_phone}
						</div>

						<div class="muted tiny">
							{detail.order.customer_city}
							<span aria-hidden="true"> · </span>
							Order {detail.order.reference}
						</div>
					</div>

					<div class="order-summary">
						<div class="section-label">Order summary</div>

						<div class="stack tiny">
							{#each detail.items as item (item.id)}
								<div class="spread">
									<span>
										{item.quantity} × {item.name}
									</span>

									<span>
										{money(item.quantity * item.unit_price)}
									</span>
								</div>
							{/each}

							<div class="summary-total">
								<span>COD total</span>
								<strong>{money(detail.order.total)}</strong>
							</div>
						</div>
					</div>

					<form method="POST" action="?/log" class="call-form">
						<input
							type="hidden"
							name="orderId"
							value={detail.order.id}
						/>

						<div class="field">
							<label for="call-notes">Call notes</label>

							<textarea
								id="call-notes"
								name="notes"
								rows="3"
								placeholder="Add notes from this call..."
							></textarea>
						</div>

						<button
							type="submit"
							class="success confirm-button"
							name="outcome"
							value="confirmed"
						>
							Confirm order
						</button>

						<div class="action-grid">
							<button
								type="submit"
								class="small"
								name="outcome"
								value="no_answer"
							>
								No answer
							</button>

							<button
								type="submit"
								class="small"
								name="outcome"
								value="scheduled"
							>
								Call later
							</button>

							<button
								type="submit"
								class="danger small"
								name="outcome"
								value="cancelled"
							>
								Cancel
							</button>

							<button
								type="submit"
								class="danger small"
								name="outcome"
								value="wrong_number"
							>
								Wrong number
							</button>
						</div>
					</form>

					<a
						class="btn small full-width"
						href="/orders/{detail.order.id}"
					>
						Open full order
					</a>
				</div>
			</section>

			<section class="panel">
				<div class="panel-head">
					<div>
						<div class="eyebrow">History</div>
						<h2>Previous attempts</h2>
					</div>

					<span class="pill blue">
						{detail.calls.length}
					</span>
				</div>

				<div class="panel-body">
					<div class="attempt-list">
						{#each detail.calls as call (call.id)}
							<div class="attempt">
								<div>
									<strong>
										{call.outcome.replace('_', ' ')}
									</strong>

									<div class="muted tiny">
										{call.agent ?? 'system'}
									</div>
								</div>

								<div class="muted tiny">
									{dateTime(call.created_at)}
								</div>
							</div>
						{:else}
							<div class="empty-mini">
								<span class="muted">
									First attempt.
								</span>
							</div>
						{/each}
					</div>
				</div>
			</section>
		{/if}

		<section class="panel">
			<div class="panel-head">
				<div>
					<div class="eyebrow">Analytics</div>
					<h2>Call outcomes</h2>
				</div>

				<span class="pill gradient">7 days</span>
			</div>

			<div class="panel-body">
				<div class="stats-list">
					{#each data.stats as stat (stat.outcome)}
						<div class="stat-row">
							<div class="stat-name">
								<span class="status-dot"></span>
								{stat.outcome.replace('_', ' ')}
							</div>

							<strong>{stat.count}</strong>
						</div>
					{:else}
						<div class="empty-mini">
							<span class="muted">No call activity yet.</span>
						</div>
					{/each}
				</div>
			</div>
		</section>
	</aside>
</div>

<style>
	.confirmation-layout {
		display: grid;
		grid-template-columns: minmax(0, 2fr) minmax(320px, 1fr);
		gap: 18px;
		align-items: start;
	}

	.queue-panel {
		min-width: 0;
	}

	.detail-column {
		display: flex;
		flex-direction: column;
		gap: 18px;
		min-width: 0;
	}

	.queue-heading {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 20px;
		margin-bottom: 18px;
	}

	.queue-actions {
		display: flex;
		flex-wrap: wrap;
		gap: 8px;
		justify-content: flex-end;
	}

	.eyebrow {
		margin-bottom: 4px;
		font-size: 10px;
		font-weight: 700;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		color: var(--brand);
	}

	.queue-heading h2,
	.panel-head h2 {
		margin: 0;
	}

	.queue-heading .hint {
		margin-top: 4px;
	}

	.advanced-filter {
		display: grid;
		grid-template-columns: repeat(2, minmax(160px, 1fr));
		gap: 12px;
	}

	.filter-group {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.filter-group label,
	.field label {
		font-size: 12px;
		font-weight: 600;
		color: var(--muted);
	}

	.table-wrap {
		overflow-x: auto;
	}

	.checkbox-cell {
		width: 44px;
		text-align: center;
	}

	.checkbox-cell input {
		width: 16px;
		height: 16px;
	}

	.selected-row {
		background: var(--brand-soft);
	}

	.order-reference {
		font-weight: 600;
	}

	.customer-name {
		font-weight: 550;
	}

	.action-cell {
		white-space: nowrap;
	}

	.customer-contact {
		padding: 14px;
		border: 1px solid var(--line);
		border-radius: 12px;
		background: var(--brand-soft);
	}

	.phone-number {
		font-size: 20px;
		font-weight: 700;
	}

	.order-summary {
		padding-top: 4px;
	}

	.section-label {
		margin-bottom: 10px;
		font-size: 11px;
		font-weight: 700;
		text-transform: uppercase;
		letter-spacing: 0.06em;
		color: var(--muted);
	}

	.summary-total {
		display: flex;
		justify-content: space-between;
		padding-top: 10px;
		margin-top: 8px;
		border-top: 1px solid var(--line);
	}

	.call-form {
		display: flex;
		flex-direction: column;
		gap: 12px;
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.field textarea {
		resize: vertical;
		min-height: 78px;
	}

	.confirm-button {
		width: 100%;
		justify-content: center;
		padding: 11px 14px;
	}

	.action-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 8px;
	}

	.full-width {
		width: 100%;
		justify-content: center;
	}

	.attempt-list,
	.stats-list {
		display: flex;
		flex-direction: column;
		gap: 10px;
	}

	.attempt {
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 12px;
		padding: 10px 0;
		border-bottom: 1px solid var(--line);
	}

	.attempt:last-child {
		border-bottom: 0;
	}

	.stat-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		padding: 10px 0;
		border-bottom: 1px solid var(--line);
	}

	.stat-row:last-child {
		border-bottom: 0;
	}

	.stat-name {
		display: flex;
		align-items: center;
		gap: 8px;
		text-transform: capitalize;
	}

	.status-dot {
		width: 7px;
		height: 7px;
		border-radius: 50%;
		background: var(--brand);
	}

	.empty-state {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 6px;
		padding: 32px 12px;
	}

	.empty-icon {
		display: grid;
		place-items: center;
		width: 36px;
		height: 36px;
		margin-bottom: 4px;
		border-radius: 50%;
		background: var(--brand-soft);
		color: var(--brand);
		font-weight: 700;
	}

	.empty-mini {
		padding: 12px 0;
		text-align: center;
	}

	@media (max-width: 1100px) {
		.confirmation-layout {
			grid-template-columns: 1fr;
		}

		.detail-column {
			display: grid;
			grid-template-columns: repeat(2, minmax(0, 1fr));
		}
	}

	@media (max-width: 760px) {
		.queue-heading {
			flex-direction: column;
		}

		.queue-actions {
			justify-content: flex-start;
		}

		.advanced-filter,
		.detail-column {
			grid-template-columns: 1fr;
		}
	}
</style>