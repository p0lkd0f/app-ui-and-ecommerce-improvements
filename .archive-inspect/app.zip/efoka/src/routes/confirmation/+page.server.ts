import { fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { confirmationQueue, getOrder, recordConfirmation } from '$lib/server/repo';
import { oneOf, positiveId } from '$lib/server/validation';

const OUTCOMES = ['confirmed', 'no_answer', 'cancelled', 'scheduled', 'wrong_number'] as const;
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
	const queue = await confirmationQueue();
	const selectedId = Number(url.searchParams.get('order') ?? queue[0]?.id ?? 0);
	const [detail, stats] = await Promise.all([
		selectedId ? getOrder(selectedId) : null,
		query<{ outcome: string; count: number }>(
			"SELECT outcome, count(*)::int AS count FROM call_attempts WHERE created_at > now() - interval '7 days' GROUP BY outcome ORDER BY count DESC"
		)
	]);
	return { queue, detail, stats };
};

export const actions: Actions = {
	log: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'confirmation.handle')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const orderId = positiveId(form.get('orderId'));
		const outcome = oneOf(form.get('outcome'), OUTCOMES, 'call outcome');
		const notes = typeof form.get('notes') === 'string' ? String(form.get('notes')).trim().slice(0, 2000) : '';
		await recordConfirmation(orderId, outcome, locals.user.id, locals.user.name, notes);
		return { success: `Logged: ${outcome.replace('_', ' ')}` };
	}
};
