<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { money } from '$lib/format';

	type AnalyticsKpis = {
		totalRevenue?: number | null;
		revenueGrowth?: number | null;
		totalOrders?: number | null;
		orderGrowth?: number | null;
		averageOrderValue?: number | null;
		aovGrowth?: number | null;
		conversionRate?: number | null;
		conversionGrowth?: number | null;
		customerLifetimeValue?: number | null;
		clvGrowth?: number | null;
		returnRate?: number | null;
		returnGrowth?: number | null;
		profitMargin?: number | null;
		profitGrowth?: number | null;
		totalCustomers?: number | null;
		newCustomers?: number | null;
	};

	type RevenuePoint = { label: string; revenue: number; orders: number; profit?: number | null };
	type Campaign = { id: string | number; name: string; type?: string | null; status: string; budget?: number | null; spent?: number | null; conversions?: number | null; revenue?: number | null; roi?: number | null };
	type Product = { id?: string | number; name: string; category?: string | null; sales: number; revenue: number; profit?: number | null; growth?: number | null };
	type GeoPerformance = { city: string; orders: number; revenue: number; deliveryRate?: number | null };
	type ChannelPerformance = { channel: string; orders: number; revenue: number; conversionRate?: number | null; averageOrderValue?: number | null };
	type FunnelStage = { stage: string; count: number; conversion?: number | null };
	type Cohort = { cohort: string; size: number; periods: Array<number | null> };

	let { data } = $props();

	// The server loader returns AnalyticsOverview directly. Build the page model
	// from those real fields instead of expecting a nonexistent data.analytics object.
	let analytics = $derived({
		lastUpdated: null as string | null,
		kpis: {
			totalRevenue: Number(data.summary?.revenue30 ?? 0),
			revenueGrowth: null,
			totalOrders: data.monthly?.reduce((sum: number, item: { orders: number }) => sum + Number(item.orders ?? 0), 0) ?? 0,
			orderGrowth: null,
			averageOrderValue: (() => {
				const orders = data.monthly?.reduce((sum: number, item: { orders: number }) => sum + Number(item.orders ?? 0), 0) ?? 0;
				return orders ? Number(data.summary?.revenue30 ?? 0) / orders : 0;
			})(),
			aovGrowth: null,
			conversionRate: null,
			conversionGrowth: null,
			customerLifetimeValue: null,
			clvGrowth: null,
			profitMargin: (() => {
				const revenue = Number(data.summary?.revenue30 ?? 0);
				return revenue ? (Number(data.summary?.profit30 ?? 0) / revenue) * 100 : 0;
			})(),
			returnRate: null,
			returnGrowth: null,
			profitGrowth: null,
			totalCustomers: null,
			newCustomers: null
		} satisfies AnalyticsKpis,
		revenue: (data.monthly ?? []).map((item: { month: string; revenue: number; profit: number; orders: number }) => ({
			label: item.month,
			revenue: Number(item.revenue ?? 0),
			profit: Number(item.profit ?? 0),
			orders: Number(item.orders ?? 0)
		} satisfies RevenuePoint)),
		campaigns: [] as Campaign[],
		topProducts: (data.products ?? []).map((item: { name: string; sku: string; units: number; revenue: number; margin: number }) => ({
			id: item.sku,
			name: item.name,
			sales: Number(item.units ?? 0),
			revenue: Number(item.revenue ?? 0),
			profit: Number(item.margin ?? 0),
			category: null,
			growth: null
		} satisfies Product)),
		geoPerformance: (data.summary?.topCities ?? []).map((item: { city: string; orders: number; revenue: number; delivered: number }) => ({
			city: item.city,
			orders: Number(item.orders ?? 0),
			revenue: Number(item.revenue ?? 0),
			deliveryRate: item.orders ? (Number(item.delivered ?? 0) / Number(item.orders)) * 100 : 0
		} satisfies GeoPerformance)),
		channelPerformance: (data.sources ?? []).map((item: { source: string; orders: number; revenue: number; delivered: number }) => ({
			channel: item.source,
			orders: Number(item.orders ?? 0),
			revenue: Number(item.revenue ?? 0),
			conversionRate: item.orders ? (Number(item.delivered ?? 0) / Number(item.orders)) * 100 : 0,
			averageOrderValue: item.orders ? Number(item.revenue ?? 0) / Number(item.orders) : 0
		} satisfies ChannelPerformance)),
		funnel: (data.summary?.statusBreakdown ?? []).map((item: { status: string; count: number }) => ({
			stage: item.status,
			count: Number(item.count ?? 0),
			conversion: null
		} satisfies FunnelStage)),
		cohorts: [] as Cohort[]
	});

	let timeRange = $state('30d');
	let storeFilter = $state('all');
	let channelFilter = $state('all');
	let compareWith = $state('previous');
	let isRefreshing = $state(false);

	let kpis = $derived(analytics.kpis);
	let revenueData = $derived(analytics.revenue);
	let campaigns = $derived(analytics.campaigns);
	let topProducts = $derived(analytics.topProducts);
	let geoPerformance = $derived(analytics.geoPerformance);
	let channelPerformance = $derived(analytics.channelPerformance);
	let funnelData = $derived(analytics.funnel);
	let cohortData = $derived(analytics.cohorts);

	let maxRevenue = $derived(Math.max(1, ...revenueData.map((item) => Number(item.revenue) || 0)));
	let maxFunnel = $derived(Math.max(1, ...funnelData.map((item) => Number(item.count) || 0)));

	function formatNumber(value: number | null | undefined): string { return Number(value ?? 0).toLocaleString(); }
	function formatPercent(value: number | null | undefined, digits = 1): string {
		if (value === null || value === undefined || Number.isNaN(Number(value))) return '—';
		return `${Number(value).toFixed(digits)}%`;
	}
	function growthText(value: number | null | undefined): string {
		if (value === null || value === undefined || Number.isNaN(Number(value))) return 'No comparison data';
		const numeric = Number(value);
		if (numeric === 0) return 'No change';
		return `${numeric > 0 ? '↑' : '↓'} ${Math.abs(numeric).toFixed(1)}%`;
	}
	function growthClass(value: number | null | undefined): string {
		if (value === null || value === undefined) return 'muted';
		return Number(value) >= 0 ? 'positive' : 'negative';
	}
	function revenueWidth(value: number): string { return `${Math.min(100, Math.max(0, (value / maxRevenue) * 100))}%`; }
	function funnelWidth(value: number): string { return `${Math.min(100, Math.max(0, (value / maxFunnel) * 100))}%`; }

	async function refreshAnalytics() {
		isRefreshing = true;
		location.reload();
	}

	function exportReport(format: 'csv') {
		const params = new URLSearchParams({ format, range: timeRange, store: storeFilter, channel: channelFilter, compare: compareWith });
		location.href = `/api/analytics?${params.toString()}`;
	}
</script>

{#if !analytics}
	<div class="panel empty-state">
		<div class="panel-body">
			<div class="empty-icon">◎</div>
			<h2>Analytics unavailable</h2>
			<p class="muted">
				No analytics response was provided by the API/DB loader.
			</p>
			<button class="primary" type="button" onclick={refreshAnalytics}>
				Retry
			</button>
		</div>
	</div>
{:else}
	<!-- Header -->
	<div class="page-header">
		<div>
			<h1>Analytics</h1>
			<p class="muted">
				Live business performance from your connected data sources.
			</p>

			{#if analytics.lastUpdated}
				<div class="tiny muted">
					Last updated {analytics.lastUpdated}
				</div>
			{/if}
		</div>

		<div class="row">
			<button
				class="small"
				type="button"
				onclick={refreshAnalytics}
				disabled={isRefreshing}
			>
				{isRefreshing ? 'Refreshing…' : '↻ Refresh'}
			</button>

			<button
				class="small"
				type="button"
				onclick={() => exportReport('csv')}
			>
				Export CSV
			</button>

		</div>
	</div>

	<!-- Filters -->
	<div class="panel filters-panel">
		<div class="panel-body">
			<div class="advanced-filter">
				<div class="filter-group">
					<label for="analytics-range">Time Range</label>
					<select id="analytics-range" bind:value={timeRange}>
						<option value="7d">Last 7 Days</option>
						<option value="30d">Last 30 Days</option>
						<option value="90d">Last 90 Days</option>
						<option value="1y">Last Year</option>
						<option value="custom">Custom Range</option>
					</select>
				</div>

				<div class="filter-group">
					<label for="analytics-store">Store</label>
					<select id="analytics-store" bind:value={storeFilter}>
						<option value="all">All Stores</option>
						<option value="main">Main Store</option>
						<option value="outlet">Outlet Store</option>
					</select>
				</div>

				<div class="filter-group">
					<label for="analytics-channel">Channel</label>
					<select id="analytics-channel" bind:value={channelFilter}>
						<option value="all">All Channels</option>
						<option value="whatsapp">WhatsApp</option>
						<option value="website">Website</option>
						<option value="instagram">Instagram</option>
						<option value="phone">Phone Orders</option>
						<option value="marketplace">Marketplace</option>
					</select>
				</div>

				<div class="filter-group">
					<label for="analytics-compare">Compare With</label>
					<select id="analytics-compare" bind:value={compareWith}>
						<option value="previous">Previous Period</option>
						<option value="year">Same Period Last Year</option>
					</select>
				</div>
			</div>
		</div>
	</div>

	<!-- Primary KPIs -->
	<div class="grid cols-4">
		<div class="panel stat hover-lift">
			<div class="panel-body">
				<div class="label">Revenue</div>
				<div class="value">
					{money(kpis?.totalRevenue ?? 0)}
				</div>

				<div class:positive={growthClass(kpis?.revenueGrowth) === 'positive'}
					class:negative={growthClass(kpis?.revenueGrowth) === 'negative'}
					class="foot">
					{growthText(kpis?.revenueGrowth)}
				</div>
			</div>
		</div>

		<div class="panel stat hover-lift">
			<div class="panel-body">
				<div class="label">Orders</div>
				<div class="value">
					{formatNumber(kpis?.totalOrders)}
				</div>

				<div
					class:positive={growthClass(kpis?.orderGrowth) === 'positive'}
					class:negative={growthClass(kpis?.orderGrowth) === 'negative'}
					class="foot"
				>
					{growthText(kpis?.orderGrowth)}
				</div>
			</div>
		</div>

		<div class="panel stat hover-lift">
			<div class="panel-body">
				<div class="label">Average Order Value</div>
				<div class="value">
					{money(kpis?.averageOrderValue ?? 0)}
				</div>

				<div
					class:positive={growthClass(kpis?.aovGrowth) === 'positive'}
					class:negative={growthClass(kpis?.aovGrowth) === 'negative'}
					class="foot"
				>
					{growthText(kpis?.aovGrowth)}
				</div>
			</div>
		</div>

		<div class="panel stat hover-lift">
			<div class="panel-body">
				<div class="label">Conversion Rate</div>
				<div class="value">
					{formatPercent(kpis?.conversionRate)}
				</div>

				<div
					class:positive={growthClass(kpis?.conversionGrowth) === 'positive'}
					class:negative={growthClass(kpis?.conversionGrowth) === 'negative'}
					class="foot"
				>
					{growthText(kpis?.conversionGrowth)}
				</div>
			</div>
		</div>
	</div>

	<!-- Secondary KPIs -->
	<div class="grid cols-4 section">
		{#if kpis?.customerLifetimeValue !== null && kpis?.customerLifetimeValue !== undefined}
			<div class="panel stat">
				<div class="panel-body">
					<div class="label">Customer Lifetime Value</div>
					<div class="value">
						{money(kpis.customerLifetimeValue)}
					</div>
					<div
						class:positive={growthClass(kpis.clvGrowth) === 'positive'}
						class:negative={growthClass(kpis.clvGrowth) === 'negative'}
						class="foot"
					>
						{growthText(kpis.clvGrowth)}
					</div>
				</div>
			</div>
		{/if}

		{#if kpis?.returnRate !== null && kpis?.returnRate !== undefined}
			<div class="panel stat">
				<div class="panel-body">
					<div class="label">Return Rate</div>
					<div class="value">
						{formatPercent(kpis.returnRate)}
					</div>
					<div
						class:positive={growthClass(kpis.returnGrowth) === 'positive'}
						class:negative={growthClass(kpis.returnGrowth) === 'negative'}
						class="foot"
					>
						{growthText(kpis.returnGrowth)}
					</div>
				</div>
			</div>
		{/if}

		{#if kpis?.profitMargin !== null && kpis?.profitMargin !== undefined}
			<div class="panel stat">
				<div class="panel-body">
					<div class="label">Profit Margin</div>
					<div class="value">
						{formatPercent(kpis.profitMargin)}
					</div>
					<div
						class:positive={growthClass(kpis.profitGrowth) === 'positive'}
						class:negative={growthClass(kpis.profitGrowth) === 'negative'}
						class="foot"
					>
						{growthText(kpis.profitGrowth)}
					</div>
				</div>
			</div>
		{/if}

		{#if kpis?.totalCustomers !== null && kpis?.totalCustomers !== undefined}
			<div class="panel stat">
				<div class="panel-body">
					<div class="label">Customers</div>
					<div class="value">
						{formatNumber(kpis.totalCustomers)}
					</div>

					{#if kpis.newCustomers !== null && kpis.newCustomers !== undefined}
						<div class="foot">
							{formatNumber(kpis.newCustomers)} new
						</div>
					{/if}
				</div>
			</div>
		{/if}
	</div>

	<!-- Revenue -->
	{#if revenueData.length}
		<div class="panel section">
			<div class="panel-head">
				<div>
					<h2>Revenue & Orders</h2>
					<div class="tiny muted">
						Data returned by the analytics source
					</div>
				</div>

				<div class="row">
					<span class="pill green">Revenue</span>
					<span class="pill blue">Orders</span>
				</div>
			</div>

			<div class="panel-body">
				<div class="revenue-chart">
					{#each revenueData as point (point.label)}
						<div class="revenue-column">
							<div class="revenue-value">
								{money(point.revenue)}
							</div>

							<div class="revenue-track">
								<div
									class="revenue-bar"
									style={`height: ${revenueWidth(Number(point.revenue) || 0)}`}
									title={`${point.label}: ${money(point.revenue)}`}
								></div>
							</div>

							<div class="tiny muted">
								{point.label}
							</div>

							<div class="tiny">
								{formatNumber(point.orders)} orders
							</div>
						</div>
					{/each}
				</div>
			</div>
		</div>
	{/if}

	<!-- Campaign Performance -->
	{#if campaigns.length}
		<div class="panel section">
			<div class="panel-head">
				<div class="spread">
					<h2>Campaign Performance</h2>
					<a class="hint" href="/campaigns">Manage campaigns →</a>
				</div>
			</div>

			<div class="panel-body table-scroll">
				<table>
					<thead>
						<tr>
							<th>Campaign</th>
							<th>Type</th>
							<th>Status</th>
							<th>Budget</th>
							<th>Spent</th>
							<th>Conversions</th>
							<th>Revenue</th>
							<th>ROI</th>
						</tr>
					</thead>

					<tbody>
						{#each campaigns as campaign (campaign.id)}
							<tr>
								<td>
									<strong>{campaign.name}</strong>
								</td>

								<td>
									{#if campaign.type}
										<span class="pill blue">
											{campaign.type}
										</span>
									{:else}
										<span class="muted">—</span>
									{/if}
								</td>

								<td>
									<Pill status={campaign.status} />
								</td>

								<td>
									{campaign.budget !== null &&
									campaign.budget !== undefined
										? money(campaign.budget)
										: '—'}
								</td>

								<td>
									{campaign.spent !== null &&
									campaign.spent !== undefined
										? money(campaign.spent)
										: '—'}
								</td>

								<td>
									{formatNumber(campaign.conversions)}
								</td>

								<td>
									{campaign.revenue !== null &&
									campaign.revenue !== undefined
										? money(campaign.revenue)
										: '—'}
								</td>

								<td class="text-green">
									{formatPercent(campaign.roi)}
								</td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>
		</div>
	{/if}

	<!-- Products + Geography -->
	<div class="grid cols-2 section">
		{#if topProducts.length}
			<div class="panel">
				<div class="panel-head">
					<div class="spread">
						<h2>Top Products</h2>
						<a class="hint" href="/products">View all →</a>
					</div>
				</div>

				<div class="panel-body table-scroll">
					<table>
						<thead>
							<tr>
								<th>Product</th>
								<th>Sales</th>
								<th>Revenue</th>
								<th>Profit</th>
								<th>Growth</th>
							</tr>
						</thead>

						<tbody>
							{#each topProducts as product (product.id ?? product.name)}
								<tr>
									<td>
										<strong>{product.name}</strong>

										{#if product.category}
											<div class="tiny muted">
												{product.category}
											</div>
										{/if}
									</td>

									<td>
										{formatNumber(product.sales)}
									</td>

									<td>
										{money(product.revenue)}
									</td>

									<td>
										{product.profit !== null &&
										product.profit !== undefined
											? money(product.profit)
											: '—'}
									</td>

									<td
										class:positive={Number(product.growth ?? 0) >= 0}
										class:negative={Number(product.growth ?? 0) < 0}
									>
										{formatPercent(product.growth)}
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
			</div>
		{/if}

		{#if geoPerformance.length}
			<div class="panel">
				<div class="panel-head">
					<h2>Geographic Performance</h2>
				</div>

				<div class="panel-body table-scroll">
					<table>
						<thead>
							<tr>
								<th>City</th>
								<th>Orders</th>
								<th>Revenue</th>
								<th>Delivery</th>
							</tr>
						</thead>

						<tbody>
							{#each geoPerformance as geo (geo.city)}
								<tr>
									<td>
										<strong>{geo.city}</strong>
									</td>

									<td>
										{formatNumber(geo.orders)}
									</td>

									<td>
										{money(geo.revenue)}
									</td>

									<td>
										{#if geo.deliveryRate !== null &&
										geo.deliveryRate !== undefined}
											<div class="metric">
												<div class="bar-track">
													<div
														class="bar-fill"
														style={`width: ${Math.min(
															100,
															Math.max(0, Number(geo.deliveryRate))
														)}%`}
													></div>
												</div>

												<span class="tiny">
													{formatPercent(geo.deliveryRate)}
												</span>
											</div>
										{:else}
											<span class="muted">—</span>
										{/if}
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
			</div>
		{/if}
	</div>

	<!-- Channels + Funnel -->
	<div class="grid cols-2 section">
		{#if channelPerformance.length}
			<div class="panel">
				<div class="panel-head">
					<h2>Channel Performance</h2>
				</div>

				<div class="panel-body table-scroll">
					<table>
						<thead>
							<tr>
								<th>Channel</th>
								<th>Orders</th>
								<th>Revenue</th>
								<th>Conversion</th>
								<th>AOV</th>
							</tr>
						</thead>

						<tbody>
							{#each channelPerformance as channel (channel.channel)}
								<tr>
									<td>
										<strong>{channel.channel}</strong>
									</td>

									<td>
										{formatNumber(channel.orders)}
									</td>

									<td>
										{money(channel.revenue)}
									</td>

									<td>
										{formatPercent(channel.conversionRate)}
									</td>

									<td>
										{channel.averageOrderValue !== null &&
										channel.averageOrderValue !== undefined
											? money(channel.averageOrderValue)
											: '—'}
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
			</div>
		{/if}

		{#if funnelData.length}
			<div class="panel">
				<div class="panel-head">
					<h2>Conversion Funnel</h2>
				</div>

				<div class="panel-body">
					<div class="funnel">
						{#each funnelData as stage (stage.stage)}
							<div class="funnel-row">
								<div class="funnel-label">
									<strong>{stage.stage}</strong>
								</div>

								<div class="funnel-track">
									<div
										class="funnel-fill"
										style={`width: ${funnelWidth(Number(stage.count) || 0)}`}
									></div>
								</div>

								<div class="funnel-value">
									{formatNumber(stage.count)}
								</div>

								<div class="funnel-percent">
									{formatPercent(stage.conversion)}
								</div>
							</div>
						{/each}
					</div>
				</div>
			</div>
		{/if}
	</div>

	<!-- Cohorts -->
	{#if cohortData.length}
		<div class="panel section">
			<div class="panel-head">
				<div>
					<h2>Customer Retention</h2>
					<div class="tiny muted">
						Cohort retention returned by the analytics source.
					</div>
				</div>
			</div>

			<div class="panel-body table-scroll">
				<table>
					<thead>
						<tr>
							<th>Cohort</th>
							<th>Size</th>

							{#if cohortData[0]?.periods}
								{#each cohortData[0].periods as _, index}
									<th>Period {index + 1}</th>
								{/each}
							{/if}
						</tr>
					</thead>

					<tbody>
						{#each cohortData as cohort (cohort.cohort)}
							<tr>
								<td>
									<strong>{cohort.cohort}</strong>
								</td>

								<td>
									{formatNumber(cohort.size)}
								</td>

								{#each cohort.periods as value}
									<td class="text-green">
										{value === null || value === undefined
											? '—'
											: formatPercent(value)}
									</td>
								{/each}
							</tr>
						{/each}
					</tbody>
				</table>
			</div>
		</div>
	{/if}
{/if}

<style>
	.page-header {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 20px;
		margin-bottom: 18px;
	}

	.page-header h1 {
		margin: 0 0 4px;
	}

	.section {
		margin-top: 18px;
	}

	.filters-panel {
		margin-bottom: 18px;
	}

	.advanced-filter {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
		gap: 12px;
	}

	.filter-group {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.filter-group label {
		font-size: 12px;
		font-weight: 550;
		color: var(--muted);
	}

	.text-green {
		color: var(--green);
		font-weight: 550;
	}

	.positive {
		color: var(--green);
	}

	.negative {
		color: var(--red, #dc2626);
	}

	.empty-state {
		min-height: 360px;
		display: grid;
		place-items: center;
		text-align: center;
	}

	.empty-icon {
		font-size: 42px;
		margin-bottom: 12px;
		opacity: 0.5;
	}

	.revenue-chart {
		min-height: 320px;
		display: flex;
		align-items: flex-end;
		gap: 12px;
		padding: 20px 8px 8px;
		overflow-x: auto;
	}

	.revenue-column {
		min-width: 70px;
		flex: 1;
		min-height: 270px;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		gap: 5px;
		text-align: center;
	}

	.revenue-value {
		font-size: 11px;
		font-weight: 600;
	}

	.revenue-track {
		height: 210px;
		display: flex;
		align-items: flex-end;
		justify-content: center;
	}

	.revenue-bar {
		width: min(42px, 70%);
		min-height: 3px;
		border-radius: 7px 7px 3px 3px;
		background: var(--brand);
		transition:
			height 0.25s ease,
			opacity 0.2s ease;
	}

	.revenue-bar:hover {
		opacity: 0.75;
	}

	.table-scroll {
		overflow-x: auto;
	}

	.metric {
		display: flex;
		align-items: center;
		gap: 8px;
		min-width: 120px;
	}

	.bar-track {
		height: 7px;
		flex: 1;
		min-width: 60px;
		border-radius: 99px;
		background: var(--line);
		overflow: hidden;
	}

	.bar-fill {
		height: 100%;
		border-radius: inherit;
		background: var(--brand);
	}

	.funnel {
		display: flex;
		flex-direction: column;
		gap: 12px;
	}

	.funnel-row {
		display: grid;
		grid-template-columns: 150px minmax(100px, 1fr) 90px 60px;
		align-items: center;
		gap: 12px;
		padding: 8px;
		border-radius: 8px;
	}

	.funnel-row:hover {
		background: var(--brand-soft);
	}

	.funnel-track {
		height: 10px;
		border-radius: 99px;
		background: var(--line);
		overflow: hidden;
	}

	.funnel-fill {
		height: 100%;
		border-radius: inherit;
		background: var(--brand);
		transition: width 0.25s ease;
	}

	.funnel-value,
	.funnel-percent {
		text-align: right;
		font-variant-numeric: tabular-nums;
	}

	@media (max-width: 900px) {
		.page-header {
			flex-direction: column;
		}

		.funnel-row {
			grid-template-columns: 1fr;
			gap: 6px;
		}

		.funnel-value,
		.funnel-percent {
			text-align: left;
		}
	}
</style>