import { error } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { analyticsOverview } from '$lib/server/repo';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user || !can(locals.user.role, 'analytics.view')) throw error(403, 'Your role cannot view analytics');
	return analyticsOverview();
};
