<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { money, timeAgo } from '$lib/format';

	let { data } = $props();

	type DeliveryStatus =
		| 'delivered'
		| 'out_for_delivery'
		| 'in_transit'
		| 'failed';

	type Delivery = {
		id: string;
		orderId: string;
		customer: string;
		phone: string;
		address: string;
		carrier: string;
		trackingNumber: string;
		status: DeliveryStatus;
		estimatedDelivery: Date;
		driver: string | null;
		driverPhone: string | null;
	};

	type DeliveryIssue = {
		id: number;
		orderId: string;
		issue: string;
		attempts: number;
		lastAttempt: Date;
		action: string;
	};

	let deliveryStats = $state({
		totalDeliveries: 8924,
		inTransit: 567,
		outForDelivery: 234,
		deliveredToday: 156,
		failedToday: 12,
		successRate: 94.2,
		avgDeliveryTime: '2.8 days'
	});

	let activeDeliveries = $state<Delivery[]>([
		{
			id: 'DLV-789',
			orderId: 'EFK-1234',
			customer: 'Amine T.',
			phone: '+212 661 234 567',
			address: '123 Rue Mohammed V, Casablanca',
			carrier: 'Aramex',
			trackingNumber: 'AR789456123',
			status: 'out_for_delivery',
			estimatedDelivery: new Date(Date.now() + 7200000),
			driver: 'Hassan B.',
			driverPhone: '+212 662 345 678'
		},
		{
			id: 'DLV-790',
			orderId: 'EFK-1235',
			customer: 'Fatima M.',
			phone: '+212 663 456 789',
			address: '456 Avenue Hassan II, Rabat',
			carrier: 'DHL',
			trackingNumber: 'DH123456789',
			status: 'in_transit',
			estimatedDelivery: new Date(Date.now() + 86400000),
			driver: null,
			driverPhone: null
		}
	]);

	let carrierPerformance = $state([
		{
			carrier: 'Aramex',
			deliveries: 3456,
			successRate: 95.2,
			avgTime: '2.5 days',
			cost: 25
		},
		{
			carrier: 'DHL',
			deliveries: 2345,
			successRate: 94.8,
			avgTime: '2.1 days',
			cost: 32
		},
		{
			carrier: 'FedEx',
			deliveries: 1234,
			successRate: 93.5,
			avgTime: '2.8 days',
			cost: 28
		},
		{
			carrier: 'Local Express',
			deliveries: 1890,
			successRate: 91.2,
			avgTime: '3.2 days',
			cost: 18
		}
	]);

	let deliveryIssues = $state<DeliveryIssue[]>([
		{
			id: 1,
			orderId: 'EFK-1199',
			issue: 'Customer unreachable',
			attempts: 3,
			lastAttempt: new Date(Date.now() - 3600000),
			action: 'Reschedule for tomorrow'
		},
		{
			id: 2,
			orderId: 'EFK-1198',
			issue: 'Wrong address',
			attempts: 2,
			lastAttempt: new Date(Date.now() - 7200000),
			action: 'Contact customer for correction'
		}
	]);

	let statusFilter = $state('all');
	let carrierFilter = $state('all');
	let dateFilter = $state('today');
	let searchQuery = $state('');

	let showManualModal = $state(false);
	let showImportModal = $state(false);

	const filteredDeliveries = $derived(
		activeDeliveries.filter((delivery) => {
			const query = searchQuery.trim().toLowerCase();

			const matchesSearch =
				!query ||
				delivery.id.toLowerCase().includes(query) ||
				delivery.orderId.toLowerCase().includes(query) ||
				delivery.customer.toLowerCase().includes(query) ||
				delivery.trackingNumber.toLowerCase().includes(query);

			const matchesStatus =
				statusFilter === 'all' ||
				delivery.status === statusFilter;

			const matchesCarrier =
				carrierFilter === 'all' ||
				delivery.carrier.toLowerCase() === carrierFilter;

			return matchesSearch && matchesStatus && matchesCarrier;
		})
	);

	const activeCount = $derived(
		deliveryStats.inTransit + deliveryStats.outForDelivery
	);

	const attentionRate = $derived(
		((deliveryStats.failedToday / Math.max(1, deliveryStats.deliveredToday)) * 100).toFixed(1)
	);

	function contactDriver(delivery: Delivery) {
		if (delivery.driverPhone) {
			window.location.href = `tel:${delivery.driverPhone}`;
		}
	}

	function rescheduleDelivery(delivery: Delivery) {
		console.log('Rescheduling delivery:', delivery.id);
	}

	function viewTracking(trackingNumber: string) {
		window.open(
			`https://track.example.com/${trackingNumber}`,
			'_blank',
			'noopener,noreferrer'
		);
	}

	function statusLabel(status: DeliveryStatus) {
		switch (status) {
			case 'out_for_delivery':
				return 'Out for delivery';
			case 'in_transit':
				return 'In transit';
			case 'delivered':
				return 'Delivered';
			case 'failed':
				return 'Failed';
			default:
				return status;
		}
	}

	function carrierClass(carrier: string) {
		return carrier.toLowerCase().replace(/\s+/g, '-');
	}
</script>

<svelte:head>
	<title>Delivery Operations | Efoka.ma</title>
	<meta
		name="description"
		content="Monitor deliveries, carrier performance and delivery issues."
	/>
</svelte:head>

<div class="page">

	<!-- ========================================================= -->
	<!-- HEADER -->
	<!-- ========================================================= -->

	<header class="page-header">

		<div>
			<div class="eyebrow">
				<span class="eyebrow-dot"></span>
				LOGISTICS OPERATIONS
			</div>

			<h1>Delivery Control Center</h1>

			<p>
				Monitor active shipments, carrier performance and delivery
				exceptions from one operational workspace.
			</p>
		</div>

		<div class="header-actions">
			<button
				type="button"
				class="button secondary"
				onclick={() => (showImportModal = true)}
			>
				<span>↥</span>
				Bulk import
			</button>

			<button
				type="button"
				class="button primary"
				onclick={() => (showManualModal = true)}
			>
				<span>＋</span>
				Manual delivery
			</button>
		</div>

	</header>

	<!-- ========================================================= -->
	<!-- KPI GRID -->
	<!-- ========================================================= -->

	<section class="stats-grid">

		<div class="stat-card featured">
			<div class="stat-top">
				<div class="stat-icon purple">↗</div>
				<span class="trend positive">+6.4%</span>
			</div>

			<div class="stat-label">Active deliveries</div>

			<div class="stat-value">
				{activeCount.toLocaleString()}
			</div>

			<div class="stat-footer">
				<span>{deliveryStats.inTransit} in transit</span>
				<span>{deliveryStats.outForDelivery} out for delivery</span>
			</div>

			<div class="progress">
				<div
					class="progress-value purple"
					style={`width: ${Math.min(100, (activeCount / 1000) * 100)}%`}
				></div>
			</div>
		</div>

		<div class="stat-card">
			<div class="stat-top">
				<div class="stat-icon green">✓</div>
				<span class="trend positive">+8%</span>
			</div>

			<div class="stat-label">Delivered today</div>

			<div class="stat-value">
				{deliveryStats.deliveredToday}
			</div>

			<div class="stat-footer">
				<span>Successful completions</span>
			</div>
		</div>

		<div class="stat-card">
			<div class="stat-top">
				<div class="stat-icon blue">◈</div>
				<span class="trend positive">+2.1%</span>
			</div>

			<div class="stat-label">Success rate</div>

			<div class="stat-value">
				{deliveryStats.successRate}%
			</div>

			<div class="stat-footer">
				<span>Compared with last week</span>
			</div>

			<div class="progress">
				<div
					class="progress-value green"
					style={`width: ${deliveryStats.successRate}%`}
				></div>
			</div>
		</div>

		<div class="stat-card">
			<div class="stat-top">
				<div class="stat-icon orange">◷</div>
				<span class="trend neutral">Nationwide</span>
			</div>

			<div class="stat-label">Average delivery time</div>

			<div class="stat-value">
				{deliveryStats.avgDeliveryTime}
			</div>

			<div class="stat-footer">
				<span>Across all carriers</span>
			</div>
		</div>

	</section>

	<!-- ========================================================= -->
	<!-- OPERATIONAL HEALTH -->
	<!-- ========================================================= -->

	<section class="health-grid">

		<div class="health-card">
			<div class="health-icon green">●</div>

			<div>
				<span class="health-label">Network status</span>
				<strong>Operational</strong>
			</div>

			<div class="health-indicator">
				<span></span>
				Live
			</div>
		</div>

		<div class="health-card">
			<div class="health-icon blue">↗</div>

			<div>
				<span class="health-label">Today's throughput</span>
				<strong>{deliveryStats.deliveredToday} deliveries</strong>
			</div>

			<div class="health-metric">+8%</div>
		</div>

		<div class="health-card">
			<div class="health-icon red">!</div>

			<div>
				<span class="health-label">Failed today</span>
				<strong>{deliveryStats.failedToday}</strong>
			</div>

			<div class="health-metric warning">
				{attentionRate}% attention
			</div>
		</div>

	</section>

	<!-- ========================================================= -->
	<!-- DELIVERY MANAGEMENT -->
	<!-- ========================================================= -->

	<section class="panel">

		<div class="panel-header">

			<div>
				<div class="section-kicker">LIVE OPERATIONS</div>
				<h2>Delivery management</h2>
				<p>
					Search and monitor currently active deliveries.
				</p>
			</div>

			<div class="live-indicator">
				<span></span>
				Live tracking
			</div>

		</div>

		<div class="filters">

			<div class="search-wrapper">
				<svg
					viewBox="0 0 24 24"
					fill="none"
					stroke="currentColor"
					stroke-width="2"
					aria-hidden="true"
				>
					<circle cx="11" cy="11" r="7" />
					<path d="m20 20-4-4" />
				</svg>

				<input
					type="search"
					placeholder="Search delivery, order, customer..."
					bind:value={searchQuery}
				/>
			</div>

			<div class="filter">

				<label for="status-filter">Status</label>

				<select id="status-filter" bind:value={statusFilter}>
					<option value="all">All statuses</option>
					<option value="in_transit">In transit</option>
					<option value="out_for_delivery">Out for delivery</option>
					<option value="delivered">Delivered</option>
					<option value="failed">Failed</option>
				</select>

			</div>

			<div class="filter">

				<label for="carrier-filter">Carrier</label>

				<select id="carrier-filter" bind:value={carrierFilter}>
					<option value="all">All carriers</option>
					<option value="aramex">Aramex</option>
					<option value="dhl">DHL</option>
					<option value="fedex">FedEx</option>
					<option value="local express">Local Express</option>
				</select>

			</div>

			<div class="filter">

				<label for="date-filter">Period</label>

				<select id="date-filter" bind:value={dateFilter}>
					<option value="today">Today</option>
					<option value="week">This week</option>
					<option value="month">This month</option>
					<option value="custom">Custom range</option>
				</select>

			</div>

		</div>

		<!-- Delivery cards on mobile / table on desktop -->
		<div class="delivery-table-wrapper">

			<table class="delivery-table">

				<thead>
					<tr>
						<th>Delivery</th>
						<th>Customer</th>
						<th>Destination</th>
						<th>Carrier</th>
						<th>Tracking</th>
						<th>Status</th>
						<th>ETA</th>
						<th>Driver</th>
						<th></th>
					</tr>
				</thead>

				<tbody>

					{#each filteredDeliveries as delivery (delivery.id)}

						<tr>

							<td>
								<div class="delivery-id">
									<a href="/deliveries/{delivery.id}">
										{delivery.id}
									</a>

									<a
										class="order-link"
										href="/orders/{delivery.orderId}"
									>
										{delivery.orderId}
									</a>
								</div>
							</td>

							<td>
								<div class="customer">
									<strong>{delivery.customer}</strong>
									<span>{delivery.phone}</span>
								</div>
							</td>

							<td>
								<div class="destination">
									<span class="location-dot"></span>
									<span>{delivery.address}</span>
								</div>
							</td>

							<td>
								<div class="carrier">
									<div class={`carrier-logo ${carrierClass(delivery.carrier)}`}>
										{delivery.carrier.slice(0, 1)}
									</div>

									<strong>{delivery.carrier}</strong>
								</div>
							</td>

							<td>
								<button
									type="button"
									class="tracking-link"
									onclick={() => viewTracking(delivery.trackingNumber)}
								>
									{delivery.trackingNumber}
								</button>
							</td>

							<td>
								<div class="status-cell">
									<Pill status={delivery.status} />
									<span class="status-label">
										{statusLabel(delivery.status)}
									</span>
								</div>
							</td>

							<td>
								<div class="eta">
									<strong>{timeAgo(delivery.estimatedDelivery)}</strong>
									<span>estimated</span>
								</div>
							</td>

							<td>

								{#if delivery.driver}

									<div class="driver">
										<div class="driver-avatar">
											{delivery.driver.slice(0, 1)}
										</div>

										<div>
											<strong>{delivery.driver}</strong>
											<span>{delivery.driverPhone}</span>
										</div>
									</div>

								{:else}

									<div class="unassigned">
										<span>—</span>
										Awaiting assignment
									</div>

								{/if}

							</td>

							<td>
								<div class="action-menu">

									<button
										type="button"
										class="icon-button"
										onclick={() => contactDriver(delivery)}
										disabled={!delivery.driverPhone}
										title="Contact driver"
										aria-label="Contact driver"
									>
										☎
									</button>

									<button
										type="button"
										class="icon-button"
										onclick={() => rescheduleDelivery(delivery)}
										title="Reschedule delivery"
										aria-label="Reschedule delivery"
									>
										◷
									</button>

									<a
										class="icon-button"
										href="/deliveries/{delivery.id}"
										title="View details"
										aria-label="View delivery details"
									>
										→
									</a>

								</div>
							</td>

						</tr>

					{:else}

						<tr>
							<td colspan="9">
								<div class="empty-state">
									<div class="empty-icon">⌕</div>
									<strong>No deliveries found</strong>
									<span>
										Try changing your search or filters.
									</span>
								</div>
							</td>
						</tr>

					{/each}

				</tbody>

			</table>

		</div>

	</section>

	<!-- ========================================================= -->
	<!-- LOWER OPERATIONS GRID -->
	<!-- ========================================================= -->

	<div class="operations-grid">

		<!-- Carrier performance -->
		<section class="panel">

			<div class="panel-header">

				<div>
					<div class="section-kicker">CARRIER INTELLIGENCE</div>
					<h2>Carrier performance</h2>
					<p>Compare operational performance.</p>
				</div>

				<a class="header-link" href="/shipping">
					Manage carriers →
				</a>

			</div>

			<div class="carrier-list">

				{#each carrierPerformance as carrier, index (carrier.carrier)}

					<div class="carrier-row">

						<div class="carrier-rank">
							0{index + 1}
						</div>

						<div class="carrier-brand">
							<div class={`carrier-logo large ${carrierClass(carrier.carrier)}`}>
								{carrier.carrier.slice(0, 1)}
							</div>

							<div>
								<strong>{carrier.carrier}</strong>
								<span>
									{carrier.deliveries.toLocaleString()} deliveries
								</span>
							</div>
						</div>

						<div class="carrier-rate">

							<div class="rate-header">
								<span>Success rate</span>
								<strong>{carrier.successRate}%</strong>
							</div>

							<div class="progress">
								<div
									class="progress-value green"
									style={`width: ${carrier.successRate}%`}
								></div>
							</div>

						</div>

						<div class="carrier-metric">
							<span>Avg time</span>
							<strong>{carrier.avgTime}</strong>
						</div>

						<div class="carrier-metric">
							<span>Cost</span>
							<strong>{money(carrier.cost)}</strong>
						</div>

					</div>

				{/each}

			</div>

		</section>

		<!-- Delivery issues -->
		<section class="panel issues-panel">

			<div class="panel-header">

				<div>
					<div class="section-kicker">EXCEPTIONS</div>
					<h2>Delivery issues</h2>
					<p>Items requiring operator attention.</p>
				</div>

				<span class="attention-badge">
					{deliveryIssues.length} attention
				</span>

			</div>

			<div class="issues-list">

				{#each deliveryIssues as issue (issue.id)}

					<div class="issue-card">

						<div class="issue-icon">
							!
						</div>

						<div class="issue-content">

							<div class="issue-top">
								<div>
									<strong>{issue.issue}</strong>
									<span>
										Order {issue.orderId}
									</span>
								</div>

								<span class="attempt-badge">
									{issue.attempts} attempts
								</span>
							</div>

							<div class="issue-meta">
								<span>{issue.action}</span>
								<span>{timeAgo(issue.lastAttempt)}</span>
							</div>

							<div class="issue-actions">

								<button
									type="button"
									class="small-button primary"
								>
									Resolve
								</button>

								<button
									type="button"
									class="small-button"
								>
									Escalate
								</button>

							</div>

						</div>

					</div>

				{/each}

			</div>

		</section>

	</div>

</div>

<!-- ============================================================= -->
<!-- MANUAL DELIVERY MODAL -->
<!-- ============================================================= -->

{#if showManualModal}

	<div
		class="modal-backdrop"
		role="presentation"
		onclick={(event) => {
			if (event.currentTarget === event.target) showManualModal = false;
		}}
	>

		<div
			class="modal"
			role="dialog"
			tabindex="-1"
			aria-modal="true"
			aria-labelledby="manual-delivery-title"
		>

			<div class="modal-header">

				<div>
					<div class="section-kicker">NEW SHIPMENT</div>
					<h2 id="manual-delivery-title">Manual delivery</h2>
					<p>Create a delivery record manually.</p>
				</div>

				<button
					type="button"
					class="close-button"
					onclick={() => (showManualModal = false)}
					aria-label="Close"
				>
					×
				</button>

			</div>

			<div class="modal-form">

				<div class="form-row">

					<div class="field">
						<label for="manual-order">Order ID</label>
						<input
							id="manual-order"
							type="text"
							placeholder="EFK-1234"
						/>
					</div>

					<div class="field">
						<label for="manual-carrier">Carrier</label>
						<select id="manual-carrier">
							<option>Aramex</option>
							<option>DHL</option>
							<option>FedEx</option>
							<option>Local Express</option>
						</select>
					</div>

				</div>

				<div class="field">
					<label for="manual-customer">Customer</label>
					<input
						id="manual-customer"
						type="text"
						placeholder="Customer name"
					/>
				</div>

				<div class="field">
					<label for="manual-phone">Phone</label>
					<input
						id="manual-phone"
						type="tel"
						placeholder="+212 6XX XXX XXX"
					/>
				</div>

				<div class="field">
					<label for="manual-address">Delivery address</label>
					<textarea
						id="manual-address"
						rows="3"
						placeholder="Full delivery address"
					></textarea>
				</div>

			</div>

			<div class="modal-footer">

				<button
					type="button"
					class="button secondary"
					onclick={() => (showManualModal = false)}
				>
					Cancel
				</button>

				<button
					type="button"
					class="button primary"
					onclick={() => (showManualModal = false)}
				>
					Create delivery
				</button>

			</div>

		</div>

	</div>

{/if}

<!-- ============================================================= -->
<!-- IMPORT MODAL -->
<!-- ============================================================= -->

{#if showImportModal}

	<div
		class="modal-backdrop"
		role="presentation"
		onclick={(event) => {
			if (event.currentTarget === event.target) showImportModal = false;
		}}
	>

		<div
			class="modal import-modal"
			role="dialog"
			tabindex="-1"
			aria-modal="true"
			aria-labelledby="import-title"
		>

			<div class="modal-header">

				<div>
					<div class="section-kicker">DATA IMPORT</div>
					<h2 id="import-title">Bulk delivery import</h2>
					<p>Import delivery records from a CSV file.</p>
				</div>

				<button
					type="button"
					class="close-button"
					onclick={() => (showImportModal = false)}
					aria-label="Close"
				>
					×
				</button>

			</div>

			<div class="upload-zone">

				<div class="upload-icon">↥</div>

				<strong>Drop your CSV file here</strong>

				<span>
					or choose a file from your computer
				</span>

				<button type="button" class="button secondary">
					Choose file
				</button>

				<small>
					CSV files up to 10 MB
				</small>

			</div>

			<div class="modal-footer">

				<button
					type="button"
					class="button secondary"
					onclick={() => (showImportModal = false)}
				>
					Cancel
				</button>

			</div>

		</div>

	</div>

{/if}

<style>
	.page {
		max-width: 1480px;
		margin: 0 auto;
		padding: 28px;
	}

	.page-header {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		gap: 24px;
		margin-bottom: 24px;
	}

	.eyebrow,
	.section-kicker {
		display: flex;
		align-items: center;
		gap: 7px;
		color: #6366f1;
		font-size: 10px;
		font-weight: 800;
		letter-spacing: 0.11em;
	}

	.eyebrow-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: #6366f1;
		box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
	}

	.page-header h1 {
		margin: 7px 0 5px;
		color: #0f172a;
		font-size: 30px;
		font-weight: 800;
		letter-spacing: -0.04em;
	}

	.page-header p {
		max-width: 720px;
		margin: 0;
		color: #64748b;
		font-size: 13px;
		line-height: 1.6;
	}

	.header-actions {
		display: flex;
		gap: 9px;
	}

	.button {
		height: 40px;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 7px;
		padding: 0 15px;
		border: 1px solid #dbe2ea;
		border-radius: 9px;
		background: white;
		color: #334155;
		font-size: 12px;
		font-weight: 700;
		cursor: pointer;
		transition:
			transform 0.15s ease,
			box-shadow 0.15s ease,
			border-color 0.15s ease;
	}

	.button:hover {
		transform: translateY(-1px);
		border-color: #cbd5e1;
		box-shadow: 0 5px 14px rgba(15, 23, 42, 0.07);
	}

	.button.primary {
		border-color: transparent;
		background: linear-gradient(135deg, #4f46e5, #7c3aed);
		color: white;
		box-shadow: 0 7px 16px rgba(79, 70, 229, 0.2);
	}

	.button.secondary {
		background: white;
	}

	.stats-grid {
		display: grid;
		grid-template-columns: repeat(4, minmax(0, 1fr));
		gap: 13px;
		margin-bottom: 13px;
	}

	.stat-card {
		position: relative;
		min-width: 0;
		padding: 18px;
		border: 1px solid #e2e8f0;
		border-radius: 15px;
		background: white;
		box-shadow: 0 5px 18px rgba(15, 23, 42, 0.035);
	}

	.stat-card.featured {
		border-color: #ddd6fe;
		background: linear-gradient(135deg, #fafaff, #fff);
	}

	.stat-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 15px;
	}

	.stat-icon {
		width: 39px;
		height: 39px;
		display: grid;
		place-items: center;
		border-radius: 10px;
		font-size: 17px;
		font-weight: 800;
	}

	.stat-icon.purple {
		background: #eef2ff;
		color: #4f46e5;
	}

	.stat-icon.green {
		background: #f0fdf4;
		color: #16a34a;
	}

	.stat-icon.blue {
		background: #eff6ff;
		color: #2563eb;
	}

	.stat-icon.orange {
		background: #fff7ed;
		color: #ea580c;
	}

	.trend {
		padding: 4px 7px;
		border-radius: 6px;
		font-size: 9px;
		font-weight: 750;
	}

	.trend.positive {
		background: #f0fdf4;
		color: #16a34a;
	}

	.trend.neutral {
		background: #f8fafc;
		color: #64748b;
	}

	.stat-label {
		color: #64748b;
		font-size: 11px;
		font-weight: 600;
	}

	.stat-value {
		margin-top: 3px;
		color: #0f172a;
		font-size: 25px;
		font-weight: 800;
		letter-spacing: -0.035em;
	}

	.stat-footer {
		display: flex;
		gap: 8px;
		margin-top: 3px;
		color: #94a3b8;
		font-size: 10px;
	}

	.progress {
		height: 5px;
		overflow: hidden;
		margin-top: 12px;
		border-radius: 99px;
		background: #f1f5f9;
	}

	.progress-value {
		height: 100%;
		border-radius: inherit;
	}

	.progress-value.purple {
		background: linear-gradient(90deg, #6366f1, #8b5cf6);
	}

	.progress-value.green {
		background: linear-gradient(90deg, #22c55e, #16a34a);
	}

	.health-grid {
		display: grid;
		grid-template-columns: repeat(3, minmax(0, 1fr));
		gap: 13px;
		margin-bottom: 18px;
	}

	.health-card {
		display: flex;
		align-items: center;
		gap: 11px;
		padding: 13px 15px;
		border: 1px solid #e2e8f0;
		border-radius: 12px;
		background: #fff;
	}

	.health-icon {
		width: 33px;
		height: 33px;
		display: grid;
		place-items: center;
		border-radius: 9px;
		font-size: 12px;
	}

	.health-icon.green {
		background: #f0fdf4;
		color: #16a34a;
	}

	.health-icon.blue {
		background: #eff6ff;
		color: #2563eb;
	}

	.health-icon.red {
		background: #fef2f2;
		color: #dc2626;
	}

	.health-card > div:nth-child(2) {
		display: flex;
		flex-direction: column;
		gap: 2px;
		min-width: 0;
	}

	.health-label {
		color: #94a3b8;
		font-size: 9px;
		font-weight: 700;
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}

	.health-card strong {
		color: #334155;
		font-size: 12px;
	}

	.health-indicator {
		display: flex;
		align-items: center;
		gap: 5px;
		margin-left: auto;
		color: #16a34a;
		font-size: 10px;
		font-weight: 700;
	}

	.health-indicator span,
	.live-indicator span {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: #22c55e;
		box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.1);
	}

	.health-metric {
		margin-left: auto;
		color: #16a34a;
		font-size: 10px;
		font-weight: 750;
	}

	.health-metric.warning {
		color: #dc2626;
	}

	.panel {
		margin-bottom: 18px;
		padding: 20px;
		border: 1px solid #e2e8f0;
		border-radius: 15px;
		background: white;
		box-shadow: 0 5px 18px rgba(15, 23, 42, 0.035);
	}

	.panel-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 20px;
		padding-bottom: 17px;
		border-bottom: 1px solid #f1f5f9;
	}

	.panel-header h2 {
		margin: 4px 0 3px;
		color: #0f172a;
		font-size: 17px;
		font-weight: 750;
		letter-spacing: -0.02em;
	}

	.panel-header p {
		margin: 0;
		color: #94a3b8;
		font-size: 11px;
	}

	.live-indicator {
		display: flex;
		align-items: center;
		gap: 7px;
		padding: 6px 9px;
		border: 1px solid #bbf7d0;
		border-radius: 7px;
		background: #f0fdf4;
		color: #15803d;
		font-size: 9px;
		font-weight: 750;
	}

	.filters {
		display: grid;
		grid-template-columns: minmax(240px, 1fr) repeat(3, 170px);
		gap: 10px;
		padding: 15px 0;
	}

	.search-wrapper {
		position: relative;
	}

	.search-wrapper svg {
		position: absolute;
		left: 11px;
		top: 50%;
		width: 15px;
		height: 15px;
		transform: translateY(-50%);
		color: #94a3b8;
		pointer-events: none;
	}

	.search-wrapper input,
	.filter select,
	.field input,
	.field select,
	.field textarea {
		width: 100%;
		box-sizing: border-box;
		border: 1px solid #dbe2ea;
		border-radius: 8px;
		outline: none;
		background: white;
		color: #334155;
		font: inherit;
		font-size: 11px;
		transition:
			border-color 0.15s ease,
			box-shadow 0.15s ease;
	}

	.search-wrapper input {
		height: 39px;
		padding: 0 12px 0 34px;
	}

	.filter {
		display: flex;
		flex-direction: column;
		gap: 5px;
	}

	.filter label,
	.field label {
		color: #64748b;
		font-size: 10px;
		font-weight: 700;
	}

	.filter select {
		height: 39px;
		padding: 0 10px;
	}

	.search-wrapper input:focus,
	.filter select:focus,
	.field input:focus,
	.field select:focus,
	.field textarea:focus {
		border-color: #818cf8;
		box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.09);
	}

	.delivery-table-wrapper {
		overflow-x: auto;
	}

	.delivery-table {
		width: 100%;
		border-collapse: collapse;
		min-width: 1180px;
	}

	.delivery-table th {
		padding: 10px 9px;
		border-bottom: 1px solid #e2e8f0;
		color: #94a3b8;
		font-size: 9px;
		font-weight: 750;
		text-align: left;
		text-transform: uppercase;
		letter-spacing: 0.06em;
		white-space: nowrap;
	}

	.delivery-table td {
		padding: 13px 9px;
		border-bottom: 1px solid #f1f5f9;
		color: #475569;
		font-size: 11px;
		vertical-align: middle;
	}

	.delivery-table tbody tr {
		transition: background 0.12s ease;
	}

	.delivery-table tbody tr:hover {
		background: #fafbff;
	}

	.delivery-id {
		display: flex;
		flex-direction: column;
		gap: 4px;
	}

	.delivery-id a {
		color: #4f46e5;
		font-family:
			ui-monospace,
			SFMono-Regular,
			Menlo,
			Monaco,
			Consolas,
			monospace;
		font-size: 10px;
		font-weight: 750;
		text-decoration: none;
	}

	.delivery-id a:hover {
		text-decoration: underline;
	}

	.delivery-id .order-link {
		color: #94a3b8;
		font-weight: 600;
	}

	.customer,
	.driver,
	.eta {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.customer strong,
	.driver strong,
	.eta strong {
		color: #334155;
		font-size: 11px;
	}

	.customer span,
	.driver span,
	.eta span {
		color: #94a3b8;
		font-size: 9px;
	}

	.destination {
		display: flex;
		align-items: flex-start;
		gap: 7px;
		max-width: 180px;
		line-height: 1.4;
	}

	.location-dot {
		width: 6px;
		height: 6px;
		flex: 0 0 auto;
		margin-top: 4px;
		border-radius: 50%;
		background: #6366f1;
	}

	.carrier {
		display: flex;
		align-items: center;
		gap: 7px;
		white-space: nowrap;
	}

	.carrier strong {
		color: #334155;
		font-size: 10px;
	}

	.carrier-logo {
		width: 27px;
		height: 27px;
		display: grid;
		place-items: center;
		border-radius: 7px;
		background: #eef2ff;
		color: #4f46e5;
		font-size: 10px;
		font-weight: 800;
	}

	.carrier-logo.large {
		width: 34px;
		height: 34px;
		border-radius: 9px;
	}

	.carrier-logo.aramex {
		background: #fff7ed;
		color: #ea580c;
	}

	.carrier-logo.dhl {
		background: #fefce8;
		color: #ca8a04;
	}

	.carrier-logo.fedex {
		background: #eef2ff;
		color: #4f46e5;
	}

	.tracking-link {
		padding: 0;
		border: 0;
		background: transparent;
		color: #4f46e5;
		font-family:
			ui-monospace,
			SFMono-Regular,
			Menlo,
			Monaco,
			Consolas,
			monospace;
		font-size: 9px;
		font-weight: 650;
		cursor: pointer;
	}

	.tracking-link:hover {
		text-decoration: underline;
	}

	.status-cell {
		display: flex;
		flex-direction: column;
		gap: 4px;
	}

	.status-label {
		color: #94a3b8;
		font-size: 9px;
	}

	.driver {
		flex-direction: row;
		align-items: center;
		gap: 7px;
	}

	.driver-avatar {
		width: 27px;
		height: 27px;
		display: grid;
		place-items: center;
		border-radius: 50%;
		background: #f1f5f9;
		color: #475569;
		font-size: 9px;
		font-weight: 800;
	}

	.unassigned {
		display: flex;
		align-items: center;
		gap: 5px;
		color: #94a3b8;
		font-size: 9px;
	}

	.unassigned span {
		width: 22px;
		height: 22px;
		display: grid;
		place-items: center;
		border-radius: 50%;
		background: #f8fafc;
	}

	.action-menu {
		display: flex;
		gap: 5px;
	}

	.icon-button {
		width: 28px;
		height: 28px;
		display: grid;
		place-items: center;
		padding: 0;
		border: 1px solid #e2e8f0;
		border-radius: 7px;
		background: white;
		color: #64748b;
		font-size: 11px;
		text-decoration: none;
		cursor: pointer;
	}

	.icon-button:hover:not(:disabled) {
		border-color: #c7d2fe;
		background: #f8faff;
		color: #4f46e5;
	}

	.icon-button:disabled {
		cursor: not-allowed;
		opacity: 0.35;
	}

	.operations-grid {
		display: grid;
		grid-template-columns: 1.25fr 0.75fr;
		gap: 0;
	}

	.operations-grid > .panel {
		margin-bottom: 18px;
	}

	.operations-grid > .panel:first-child {
		margin-right: 9px;
	}

	.operations-grid > .panel:last-child {
		margin-left: 9px;
	}

	.header-link {
		color: #4f46e5;
		font-size: 10px;
		font-weight: 700;
		text-decoration: none;
	}

	.carrier-list {
		display: flex;
		flex-direction: column;
	}

	.carrier-row {
		display: grid;
		grid-template-columns: 28px 1.1fr 1.2fr 90px 70px;
		align-items: center;
		gap: 13px;
		padding: 13px 0;
		border-bottom: 1px solid #f1f5f9;
	}

	.carrier-row:last-child {
		border-bottom: 0;
	}

	.carrier-rank {
		color: #cbd5e1;
		font-family: monospace;
		font-size: 10px;
		font-weight: 800;
	}

	.carrier-brand {
		display: flex;
		align-items: center;
		gap: 9px;
		min-width: 0;
	}

	.carrier-brand > div:last-child {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.carrier-brand strong {
		color: #334155;
		font-size: 11px;
	}

	.carrier-brand span {
		color: #94a3b8;
		font-size: 9px;
	}

	.carrier-rate {
		min-width: 100px;
	}

	.rate-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 5px;
	}

	.rate-header span {
		color: #94a3b8;
		font-size: 8px;
	}

	.rate-header strong {
		color: #334155;
		font-size: 9px;
	}

	.carrier-rate .progress {
		margin-top: 0;
	}

	.carrier-metric {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.carrier-metric span {
		color: #94a3b8;
		font-size: 8px;
	}

	.carrier-metric strong {
		color: #334155;
		font-size: 10px;
	}

	.attention-badge {
		padding: 6px 8px;
		border-radius: 7px;
		background: #fef2f2;
		color: #dc2626;
		font-size: 9px;
		font-weight: 750;
	}

	.issues-list {
		display: flex;
		flex-direction: column;
		gap: 10px;
		padding-top: 3px;
	}

	.issue-card {
		display: flex;
		align-items: flex-start;
		gap: 10px;
		padding: 12px;
		border: 1px solid #fee2e2;
		border-radius: 10px;
		background: #fffafa;
	}

	.issue-icon {
		width: 27px;
		height: 27px;
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 8px;
		background: #fee2e2;
		color: #dc2626;
		font-size: 11px;
		font-weight: 800;
	}

	.issue-content {
		width: 100%;
		min-width: 0;
	}

	.issue-top {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 8px;
	}

	.issue-top div {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.issue-top strong {
		color: #334155;
		font-size: 11px;
	}

	.issue-top span {
		color: #94a3b8;
		font-size: 9px;
	}

	.attempt-badge {
		padding: 4px 6px;
		border-radius: 5px;
		background: #fff1f2;
		color: #e11d48 !important;
		font-size: 8px !important;
		font-weight: 700;
		white-space: nowrap;
	}

	.issue-meta {
		display: flex;
		justify-content: space-between;
		gap: 10px;
		margin-top: 8px;
		color: #64748b;
		font-size: 9px;
	}

	.issue-actions {
		display: flex;
		gap: 6px;
		margin-top: 10px;
	}

	.small-button {
		height: 27px;
		padding: 0 9px;
		border: 1px solid #e2e8f0;
		border-radius: 6px;
		background: white;
		color: #475569;
		font-size: 9px;
		font-weight: 700;
		cursor: pointer;
	}

	.small-button.primary {
		border-color: #c7d2fe;
		background: #eef2ff;
		color: #4f46e5;
	}

	.empty-state {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		gap: 5px;
		min-height: 180px;
	}

	.empty-icon {
		width: 40px;
		height: 40px;
		display: grid;
		place-items: center;
		margin-bottom: 5px;
		border-radius: 11px;
		background: #f1f5f9;
		color: #64748b;
		font-size: 19px;
	}

	.empty-state strong {
		color: #334155;
		font-size: 13px;
	}

	.empty-state span {
		color: #94a3b8;
		font-size: 10px;
	}

	.modal-backdrop {
		position: fixed;
		inset: 0;
		z-index: 1000;
		display: grid;
		place-items: center;
		padding: 20px;
		background: rgba(15, 23, 42, 0.48);
		backdrop-filter: blur(5px);
	}

	.modal {
		width: min(520px, 100%);
		max-height: calc(100vh - 40px);
		overflow: auto;
		border: 1px solid #e2e8f0;
		border-radius: 17px;
		background: white;
		box-shadow:
			0 30px 70px rgba(15, 23, 42, 0.22),
			0 8px 20px rgba(15, 23, 42, 0.1);
	}

	.import-modal {
		width: min(560px, 100%);
	}

	.modal-header {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 15px;
		padding: 20px;
		border-bottom: 1px solid #f1f5f9;
	}

	.modal-header h2 {
		margin: 4px 0 3px;
		color: #0f172a;
		font-size: 18px;
		font-weight: 800;
	}

	.modal-header p {
		margin: 0;
		color: #94a3b8;
		font-size: 11px;
	}

	.close-button {
		width: 30px;
		height: 30px;
		display: grid;
		place-items: center;
		border: 1px solid #e2e8f0;
		border-radius: 8px;
		background: white;
		color: #64748b;
		font-size: 19px;
		cursor: pointer;
	}

	.close-button:hover {
		background: #f8fafc;
		color: #0f172a;
	}

	.modal-form {
		display: flex;
		flex-direction: column;
		gap: 15px;
		padding: 20px;
	}

	.form-row {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 12px;
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.field input,
	.field select {
		height: 40px;
		padding: 0 11px;
	}

	.field textarea {
		padding: 10px 11px;
		resize: vertical;
	}

	.modal-footer {
		display: flex;
		justify-content: flex-end;
		gap: 8px;
		padding: 15px 20px;
		border-top: 1px solid #f1f5f9;
		background: #fafbfc;
	}

	.upload-zone {
		display: flex;
		align-items: center;
		flex-direction: column;
		gap: 8px;
		margin: 20px;
		padding: 40px 20px;
		border: 1.5px dashed #cbd5e1;
		border-radius: 13px;
		background: #f8fafc;
		text-align: center;
	}

	.upload-icon {
		width: 46px;
		height: 46px;
		display: grid;
		place-items: center;
		margin-bottom: 4px;
		border-radius: 12px;
		background: #eef2ff;
		color: #4f46e5;
		font-size: 20px;
		font-weight: 800;
	}

	.upload-zone strong {
		color: #334155;
		font-size: 13px;
	}

	.upload-zone span {
		color: #94a3b8;
		font-size: 10px;
	}

	.upload-zone small {
		color: #cbd5e1;
		font-size: 9px;
	}

	@media (max-width: 1200px) {
		.stats-grid {
			grid-template-columns: repeat(2, 1fr);
		}

		.filters {
			grid-template-columns: 1fr 1fr 1fr;
		}

		.search-wrapper {
			grid-column: 1 / -1;
		}

		.operations-grid {
			grid-template-columns: 1fr;
		}

		.operations-grid > .panel:first-child,
		.operations-grid > .panel:last-child {
			margin-left: 0;
			margin-right: 0;
		}
	}

	@media (max-width: 800px) {
		.page {
			padding: 18px;
		}

		.page-header {
			align-items: flex-start;
			flex-direction: column;
		}

		.header-actions {
			width: 100%;
		}

		.header-actions .button {
			flex: 1;
		}

		.health-grid {
			grid-template-columns: 1fr;
		}

		.filters {
			grid-template-columns: 1fr 1fr;
		}

		.search-wrapper {
			grid-column: 1 / -1;
		}

		.carrier-row {
			grid-template-columns: 28px 1fr 1fr;
		}

		.carrier-rate {
			grid-column: 2 / -1;
		}

		.carrier-metric {
			display: none;
		}
	}

	@media (max-width: 560px) {
		.page {
			padding: 13px;
		}

		.page-header h1 {
			font-size: 25px;
		}

		.stats-grid {
			grid-template-columns: 1fr;
		}

		.filters {
			grid-template-columns: 1fr;
		}

		.search-wrapper {
			grid-column: auto;
		}

		.form-row {
			grid-template-columns: 1fr;
		}

		.panel {
			padding: 15px;
		}

		.panel-header {
			align-items: flex-start;
			flex-direction: column;
		}

		.health-card {
			padding: 12px;
		}

		.issue-meta {
			flex-direction: column;
		}

		.modal-backdrop {
			padding: 10px;
		}

		.modal {
			border-radius: 14px;
		}
	}
</style>