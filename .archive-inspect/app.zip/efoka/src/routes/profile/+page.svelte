<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Checkbox,
		Helper,
		Input,
		Label,
		Modal,
		Spinner,
		Textarea,
		Toggle
	} from 'flowbite-svelte';

	import Pill from '$lib/components/Pill.svelte';
	import { ROLE_LABELS } from '$lib/permissions';
	import type { Role } from '$lib/types';

	let { data } = $props();

	let userProfile = $state({
		name: 'John Doe',
		email: 'john@efoka.ma',
		phone: '+212 661 234 567',
		role: 'manager' as Role,
		avatar: null as string | null,
		bio: 'E-commerce operations specialist',
		timezone: 'Africa/Casablanca',
		language: 'en',
		notifications: {
			email: true,
			sms: false,
			push: true,
			whatsapp: true
		},
		twoFactorEnabled: false,
		lastLogin: new Date(Date.now() - 86400000),
		createdAt: new Date('2024-01-15')
	});

	let activityLog = $state([
		{
			action: 'Updated order status',
			timestamp: new Date(Date.now() - 3600000),
			ip: '192.168.1.1'
		},
		{
			action: 'Logged in',
			timestamp: new Date(Date.now() - 86400000),
			ip: '192.168.1.1'
		},
		{
			action: 'Password changed',
			timestamp: new Date(Date.now() - 172800000),
			ip: '192.168.1.2'
		}
	]);

	let performanceMetrics = $state({
		ordersProcessed: 456,
		confirmations: 389,
		customerSatisfaction: 4.6,
		avgResponseTime: '2.3h'
	});

	let isEditing = $state(false);
	let savingProfile = $state(false);

	let showPasswordModal = $state(false);
	let showSessionsModal = $state(false);

	let password = $state('');
	let passwordConfirmation = $state('');
	let passwordChanging = $state(false);

	const initials = $derived(
		userProfile.name
			.trim()
			.split(/\s+/)
			.filter(Boolean)
			.map((name) => name[0])
			.join('')
			.slice(0, 2)
			.toUpperCase()
	);

	const confirmationRate = $derived(
		userProfile && performanceMetrics.ordersProcessed > 0
			? Math.round(
					(performanceMetrics.confirmations /
						performanceMetrics.ordersProcessed) *
						100
				)
			: 0
	);

	const roleLabel = $derived(
		ROLE_LABELS[userProfile.role] ?? userProfile.role
	);

	function saveProfile() {
		savingProfile = true;

		setTimeout(() => {
			savingProfile = false;
			isEditing = false;
		}, 350);
	}

	function closePasswordModal() {
		showPasswordModal = false;
		password = '';
		passwordConfirmation = '';
	}

	function changePassword() {
		if (
			password.length < 8 ||
			password !== passwordConfirmation
		) {
			return;
		}

		passwordChanging = true;

		setTimeout(() => {
			passwordChanging = false;
			closePasswordModal();
		}, 500);
	}

	function formatDate(date: Date) {
		return date.toLocaleDateString(undefined, {
			year: 'numeric',
			month: 'short',
			day: 'numeric'
		});
	}

	function formatDateTime(date: Date) {
		return date.toLocaleString(undefined, {
			year: 'numeric',
			month: 'short',
			day: 'numeric',
			hour: '2-digit',
			minute: '2-digit'
		});
	}
</script>

<svelte:head>
	<title>Profile · Efoka</title>
	<meta
		name="description"
		content="Manage your Efoka profile, security and notification preferences."
	/>
</svelte:head>

<div class="space-y-6">

	<!-- Header -->
	<div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
		<div>
			<div class="mb-1 text-xs font-semibold uppercase tracking-wider text-primary-600">
				Account
			</div>

			<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
				Profile
			</h1>

			<p class="mt-2 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
				Manage your personal information, security settings and notification preferences.
			</p>
		</div>

		<Button
			color={isEditing ? 'alternative' : 'primary'}
			onclick={() => (isEditing = !isEditing)}
		>
			{isEditing ? 'Cancel editing' : 'Edit profile'}
		</Button>
	</div>

	<!-- Profile / Performance -->
	<div class="grid gap-6 xl:grid-cols-3">

		<Card class="xl:col-span-1">
			<div class="flex flex-col items-center text-center">

				<div
					class="flex h-24 w-24 items-center justify-center overflow-hidden rounded-full bg-primary-600 text-2xl font-bold text-white shadow-lg"
					aria-label={`Avatar for ${userProfile.name}`}
				>
					{#if userProfile.avatar}
						<img
							src={userProfile.avatar}
							alt={userProfile.name}
							class="h-full w-full object-cover"
						/>
					{:else}
						{initials}
					{/if}
				</div>

				<h2 class="mt-4 text-xl font-bold text-gray-900 dark:text-white">
					{userProfile.name}
				</h2>

				<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
					{userProfile.email}
				</p>

				<div class="mt-3">
					<Pill status={userProfile.role} />
				</div>
			</div>

			<div class="my-6 border-t border-gray-200 dark:border-gray-700"></div>

			{#if isEditing}
				<form
					class="space-y-5"
					onsubmit={(event) => {
						event.preventDefault();
						saveProfile();
					}}
				>
					<div>
						<Label for="profile-name" class="mb-2 block">
							Full name
						</Label>

						<Input
							id="profile-name"
							bind:value={userProfile.name}
							placeholder="Your full name"
							required
						/>
					</div>

					<div>
						<Label for="profile-email" class="mb-2 block">
							Email
						</Label>

						<Input
							id="profile-email"
							type="email"
							bind:value={userProfile.email}
							placeholder="name@example.com"
							required
						/>
					</div>

					<div>
						<Label for="profile-phone" class="mb-2 block">
							Phone
						</Label>

						<Input
							id="profile-phone"
							type="tel"
							bind:value={userProfile.phone}
							placeholder="+212 ..."
						/>
					</div>

					<div>
						<Label for="profile-bio" class="mb-2 block">
							Bio
						</Label>

						<Textarea
							id="profile-bio"
							bind:value={userProfile.bio}
							rows={4}
							placeholder="Tell your team a little about yourself"
						/>
					</div>

					<Button
						type="submit"
						color="primary"
						class="w-full"
						disabled={savingProfile}
					>
						{#if savingProfile}
							<Spinner size="4" class="me-2" />
							Saving...
						{:else}
							Save changes
						{/if}
					</Button>
				</form>
			{:else}
				<div class="space-y-5">

					<div>
						<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
							Email
						</div>

						<div class="mt-1 text-sm font-medium text-gray-900 dark:text-white">
							{userProfile.email}
						</div>
					</div>

					<div>
						<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
							Phone
						</div>

						<div class="mt-1 text-sm font-medium text-gray-900 dark:text-white">
							{userProfile.phone}
						</div>
					</div>

					<div>
						<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
							Role
						</div>

						<div class="mt-2">
							<Badge color="blue">{roleLabel}</Badge>
						</div>
					</div>

					<div>
						<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
							Timezone
						</div>

						<div class="mt-1 text-sm font-medium text-gray-900 dark:text-white">
							{userProfile.timezone}
						</div>
					</div>

					<div>
						<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
							Language
						</div>

						<div class="mt-1 text-sm font-medium text-gray-900 dark:text-white">
							{userProfile.language.toUpperCase()}
						</div>
					</div>

					<div>
						<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
							Member since
						</div>

						<div class="mt-1 text-sm font-medium text-gray-900 dark:text-white">
							{formatDate(userProfile.createdAt)}
						</div>
					</div>

				</div>
			{/if}
		</Card>

		<Card class="xl:col-span-2">
			<div class="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
				<div>
					<h2 class="text-xl font-bold text-gray-900 dark:text-white">
						Performance overview
					</h2>

					<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
						Your operational activity and service metrics.
					</p>
				</div>

				<Badge color="green">
					{confirmationRate}% confirmation rate
				</Badge>
			</div>

			<div class="grid gap-4 sm:grid-cols-2">

				<div class="metric-card">
					<div class="metric-icon metric-blue">↗</div>

					<div>
						<div class="metric-value">
							{performanceMetrics.ordersProcessed}
						</div>

						<div class="metric-label">
							Orders processed
						</div>
					</div>
				</div>

				<div class="metric-card">
					<div class="metric-icon metric-green">✓</div>

					<div>
						<div class="metric-value">
							{performanceMetrics.confirmations}
						</div>

						<div class="metric-label">
							Confirmations
						</div>
					</div>
				</div>

				<div class="metric-card">
					<div class="metric-icon metric-violet">★</div>

					<div>
						<div class="metric-value">
							{performanceMetrics.customerSatisfaction}
							<span class="text-sm font-medium text-gray-400">/ 5</span>
						</div>

						<div class="metric-label">
							Customer satisfaction
						</div>
					</div>
				</div>

				<div class="metric-card">
					<div class="metric-icon metric-amber">◷</div>

					<div>
						<div class="metric-value">
							{performanceMetrics.avgResponseTime}
						</div>

						<div class="metric-label">
							Average response time
						</div>
					</div>
				</div>

			</div>

			<div class="mt-6 rounded-lg bg-gray-50 p-4 dark:bg-gray-800/50">
				<div class="flex items-center justify-between gap-4">
					<div>
						<div class="text-sm font-medium text-gray-900 dark:text-white">
							Confirmation performance
						</div>

						<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							{performanceMetrics.confirmations}
							confirmed from
							{performanceMetrics.ordersProcessed}
							processed orders
						</div>
					</div>

					<div class="text-lg font-bold text-primary-600">
						{confirmationRate}%
					</div>
				</div>

				<div class="mt-3 h-2 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700">
					<div
						class="h-full rounded-full bg-primary-600 transition-all duration-500"
						style={`width: ${Math.min(confirmationRate, 100)}%`}
					></div>
				</div>
			</div>
		</Card>
	</div>

	<!-- Security / Notifications -->
	<div class="grid gap-6 lg:grid-cols-2">

		<Card>
			<div class="mb-6">
				<h2 class="text-xl font-bold text-gray-900 dark:text-white">
					Security
				</h2>

				<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
					Protect your account and manage access.
				</p>
			</div>

			<div class="divide-y divide-gray-200 dark:divide-gray-700">

				<div class="flex items-center justify-between gap-4 py-4 first:pt-0">
					<div>
						<div class="flex flex-wrap items-center gap-2">
							<span class="text-sm font-semibold text-gray-900 dark:text-white">
								Two-factor authentication
							</span>

							{#if userProfile.twoFactorEnabled}
								<Badge color="green">Enabled</Badge>
							{:else}
								<Badge color="yellow">Not enabled</Badge>
							{/if}
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Add another verification step when signing in.
						</p>
					</div>

					<Toggle bind:checked={userProfile.twoFactorEnabled}>
						<span class="sr-only">
							Enable two-factor authentication
						</span>
					</Toggle>
				</div>

				<div class="flex items-center justify-between gap-4 py-4">
					<div>
						<div class="text-sm font-semibold text-gray-900 dark:text-white">
							Password
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Update your account password.
						</p>
					</div>

					<Button
						size="sm"
						color="alternative"
						onclick={() => (showPasswordModal = true)}
					>
						Change
					</Button>
				</div>

				<div class="flex items-center justify-between gap-4 py-4 last:pb-0">
					<div>
						<div class="text-sm font-semibold text-gray-900 dark:text-white">
							Active sessions
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Review devices currently signed into your account.
						</p>
					</div>

					<Button
						size="sm"
						color="alternative"
						onclick={() => (showSessionsModal = true)}
					>
						Manage
					</Button>
				</div>

			</div>
		</Card>

		<Card>
			<div class="mb-6">
				<h2 class="text-xl font-bold text-gray-900 dark:text-white">
					Notifications
				</h2>

				<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
					Choose how you want to receive operational updates.
				</p>
			</div>

			<div class="space-y-5">

				<div class="notification-row">
					<div>
						<div class="text-sm font-semibold text-gray-900 dark:text-white">
							Email notifications
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Receive account and operational updates by email.
						</p>
					</div>

					<Checkbox bind:checked={userProfile.notifications.email}>
						<span class="sr-only">Email notifications</span>
					</Checkbox>
				</div>

				<div class="notification-row">
					<div>
						<div class="text-sm font-semibold text-gray-900 dark:text-white">
							SMS notifications
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Receive urgent notifications by SMS.
						</p>
					</div>

					<Checkbox bind:checked={userProfile.notifications.sms}>
						<span class="sr-only">SMS notifications</span>
					</Checkbox>
				</div>

				<div class="notification-row">
					<div>
						<div class="text-sm font-semibold text-gray-900 dark:text-white">
							Push notifications
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Receive browser push notifications.
						</p>
					</div>

					<Checkbox bind:checked={userProfile.notifications.push}>
						<span class="sr-only">Push notifications</span>
					</Checkbox>
				</div>

				<div class="notification-row">
					<div>
						<div class="text-sm font-semibold text-gray-900 dark:text-white">
							WhatsApp notifications
						</div>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Receive selected updates through WhatsApp.
						</p>
					</div>

					<Checkbox bind:checked={userProfile.notifications.whatsapp}>
						<span class="sr-only">WhatsApp notifications</span>
					</Checkbox>
				</div>

			</div>
		</Card>
	</div>

	<!-- Account details -->
	<Card>
		<div class="mb-6">
			<h2 class="text-xl font-bold text-gray-900 dark:text-white">
				Account details
			</h2>

			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				Additional information associated with your account.
			</p>
		</div>

		<div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">

			<div>
				<div class="detail-label">Role</div>

				<div class="mt-2">
					<Badge color="blue">{roleLabel}</Badge>
				</div>
			</div>

			<div>
				<div class="detail-label">Timezone</div>

				<div class="detail-value">
					{userProfile.timezone}
				</div>
			</div>

			<div>
				<div class="detail-label">Language</div>

				<div class="detail-value">
					{userProfile.language.toUpperCase()}
				</div>
			</div>

			<div>
				<div class="detail-label">Last login</div>

				<div class="detail-value">
					{formatDateTime(userProfile.lastLogin)}
				</div>
			</div>

		</div>

		<div class="mt-6 rounded-lg border border-gray-200 p-4 dark:border-gray-700">
			<div class="detail-label">About</div>

			<p class="mt-2 text-sm leading-6 text-gray-700 dark:text-gray-300">
				{userProfile.bio}
			</p>
		</div>
	</Card>

	<!-- Activity -->
	<Card>
		<div class="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
			<div>
				<h2 class="text-xl font-bold text-gray-900 dark:text-white">
					Recent activity
				</h2>

				<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
					Recent account and operational activity.
				</p>
			</div>

			<Badge color="gray">
				{activityLog.length} recent events
			</Badge>
		</div>

		<div class="overflow-x-auto">
			<table class="w-full text-left text-sm text-gray-500 dark:text-gray-400">
				<thead class="bg-gray-50 text-xs uppercase text-gray-700 dark:bg-gray-700 dark:text-gray-400">
					<tr>
						<th scope="col" class="px-6 py-3">
							Action
						</th>

						<th scope="col" class="px-6 py-3">
							Timestamp
						</th>

						<th scope="col" class="px-6 py-3">
							IP address
						</th>
					</tr>
				</thead>

				<tbody>
					{#each activityLog as activity, index (activity.timestamp.getTime())}
						<tr class="border-b bg-white dark:border-gray-700 dark:bg-gray-800">
							<td class="px-6 py-4">
								<div class="flex items-center gap-3">
									<div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary-100 text-xs font-bold text-primary-700 dark:bg-primary-900 dark:text-primary-300">
										{index + 1}
									</div>

									<span class="font-medium text-gray-900 dark:text-white">
										{activity.action}
									</span>
								</div>
							</td>

							<td class="whitespace-nowrap px-6 py-4">
								{formatDateTime(activity.timestamp)}
							</td>

							<td class="px-6 py-4 font-mono text-xs">
								{activity.ip}
							</td>
						</tr>
					{:else}
						<tr>
							<td colspan="3" class="px-6 py-12 text-center">
								<div class="text-sm font-medium text-gray-900 dark:text-white">
									No recent activity
								</div>

								<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									Account activity will appear here.
								</div>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>
	</Card>
</div>

<!-- Password modal -->
<Modal bind:open={showPasswordModal} size="md">
	{#snippet header()}
		Change password
	{/snippet}

	<div class="space-y-5">
		<p class="text-sm leading-6 text-gray-500 dark:text-gray-400">
			Choose a strong password that you do not use on another service.
		</p>

		<div>
			<Label for="new-password" class="mb-2 block">
				New password
			</Label>

			<Input
				id="new-password"
				type="password"
				bind:value={password}
				placeholder="••••••••"
				minlength={8}
				required
			/>

			<Helper class="mt-1">
				Use at least 8 characters.
			</Helper>
		</div>

		<div>
			<Label for="confirm-password" class="mb-2 block">
				Confirm password
			</Label>

			<Input
				id="confirm-password"
				type="password"
				bind:value={passwordConfirmation}
				placeholder="••••••••"
				minlength={8}
				required
			/>

			{#if passwordConfirmation && password !== passwordConfirmation}
				<Helper color="red" class="mt-1">
					Passwords do not match.
				</Helper>
			{/if}
		</div>
	</div>

	{#snippet footer()}
		<Button
			color="primary"
			disabled={
				passwordChanging ||
				password.length < 8 ||
				password !== passwordConfirmation
			}
			onclick={changePassword}
		>
			{#if passwordChanging}
				<Spinner size="4" class="me-2" />
				Updating...
			{:else}
				Update password
			{/if}
		</Button>

		<Button color="alternative" onclick={closePasswordModal}>
			Cancel
		</Button>
	{/snippet}
</Modal>

<!-- Sessions modal -->
<Modal bind:open={showSessionsModal} size="lg">
	{#snippet header()}
		Active sessions
	{/snippet}

	<div class="space-y-4">
		<div class="flex flex-col justify-between gap-4 rounded-lg border border-gray-200 p-4 dark:border-gray-700 sm:flex-row sm:items-center">
			<div>
				<div class="flex items-center gap-2">
					<strong class="text-sm text-gray-900 dark:text-white">
						Current browser
					</strong>

					<Badge color="green">Current</Badge>
				</div>

				<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
					Last activity: {formatDateTime(userProfile.lastLogin)}
				</p>
			</div>

			<Badge color="gray">
				{userProfile.timezone}
			</Badge>
		</div>

		<div class="rounded-lg bg-yellow-50 p-4 text-sm text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">
			Session management will become active when the server-side session management endpoint is connected.
		</div>
	</div>

	{#snippet footer()}
		<Button
			color="alternative"
			onclick={() => (showSessionsModal = false)}
		>
			Close
		</Button>
	{/snippet}
</Modal>

<style>
	.metric-card {
		display: flex;
		align-items: center;
		gap: 1rem;
		border: 1px solid rgb(229 231 235);
		border-radius: 0.75rem;
		padding: 1.125rem;
		transition:
			transform 160ms ease,
			box-shadow 160ms ease;
	}

	.metric-card:hover {
		transform: translateY(-2px);
		box-shadow: 0 8px 24px rgb(0 0 0 / 7%);
	}

	:global(.dark) .metric-card {
		border-color: rgb(55 65 81);
	}

	.metric-icon {
		display: flex;
		height: 46px;
		width: 46px;
		flex-shrink: 0;
		align-items: center;
		justify-content: center;
		border-radius: 0.75rem;
		font-size: 20px;
		font-weight: 700;
	}

	.metric-blue {
		background: rgb(219 234 254);
		color: rgb(29 78 216);
	}

	.metric-green {
		background: rgb(220 252 231);
		color: rgb(21 128 61);
	}

	.metric-violet {
		background: rgb(237 233 254);
		color: rgb(109 40 217);
	}

	.metric-amber {
		background: rgb(254 243 199);
		color: rgb(180 83 9);
	}

	:global(.dark) .metric-blue {
		background: rgb(30 58 138 / 35%);
	}

	:global(.dark) .metric-green {
		background: rgb(20 83 45 / 35%);
	}

	:global(.dark) .metric-violet {
		background: rgb(76 29 149 / 35%);
	}

	:global(.dark) .metric-amber {
		background: rgb(120 53 15 / 35%);
	}

	.metric-value {
		font-size: 24px;
		font-weight: 700;
		line-height: 1.1;
		color: rgb(17 24 39);
	}

	.metric-label {
		margin-top: 4px;
		font-size: 12px;
		color: rgb(107 114 128);
	}

	:global(.dark) .metric-value {
		color: white;
	}

	.notification-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 20px;
	}

	.detail-label {
		font-size: 11px;
		font-weight: 600;
		text-transform: uppercase;
		letter-spacing: 0.06em;
		color: rgb(156 163 175);
	}

	.detail-value {
		margin-top: 6px;
		font-size: 14px;
		font-weight: 600;
		color: rgb(17 24 39);
	}

	:global(.dark) .detail-value {
		color: white;
	}

	.sr-only {
		position: absolute;
		width: 1px;
		height: 1px;
		padding: 0;
		margin: -1px;
		overflow: hidden;
		clip: rect(0, 0, 0, 0);
		white-space: nowrap;
		border: 0;
	}
</style>