import { fail, redirect } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import {
	conversationMessages,
	listConversations,
	markConversationRead,
	sendWhatsAppMessage
} from '$lib/server/repo';
import { query } from '$lib/server/db';
import { positiveId, requiredText } from '$lib/server/validation';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
	const conversations = await listConversations();

	const selectedId = Number(
		url.searchParams.get('c') ?? conversations[0]?.id ?? 0
	);

	const active =
		conversations.find((conversation) => conversation.id === selectedId) ??
		null;

	const [messages, templates] = await Promise.all([
		selectedId ? conversationMessages(selectedId) : [],
		query<{
			id: number;
			name: string;
			channel: string;
			body: string;
			category: string;
			active: boolean;
			created_at: string;
		}>(
			`SELECT id, name, channel, body, category, active, created_at
			 FROM message_templates
			 WHERE active = true
			   AND channel = 'whatsapp'
			 ORDER BY category, name`
		)
	]);

	if (active?.unread) {
		await markConversationRead(active.id);
	}

	return {
		conversations,
		active,
		messages,
		templates
	};
};

export const actions: Actions = {
	send: async ({ request, locals }) => {
		if (
			!locals.user ||
			!can(locals.user.role, 'whatsapp.reply')
		) {
			return fail(403, { error: 'Not allowed' });
		}

		const form = await request.formData();

		const conversationId = positiveId(
			form.get('conversationId')
		);

		const body = requiredText(
			form.get('body'),
			'Message',
			4096
		);

		await sendWhatsAppMessage(
			conversationId,
			body,
			locals.user.name
		);

		throw redirect(
			303,
			`/whatsapp?c=${conversationId}`
		);
	}
};