<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Input,
		Select,
		Textarea
	} from 'flowbite-svelte';

	import Pill from '$lib/components/Pill.svelte';
	import { dateTime, initials, timeAgo } from '$lib/format';

	let { data, form } = $props();

	let draft = $state('');
	let searchQuery = $state('');
	let filterStatus = $state('all');
	let showTemplates = $state(true);

	let filteredConversations = $derived(
		data.conversations.filter((conversation: any) => {
			const term = searchQuery.trim().toLowerCase();

			const matchesStatus =
				filterStatus === 'all' ||
				conversation.status === filterStatus;

			const matchesSearch =
				!term ||
				String(conversation.customer_name ?? '')
					.toLowerCase()
					.includes(term) ||
				String(conversation.last_message ?? '')
					.toLowerCase()
					.includes(term) ||
				String(conversation.phone ?? '')
					.toLowerCase()
					.includes(term);

			return matchesStatus && matchesSearch;
		})
	);

	let unreadCount = $derived(
		data.conversations.reduce(
			(total: number, conversation: any) =>
				total + Number(conversation.unread ?? 0),
			0
		)
	);

	let openCount = $derived(
		data.conversations.filter(
			(conversation: any) => conversation.status === 'open'
		).length
	);

	let pendingCount = $derived(
		data.conversations.filter(
			(conversation: any) => conversation.status === 'pending'
		).length
	);

	let characterCount = $derived(draft.length);

	function useTemplate(body: string) {
		draft = body;
	}

	function clearFilters() {
		searchQuery = '';
		filterStatus = 'all';
	}

	function handleComposerKeydown(event: KeyboardEvent) {
		if (
			event.key === 'Enter' &&
			!event.shiftKey &&
			!event.ctrlKey &&
			!event.metaKey
		) {
			event.preventDefault();

			const formElement = event.currentTarget as HTMLTextAreaElement;
			formElement.closest('form')?.requestSubmit();
		}
	}

	function templatePreview(body: string) {
		return String(body ?? '')
			.replace(/\s+/g, ' ')
			.slice(0, 60);
	}
</script>

<svelte:head>
	<title>WhatsApp Inbox · Efoka</title>
	<meta
		name="description"
		content="Manage WhatsApp customer conversations and replies."
	/>
</svelte:head>

<!-- Page header -->
<div class="mb-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
	<div>
		<div class="mb-2 flex items-center gap-2">
			<Badge color="green">WhatsApp</Badge>

			<Badge color="gray">
				{data.conversations.length} conversations
			</Badge>
		</div>

		<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
			One Inbox
		</h1>

		<p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
			Handle customer conversations and send replies from one place.
		</p>
	</div>

	<div class="flex flex-wrap gap-2">
		<Badge color="green">
			{openCount} open
		</Badge>

		<Badge color="yellow">
			{pendingCount} pending
		</Badge>

		{#if unreadCount > 0}
			<Badge color="red">
				{unreadCount} unread
			</Badge>
		{/if}
	</div>
</div>

<!-- Error -->
{#if form?.error}
	<div
		class="mb-5 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-300"
	>
		{form.error}
	</div>
{/if}

<!-- Inbox -->
<div
	class="grid min-h-[calc(100vh-230px)] gap-4 xl:grid-cols-[340px_minmax(0,1fr)]"
>
	<!-- Conversation sidebar -->
	<Card class="!p-0 overflow-hidden">
		<div class="border-b border-gray-200 p-4 dark:border-gray-700">
			<div class="mb-4 flex items-center justify-between gap-3">
				<div>
					<h2 class="font-bold text-gray-900 dark:text-white">
						Conversations
					</h2>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						{filteredConversations.length} shown
					</p>
				</div>

				{#if unreadCount > 0}
					<Badge color="red">
						{unreadCount}
					</Badge>
				{/if}
			</div>

			<div class="space-y-3">
				<Input
					type="search"
					bind:value={searchQuery}
					placeholder="Search conversations..."
				/>

				<div class="flex gap-2">
					<Select bind:value={filterStatus} class="flex-1">
						<option value="all">All statuses</option>
						<option value="open">Open</option>
						<option value="pending">Pending</option>
						<option value="closed">Closed</option>
					</Select>

					<Button
						size="sm"
						color="alternative"
						onclick={clearFilters}
					>
						Clear
					</Button>
				</div>
			</div>
		</div>

		<div class="max-h-[calc(100vh-390px)] overflow-y-auto">
			{#if filteredConversations.length > 0}
				{#each filteredConversations as conversation (conversation.id)}
					<a
						href="/whatsapp?c={conversation.id}"
						class={[
							'block border-b border-gray-100 p-4 transition hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/60',
							data.active?.id === conversation.id ? 'bg-primary-50 dark:bg-gray-800' : ''
						]}
					>
						<div class="flex gap-3">
							<div class="relative shrink-0">
								<div
									class="flex h-11 w-11 items-center justify-center rounded-full bg-primary-100 text-sm font-bold text-primary-700 dark:bg-primary-900/40 dark:text-primary-300"
								>
									{initials(conversation.customer_name)}
								</div>

								{#if conversation.status === 'open'}
									<span
										class="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-green-500 dark:border-gray-900"
									></span>
								{/if}
							</div>

							<div class="min-w-0 flex-1">
								<div class="flex items-start justify-between gap-2">
									<div class="truncate font-semibold text-gray-900 dark:text-white">
										{conversation.customer_name}
									</div>

									<span class="shrink-0 text-[11px] text-gray-400">
										{timeAgo(conversation.last_message_at)}
									</span>
								</div>

								<div class="mt-1 flex items-center justify-between gap-2">
									<div class="truncate text-xs text-gray-500 dark:text-gray-400">
										{conversation.last_message}
									</div>

									{#if conversation.unread > 0}
										<span
											class="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-red-600 px-1.5 text-[10px] font-bold text-white"
										>
											{conversation.unread}
										</span>
									{/if}
								</div>

								<div class="mt-2 flex items-center gap-2">
									<Pill status={conversation.status} />

									{#if conversation.phone}
										<span class="truncate font-mono text-[10px] text-gray-400">
											{conversation.phone}
										</span>
									{/if}
								</div>
							</div>
						</div>
					</a>
				{/each}
			{:else}
				<div class="p-10 text-center">
					<div class="mx-auto flex h-11 w-11 items-center justify-center rounded-full bg-gray-100 text-gray-500 dark:bg-gray-800">
						⌕
					</div>

					<h3 class="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
						No conversations
					</h3>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						Try another search or status filter.
					</p>
				</div>
			{/if}
		</div>
	</Card>

	<!-- Thread -->
	<Card class="!p-0 overflow-hidden">
		{#if data.active}
			<!-- Thread header -->
			<div
				class="flex flex-col justify-between gap-4 border-b border-gray-200 p-4 dark:border-gray-700 sm:flex-row sm:items-center"
			>
				<div class="flex items-center gap-3">
					<div
						class="flex h-11 w-11 items-center justify-center rounded-full bg-primary-100 text-sm font-bold text-primary-700 dark:bg-primary-900/40 dark:text-primary-300"
					>
						{initials(data.active.customer_name)}
					</div>

					<div>
						<div class="flex items-center gap-2">
							<h2 class="font-bold text-gray-900 dark:text-white">
								{data.active.customer_name}
							</h2>

							<Pill status={data.active.status} />
						</div>

						<div class="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-500 dark:text-gray-400">
							{#if data.active.phone}
								<span class="font-mono">{data.active.phone}</span>
							{/if}

							{#if data.active.city}
								<span>{data.active.city}</span>
							{/if}
						</div>
					</div>
				</div>

				<div class="text-xs text-gray-400">
					Conversation #{data.active.id}
				</div>
			</div>

			<!-- Messages -->
			<div
				class="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto bg-gray-50 p-4 dark:bg-gray-900/40"
			>
				{#if data.messages.length > 0}
					{#each data.messages as message (message.id)}
						<div
							class:flex-row-reverse={message.direction === 'out'}
							class="flex w-full"
						>
							<div
								class:max-w-[85%]={true}
								class="sm:max-w-[70%]"
							>
								<div
									class={message.direction === 'in'
										? 'rounded-2xl px-4 py-3 shadow-sm bg-white dark:bg-gray-800 rounded-bl-md'
										: 'rounded-2xl px-4 py-3 shadow-sm bg-green-100 dark:bg-green-900/30 rounded-br-md'}
								>
									<div
										class="whitespace-pre-wrap break-words text-sm leading-6 text-gray-800 dark:text-gray-200"
									>
										{message.body}
									</div>

									<div
										class="mt-2 flex flex-wrap items-center gap-1.5 text-[10px] text-gray-400"
									>
										<span>{message.author}</span>
										<span>·</span>
										<span>{dateTime(message.created_at)}</span>

										{#if message.status}
											<span>·</span>
											<span>{message.status}</span>
										{/if}
									</div>
								</div>
							</div>
						</div>
					{/each}
				{:else}
					<div class="flex flex-1 items-center justify-center">
						<div class="text-center">
							<div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-white text-gray-400 shadow-sm dark:bg-gray-800">
								💬
							</div>

							<h3 class="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
								No messages yet
							</h3>

							<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
								Send the first reply to this conversation.
							</p>
						</div>
					</div>
				{/if}
			</div>

			<!-- Composer -->
			<div class="border-t border-gray-200 bg-white p-4 dark:border-gray-700 dark:bg-gray-900">
				<!-- Templates -->
				<div class="mb-3">
					<button
						type="button"
						class="mb-2 flex items-center gap-2 text-xs font-semibold text-gray-600 dark:text-gray-300"
						onclick={() => (showTemplates = !showTemplates)}
					>
						<span>{showTemplates ? '▾' : '▸'}</span>
						Quick replies
					</button>

					{#if showTemplates}
						{#if data.templates?.length}
							<div class="flex gap-2 overflow-x-auto pb-1">
								{#each data.templates as template (template.id)}
									<button
										type="button"
										class="min-w-[180px] max-w-[240px] rounded-lg border border-gray-200 bg-gray-50 p-2.5 text-left transition hover:border-primary-300 hover:bg-primary-50 dark:border-gray-700 dark:bg-gray-800 dark:hover:border-primary-700"
										onclick={() => useTemplate(template.body)}
									>
										<div class="flex items-center justify-between gap-2">
											<span class="truncate text-xs font-semibold text-gray-800 dark:text-gray-200">
												{template.name}
											</span>

											<Pill status={template.channel} />
										</div>

										<div class="mt-1 line-clamp-2 text-[11px] leading-4 text-gray-500 dark:text-gray-400">
											{templatePreview(template.body)}
										</div>
									</button>
								{/each}
							</div>
						{:else}
							<div class="rounded-lg border border-dashed border-gray-300 p-3 text-xs text-gray-500 dark:border-gray-700 dark:text-gray-400">
								No saved templates are available.
							</div>
						{/if}
					{/if}
				</div>

				<form method="POST" action="?/send">
					<input
						type="hidden"
						name="conversationId"
						value={data.active.id}
					/>

					<Textarea
						name="body"
						bind:value={draft}
						rows={3}
						maxlength={4096}
						placeholder="Write a WhatsApp reply..."
						onkeydown={handleComposerKeydown}
					/>

					<div class="mt-2 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
						<div class="text-[11px] text-gray-400">
							{characterCount.toLocaleString()} / 4,096
							<span class="mx-1">·</span>
							Enter to send
							<span class="mx-1">·</span>
							Shift + Enter for a new line
						</div>

						<Button
							type="submit"
							color="primary"
							disabled={!draft.trim()}
						>
							Send message
						</Button>
					</div>
				</form>
			</div>
		{:else}
			<div class="flex h-full min-h-[500px] items-center justify-center p-10">
				<div class="max-w-sm text-center">
					<div class="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-gray-100 text-2xl dark:bg-gray-800">
						💬
					</div>

					<h2 class="mt-4 text-lg font-bold text-gray-900 dark:text-white">
						Select a conversation
					</h2>

					<p class="mt-2 text-sm leading-6 text-gray-500 dark:text-gray-400">
						Choose a customer from the inbox to view their conversation
						and send a WhatsApp reply.
					</p>
				</div>
			</div>
		{/if}
	</Card>
</div>
