import { fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { listReturns, setReturnStatus } from '$lib/server/repo';
import { oneOf, positiveId } from '$lib/server/validation';

const RETURN_STATUSES = ['requested', 'in_transit', 'received', 'restocked', 'refused'] as const;
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
	const [rows, reasons, totals] = await Promise.all([
		listReturns(),
		query<{ reason: string; count: number }>(
			'SELECT reason, count(*)::int AS count FROM returns GROUP BY reason ORDER BY count DESC'
		),
		query<{ open: number; value: number; rate: number }>(`
			SELECT count(*) FILTER (WHERE status IN ('requested','in_transit'))::int AS open,
			       coalesce(sum(refund_amount), 0) AS value,
			       round(100.0 * count(*) / nullif((SELECT count(*) FROM orders WHERE status IN ('delivered','returned')), 0), 1) AS rate
			FROM returns`)
	]);
	return { rows, reasons, totals: totals[0] };
};

export const actions: Actions = {
	setStatus: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'shipping.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await setReturnStatus(positiveId(form.get('id')), oneOf(form.get('status'), RETURN_STATUSES, 'return status'));
		return { success: 'Return updated' };
	}
};
