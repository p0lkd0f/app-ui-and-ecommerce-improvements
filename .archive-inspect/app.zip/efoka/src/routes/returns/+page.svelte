<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Checkbox,
		Input,
		Label,
		Helper,
		Modal,
		Select,
		Spinner
	} from 'flowbite-svelte';

	import Pill from '$lib/components/Pill.svelte';
	import { date, money } from '$lib/format';

	let { data, form } = $props();

	const STATUSES = [
		'requested',
		'in_transit',
		'received',
		'restocked',
		'refused'
	];

	const REASONS = [
		'damaged',
		'wrong_item',
		'not_as_described',
		'changed_mind'
	];

	let statusFilter = $state('all');
	let reasonFilter = $state('all');
	let search = $state('');
	let selectedReturns = $state<Set<number>>(new Set());
	let showCreateModal = $state(false);
	let showExportModal = $state(false);
	let showLabelModal = $state(false);
	let selectedReturnId = $state<number | null>(null);
	let processing = $state(false);

	const rows = $derived(
		data.rows.filter((row: any) => {
			const matchesStatus =
				statusFilter === 'all' || row.status === statusFilter;

			const matchesReason =
				reasonFilter === 'all' || row.reason === reasonFilter;

			const query = search.trim().toLowerCase();

			const matchesSearch =
				!query ||
				String(row.reference ?? '').toLowerCase().includes(query) ||
				String(row.customer_name ?? '').toLowerCase().includes(query) ||
				String(row.city ?? '').toLowerCase().includes(query) ||
				String(row.reason ?? '').toLowerCase().includes(query);

			return matchesStatus && matchesReason && matchesSearch;
		})
	);

	const maxReason = $derived(
		Math.max(1, ...data.reasons.map((r: any) => r.count))
	);

	const visibleIds = $derived(rows.map((row: any) => row.id));

	const allVisibleSelected = $derived(
		visibleIds.length > 0 &&
			visibleIds.every((id: number) => selectedReturns.has(id))
	);

	const selectedCount = $derived(selectedReturns.size);

	const selectedValue = $derived(
		rows
			.filter((row: any) => selectedReturns.has(row.id))
			.reduce(
				(total: number, row: any) =>
					total + Number(row.refund_amount ?? 0),
				0
			)
	);

	function toggleReturnSelection(returnId: number) {
		const next = new Set(selectedReturns);

		if (next.has(returnId)) {
			next.delete(returnId);
		} else {
			next.add(returnId);
		}

		selectedReturns = next;
	}

	function toggleAllVisible() {
		const next = new Set(selectedReturns);

		if (allVisibleSelected) {
			visibleIds.forEach((id: number) => next.delete(id));
		} else {
			visibleIds.forEach((id: number) => next.add(id));
		}

		selectedReturns = next;
	}

	function clearSelection() {
		selectedReturns = new Set();
	}

	function openLabelModal(returnId: number) {
		selectedReturnId = returnId;
		showLabelModal = true;
	}

	function closeLabelModal() {
		showLabelModal = false;
		selectedReturnId = null;
	}

	function createReturnLabel() {
		if (selectedReturnId === null) return;

		/*
		 * Keep this connected to the real server action when the
		 * return-label endpoint exists.
		 */
		closeLabelModal();
	}

	function bulkProcess() {
		if (selectedReturns.size === 0) return;

		processing = true;

		/*
		 * The existing page does not expose a bulk-processing
		 * server action, so don't invent one here.
		 */
		setTimeout(() => {
			processing = false;
		}, 350);
	}

	function resetFilters() {
		statusFilter = 'all';
		reasonFilter = 'all';
		search = '';
	}

	function statusLabel(status: string) {
		return status
			.split('_')
			.map((part) => part.charAt(0).toUpperCase() + part.slice(1))
			.join(' ');
	}

	function reasonLabel(reason: string) {
		return reason
			.split('_')
			.map((part) => part.charAt(0).toUpperCase() + part.slice(1))
			.join(' ');
	}

	function statusColor(status: string) {
		switch (status) {
			case 'requested':
				return 'yellow';
			case 'in_transit':
				return 'blue';
			case 'received':
				return 'purple';
			case 'restocked':
				return 'green';
			case 'refused':
				return 'red';
			default:
				return 'gray';
		}
	}
</script>

<svelte:head>
	<title>Returns · Efoka</title>
	<meta
		name="description"
		content="Manage returns, refunds, return reasons and parcel recovery."
	/>
</svelte:head>

<div class="space-y-6">

	<!-- Header -->
	<div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
		<div>
			<div class="mb-1 text-xs font-semibold uppercase tracking-wider text-primary-600">
				Operations
			</div>

			<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
				Returns
			</h1>

			<p class="mt-2 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
				Track returned parcels, manage return statuses and monitor refund exposure.
			</p>
		</div>

		<div class="flex flex-wrap gap-2">
			<Button
				color="alternative"
				onclick={() => (showExportModal = true)}
			>
				Export report
			</Button>

			<Button
				color="primary"
				onclick={() => (showCreateModal = true)}
			>
				Create return
			</Button>
		</div>
	</div>

	{#if form?.success}
		<div
			class="rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-300"
			role="status"
		>
			{form.success}
		</div>
	{/if}

	<!-- Summary -->
	<div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">

		<Card>
			<div class="flex items-start justify-between">
				<div>
					<p class="text-sm font-medium text-gray-500 dark:text-gray-400">
						Open returns
					</p>

					<p class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
						{data.totals?.open ?? 0}
					</p>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						Awaiting pickup or inspection
					</p>
				</div>

				<Badge color="yellow">
					Open
				</Badge>
			</div>
		</Card>

		<Card>
			<div class="flex items-start justify-between">
				<div>
					<p class="text-sm font-medium text-gray-500 dark:text-gray-400">
						Value at risk
					</p>

					<p class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
						{money(data.totals?.value ?? 0)}
					</p>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						COD value of returned parcels
					</p>
				</div>

				<Badge color="red">
					Exposure
				</Badge>
			</div>
		</Card>

		<Card>
			<div class="flex items-start justify-between">
				<div>
					<p class="text-sm font-medium text-gray-500 dark:text-gray-400">
						Return rate
					</p>

					<p class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
						{data.totals?.rate ?? 0}%
					</p>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						Of closed deliveries
					</p>
				</div>

				<Badge color="blue">
					Rate
				</Badge>
			</div>
		</Card>

	</div>

	<!-- Main content -->
	<div class="grid gap-6 xl:grid-cols-3">

		<Card class="overflow-hidden p-0 xl:col-span-2">

			<!-- Toolbar -->
			<div class="border-b border-gray-200 p-5 dark:border-gray-700">

				<div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
					<div>
						<div class="flex items-center gap-2">
							<h2 class="text-xl font-bold text-gray-900 dark:text-white">
								Returns
							</h2>

							<Badge color="gray">
								{rows.length}
							</Badge>
						</div>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Manage return requests and parcel recovery.
						</p>
					</div>

					{#if selectedCount > 0}
						<div class="flex flex-wrap items-center gap-2">
							<Badge color="blue">
								{selectedCount} selected
							</Badge>

							<Button
								size="sm"
								color="primary"
								disabled={processing}
								onclick={bulkProcess}
							>
								{#if processing}
									<Spinner size="4" class="me-2" />
									Processing...
								{:else}
									Process selected
								{/if}
							</Button>

							<Button
								size="sm"
								color="alternative"
								onclick={clearSelection}
							>
								Clear
							</Button>
						</div>
					{/if}
				</div>

				<!-- Filters -->
				<div class="mt-5 grid gap-4 md:grid-cols-3">

					<div class="md:col-span-1">
						<Label for="return-search" class="mb-2 block">
							Search
						</Label>

						<Input
							id="return-search"
							bind:value={search}
							placeholder="Order, customer, city..."
						/>
					</div>

					<div>
						<Label for="return-status" class="mb-2 block">
							Status
						</Label>

						<select
							id="return-status"
							bind:value={statusFilter}
							class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
						>
							<option value="all">All statuses</option>

							{#each STATUSES as status}
								<option value={status}>
									{statusLabel(status)}
								</option>
							{/each}
						</select>
					</div>

					<div>
						<Label for="return-reason" class="mb-2 block">
							Reason
						</Label>

						<select
							id="return-reason"
							bind:value={reasonFilter}
							class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
						>
							<option value="all">All reasons</option>

							{#each REASONS as reason}
								<option value={reason}>
									{reasonLabel(reason)}
								</option>
							{/each}
						</select>
					</div>

				</div>

				{#if statusFilter !== 'all' || reasonFilter !== 'all' || search}
					<div class="mt-4 flex items-center justify-between gap-3">
						<p class="text-xs text-gray-500 dark:text-gray-400">
							Showing {rows.length} filtered returns
						</p>

						<Button
							size="xs"
							color="alternative"
							onclick={resetFilters}
						>
							Reset filters
						</Button>
					</div>
				{/if}
			</div>

			<!-- Table -->
			<div class="overflow-x-auto">
				<table class="w-full text-left text-sm text-gray-500 dark:text-gray-400">
					<thead class="bg-gray-50 text-xs uppercase text-gray-700 dark:bg-gray-700 dark:text-gray-400">
						<tr>
							<th scope="col" class="w-12 px-5 py-3">
								<Checkbox
									checked={allVisibleSelected}
									onchange={toggleAllVisible}
								>
									<span class="sr-only">
										Select all visible returns
									</span>
								</Checkbox>
							</th>

							<th scope="col" class="px-5 py-3">
								Order
							</th>

							<th scope="col" class="px-5 py-3">
								Customer
							</th>

							<th scope="col" class="px-5 py-3">
								Reason
							</th>

							<th scope="col" class="px-5 py-3">
								Status
							</th>

							<th scope="col" class="px-5 py-3 text-right">
								Refund
							</th>

							<th scope="col" class="px-5 py-3">
								Actions
							</th>
						</tr>
					</thead>

					<tbody>
						{#each rows as row (row.id)}
							<tr class="border-b bg-white transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700/50">

								<td class="px-5 py-4">
									<Checkbox
										checked={selectedReturns.has(row.id)}
										onchange={() => toggleReturnSelection(row.id)}
									>
										<span class="sr-only">
											Select {row.reference}
										</span>
									</Checkbox>
								</td>

								<td class="px-5 py-4">
									<div class="font-mono text-xs font-semibold text-gray-900 dark:text-white">
										{row.reference}
									</div>

									<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
										{date(row.created_at)}
									</div>
								</td>

								<td class="px-5 py-4">
									<div class="font-medium text-gray-900 dark:text-white">
										{row.customer_name}
									</div>

									<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
										{row.city}
									</div>
								</td>

								<td class="px-5 py-4">
									<Badge color="gray">
										{reasonLabel(row.reason)}
									</Badge>
								</td>

								<td class="px-5 py-4">
									<Pill status={row.status} />
								</td>

								<td class="px-5 py-4 text-right font-semibold text-gray-900 dark:text-white">
									{money(row.refund_amount)}
								</td>

								<td class="px-5 py-4">
									<div class="flex flex-wrap items-center gap-2">

										<form
											method="POST"
											action="?/setStatus"
											class="flex items-center gap-2"
										>
											<input
												type="hidden"
												name="id"
												value={row.id}
											/>

											<select
												name="status"
												class="rounded-lg border border-gray-300 bg-gray-50 px-2.5 py-2 text-xs text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
											>
												{#each STATUSES as status}
													<option
														value={status}
														selected={status === row.status}
													>
														{statusLabel(status)}
													</option>
												{/each}
											</select>

											<Button
												type="submit"
												size="xs"
												color="alternative"
											>
												Save
											</Button>
										</form>

										<Button
											size="xs"
											color="alternative"
											onclick={() => openLabelModal(row.id)}
										>
											Label
										</Button>

									</div>
								</td>
							</tr>
						{:else}
							<tr>
								<td colspan="7" class="px-6 py-16 text-center">
									<div class="mx-auto max-w-sm">
										<div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400">
											↩
										</div>

										<h3 class="mt-4 text-sm font-semibold text-gray-900 dark:text-white">
											No returns found
										</h3>

										<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
											No returns match the current filters.
										</p>

										{#if statusFilter !== 'all' || reasonFilter !== 'all' || search}
											<Button
												size="sm"
												color="alternative"
												class="mt-4"
												onclick={resetFilters}
											>
												Clear filters
											</Button>
										{/if}
									</div>
								</td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>

			<!-- Footer -->
			{#if rows.length > 0}
				<div class="flex flex-col justify-between gap-3 border-t border-gray-200 px-5 py-4 sm:flex-row sm:items-center dark:border-gray-700">
					<p class="text-xs text-gray-500 dark:text-gray-400">
						{rows.length} return{rows.length === 1 ? '' : 's'} displayed
					</p>

					{#if selectedCount > 0}
						<p class="text-xs text-gray-500 dark:text-gray-400">
							Selected refund value:
							<span class="font-semibold text-gray-900 dark:text-white">
								{money(selectedValue)}
							</span>
						</p>
					{/if}
				</div>
			{/if}

		</Card>

		<!-- Reasons -->
		<Card>
			<div class="mb-6">
				<div class="flex items-center justify-between gap-3">
					<div>
						<h2 class="text-xl font-bold text-gray-900 dark:text-white">
							Why parcels come back
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Return reasons across the current dataset.
						</p>
					</div>

					<Badge color="gray">
						{data.reasons.length}
					</Badge>
				</div>
			</div>

			<div class="space-y-5">
				{#each data.reasons as reason (reason.reason)}
					<div>
						<div class="mb-2 flex items-center justify-between gap-3">
							<span class="text-sm font-medium text-gray-900 dark:text-white">
								{reasonLabel(reason.reason)}
							</span>

							<span class="text-xs font-semibold text-gray-500 dark:text-gray-400">
								{reason.count}
							</span>
						</div>

						<div class="h-2.5 w-full overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700">
							<div
								class="h-full rounded-full bg-primary-600 transition-all duration-500"
								style={`width: ${(reason.count / maxReason) * 100}%`}
							></div>
						</div>
					</div>
				{:else}
					<div class="rounded-lg border border-dashed border-gray-300 p-8 text-center dark:border-gray-600">
						<p class="text-sm font-medium text-gray-900 dark:text-white">
							No return reasons available
						</p>

						<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							Reason analytics will appear here.
						</p>
					</div>
				{/each}
			</div>
		</Card>
	</div>
</div>

<!-- Create return -->
<Modal bind:open={showCreateModal} size="md">
	{#snippet header()}
		Create return
	{/snippet}

	<div class="space-y-5">
		<p class="text-sm leading-6 text-gray-500 dark:text-gray-400">
			Create a return from an existing order.
		</p>

		<div>
			<Label for="return-order" class="mb-2 block">
				Order reference
			</Label>

			<Input
				id="return-order"
				name="reference"
				placeholder="ORD-000123"
			/>

			<Helper class="mt-1">
				The order reference must belong to an existing order.
			</Helper>
		</div>

		<div>
			<Label for="return-reason-create" class="mb-2 block">
				Reason
			</Label>

			<select
				id="return-reason-create"
				class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
			>
				<option value="">Select a reason</option>

				{#each REASONS as reason}
					<option value={reason}>
						{reasonLabel(reason)}
					</option>
				{/each}
			</select>
		</div>

		<div>
			<Label for="return-notes" class="mb-2 block">
				Notes
			</Label>

			<textarea
				id="return-notes"
				rows="4"
				class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
				placeholder="Optional return notes..."
			></textarea>
		</div>

		<div class="rounded-lg bg-yellow-50 p-4 text-sm text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300">
			The existing page does not expose a create-return server action, so this dialog does not submit fake data.
		</div>
	</div>

	{#snippet footer()}
		<Button
			color="primary"
			onclick={() => (showCreateModal = false)}
		>
			Close
		</Button>

		<Button
			color="alternative"
			onclick={() => (showCreateModal = false)}
		>
			Cancel
		</Button>
	{/snippet}
</Modal>

<!-- Label modal -->
<Modal bind:open={showLabelModal} size="md">
	{#snippet header()}
		Create return label
	{/snippet}

	<div class="space-y-4">
		<p class="text-sm leading-6 text-gray-500 dark:text-gray-400">
			Generate a shipping label for the selected return.
		</p>

		<div class="rounded-lg border border-gray-200 p-4 dark:border-gray-700">
			<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
				Return ID
			</div>

			<div class="mt-2 font-mono text-sm font-semibold text-gray-900 dark:text-white">
				{selectedReturnId ?? '—'}
			</div>
		</div>

		<div class="rounded-lg bg-blue-50 p-4 text-sm text-blue-800 dark:bg-blue-900/20 dark:text-blue-300">
			Connect this action to the real return-label endpoint when it is available.
		</div>
	</div>

	{#snippet footer()}
		<Button
			color="alternative"
			onclick={closeLabelModal}
		>
			Close
		</Button>

		<Button
			color="primary"
			onclick={createReturnLabel}
		>
			Create label
		</Button>
	{/snippet}
</Modal>

<!-- Export modal -->
<Modal bind:open={showExportModal} size="md">
	{#snippet header()}
		Export returns report
	{/snippet}

	<div class="space-y-4">
		<p class="text-sm leading-6 text-gray-500 dark:text-gray-400">
			Export the currently filtered return dataset.
		</p>

		<div class="grid gap-3 sm:grid-cols-2">
			<div class="rounded-lg border border-gray-200 p-4 dark:border-gray-700">
				<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
					Rows
				</div>

				<div class="mt-1 text-xl font-bold text-gray-900 dark:text-white">
					{rows.length}
				</div>
			</div>

			<div class="rounded-lg border border-gray-200 p-4 dark:border-gray-700">
				<div class="text-xs font-medium uppercase tracking-wide text-gray-400">
					Refund value
				</div>

				<div class="mt-1 text-xl font-bold text-gray-900 dark:text-white">
					{money(
						rows.reduce(
							(total: number, row: any) =>
								total + Number(row.refund_amount ?? 0),
							0
						)
					)}
				</div>
			</div>
		</div>

		<div class="rounded-lg bg-gray-50 p-4 text-sm text-gray-600 dark:bg-gray-800 dark:text-gray-300">
			No export server action was provided by the current page, so this UI does not fabricate an export request.
		</div>
	</div>

	{#snippet footer()}
		<Button
			color="alternative"
			onclick={() => (showExportModal = false)}
		>
			Close
		</Button>
	{/snippet}
</Modal>