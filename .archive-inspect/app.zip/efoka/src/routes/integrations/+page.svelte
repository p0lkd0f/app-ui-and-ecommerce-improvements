<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { dateTime } from '$lib/format';
	import {
		Badge,
		Button,
		Card,
		Input,
		Label,
		Modal,
		Select
	} from 'flowbite-svelte';

	let { data, form } = $props();

	const KINDS: Record<string, string> = {
		store: 'Store Platforms',
		shipping: 'Shipping & Carriers',
		messaging: 'Messaging',
		analytics: 'Analytics & Data'
	};

	const KIND_ICONS: Record<string, string> = {
		store: '🛍️',
		shipping: '🚚',
		messaging: '💬',
		analytics: '📊'
	};

	const CATALOG = [
		{
			provider: 'Shopify',
			purpose: 'Store orders',
			category: 'store',
			description: 'Sync orders, customers and fulfillment data.',
			color: 'green'
		},
		{
			provider: 'WooCommerce',
			purpose: 'Store orders',
			category: 'store',
			description: 'Connect your WooCommerce commerce operation.',
			color: 'purple'
		},
		{
			provider: 'YouCan',
			purpose: 'Store orders',
			category: 'store',
			description: 'Import and synchronize YouCan orders.',
			color: 'blue'
		},
		{
			provider: 'PrestaShop',
			purpose: 'Store orders',
			category: 'store',
			description: 'Connect your PrestaShop store.',
			color: 'orange'
		},
		{
			provider: 'Google Sheets',
			purpose: 'Order import',
			category: 'analytics',
			description: 'Import operational data from spreadsheets.',
			color: 'green'
		},
		{
			provider: 'LightFunnels',
			purpose: 'Lead capture',
			category: 'store',
			description: 'Capture and route incoming commerce leads.',
			color: 'indigo'
		},
		{
			provider: 'Facebook Leads',
			purpose: 'Lead capture',
			category: 'messaging',
			description: 'Bring Meta lead submissions into Efoka.',
			color: 'blue'
		},
		{
			provider: 'TikTok Forms',
			purpose: 'Lead capture',
			category: 'messaging',
			description: 'Import TikTok lead form submissions.',
			color: 'gray'
		},
		{
			provider: 'WhatsApp Cloud API',
			purpose: 'Customer messages',
			category: 'messaging',
			description: 'Customer messaging through Meta infrastructure.',
			color: 'green'
		},
		{
			provider: 'Instagram',
			purpose: 'Customer messages',
			category: 'messaging',
			description: 'Connect Instagram customer conversations.',
			color: 'pink'
		},
		{
			provider: 'Hotjar',
			purpose: 'Consent-based insights',
			category: 'analytics',
			description: 'Privacy-conscious visitor behavior insights.',
			color: 'orange'
		}
	];

	const categories = [
		{ value: 'all', name: 'All integrations' },
		{ value: 'store', name: 'Store platforms' },
		{ value: 'shipping', name: 'Shipping' },
		{ value: 'messaging', name: 'Messaging' },
		{ value: 'analytics', name: 'Analytics' }
	];

	let showAddModal = $state(false);
	let selectedCategory = $state('all');
	let searchQuery = $state('');
	let selectedProvider = $state('');
	let apiKey = $state('');
	let accountId = $state('');

	const integrations = $derived(data.integrations ?? []);
	const stores = $derived(data.stores ?? []);

	const kinds = $derived(
		[...new Set(integrations.map((integration) => integration.kind))]
	);

	const connectedCount = $derived(
		integrations.filter((integration) => integration.status === 'connected').length
	);

	const disconnectedCount = $derived(
		integrations.filter((integration) => integration.status !== 'connected').length
	);

	const storeCount = $derived(stores.length);

	const filteredCatalog = $derived(
		CATALOG.filter((integration) => {
			const query = searchQuery.trim().toLowerCase();

			const matchesCategory =
				selectedCategory === 'all' ||
				integration.category === selectedCategory;

			const matchesSearch =
				!query ||
				integration.provider.toLowerCase().includes(query) ||
				integration.purpose.toLowerCase().includes(query) ||
				integration.description.toLowerCase().includes(query);

			return matchesCategory && matchesSearch;
		})
	);

	function openAddModal(provider = '') {
		selectedProvider = provider;
		apiKey = '';
		accountId = '';
		showAddModal = true;
	}

	function closeAddModal() {
		showAddModal = false;
	}

	function getKindIntegrations(kind: string) {
		return integrations.filter((integration) => integration.kind === kind);
	}

	function getProviderInitial(provider: string) {
		return provider.slice(0, 1).toUpperCase();
	}
</script>

<svelte:head>
	<title>Integrations | Efoka.ma</title>
	<meta
		name="description"
		content="Manage Efoka.ma commerce, messaging, shipping and analytics integrations."
	/>
</svelte:head>

<div class="page">

	<!-- Header -->
	<div class="page-header">
		<div>
			<div class="eyebrow">
				<span class="eyebrow-dot"></span>
				PLATFORM CONNECTIONS
			</div>

			<h1>Integrations</h1>

			<p>
				Connect your commerce stack, automate data flows and manage
				third-party services from one place.
			</p>
		</div>

		<Button
			class="add-button"
			onclick={() => openAddModal()}
		>
			<span class="button-icon">+</span>
			Add integration
		</Button>
	</div>

	<!-- Notifications -->
	{#if form?.success}
		<div class="notice success-notice" role="status">
			<div class="notice-icon">✓</div>
			<div>
				<strong>Integration updated</strong>
				<span>{form.success}</span>
			</div>
		</div>
	{/if}

	{#if form?.error}
		<div class="notice error-notice" role="alert">
			<div class="notice-icon">!</div>
			<div>
				<strong>Integration action failed</strong>
				<span>{form.error}</span>
			</div>
		</div>
	{/if}

	<!-- Overview -->
	<div class="stats-grid">

		<Card class="stat-card">
			<div class="stat-icon purple">⌘</div>
			<div class="stat-content">
				<span class="stat-label">Connected</span>
				<strong>{connectedCount}</strong>
				<span class="stat-caption">Active connections</span>
			</div>
			<Badge color="green" class="stat-badge">
				Live
			</Badge>
		</Card>

		<Card class="stat-card">
			<div class="stat-icon orange">◌</div>
			<div class="stat-content">
				<span class="stat-label">Attention</span>
				<strong>{disconnectedCount}</strong>
				<span class="stat-caption">Disconnected</span>
			</div>
			<Badge color={disconnectedCount ? 'yellow' : 'green'} class="stat-badge">
				{disconnectedCount ? 'Review' : 'Healthy'}
			</Badge>
		</Card>

		<Card class="stat-card">
			<div class="stat-icon blue">▣</div>
			<div class="stat-content">
				<span class="stat-label">Stores</span>
				<strong>{storeCount}</strong>
				<span class="stat-caption">Connected stores</span>
			</div>
		</Card>

		<Card class="stat-card">
			<div class="stat-icon green">↗</div>
			<div class="stat-content">
				<span class="stat-label">Sync engine</span>
				<strong>Ready</strong>
				<span class="stat-caption">Automated synchronization</span>
			</div>
			<Badge color="green" class="stat-badge">
				Operational
			</Badge>
		</Card>

	</div>

	<!-- Security / policy -->
	<Card class="policy-card">
		<div class="policy-icon">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
				<path d="M12 3 5 6v5c0 4.8 2.9 8.7 7 10 4.1-1.3 7-5.2 7-10V6l-7-3z" />
				<path d="m9 12 2 2 4-4" />
			</svg>
		</div>

		<div class="policy-content">
			<div class="policy-title-row">
				<h2>Connection policy</h2>
				<Badge color="indigo">Protected</Badge>
			</div>

			<p>
				Connections remain disabled until server-side credentials and the
				provider adapter are configured. WhatsApp messages are recorded
				in the workspace; sending through Meta requires an approved
				WhatsApp Cloud API setup. Visitor analytics must only be enabled
				after consent and publication of the applicable privacy notice.
			</p>
		</div>
	</Card>

	<!-- Catalog -->
	<Card class="catalog-card">

		<div class="section-header">
			<div>
				<div class="section-kicker">AVAILABLE CONNECTORS</div>
				<h2>Integration catalog</h2>
				<p>
					Choose a provider to connect to your Efoka workspace.
				</p>
			</div>

			<div class="catalog-controls">
				<div class="search-box">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
						<circle cx="11" cy="11" r="7" />
						<path d="m20 20-4-4" />
					</svg>

					<Input
						type="search"
						placeholder="Search integrations..."
						bind:value={searchQuery}
					/>
				</div>

				<Select
					items={categories}
					bind:value={selectedCategory}
					class="category-select"
				/>
			</div>
		</div>

		<div class="catalog-grid">
			{#each filteredCatalog as integration (integration.provider)}
				<button
					type="button"
					class="integration-card"
					onclick={() => openAddModal(integration.provider)}
				>
					<div class="integration-top">
						<div class="provider-logo">
							{getProviderInitial(integration.provider)}
						</div>

						<Badge color="green" class="available-badge">
							Available
						</Badge>
					</div>

					<div class="integration-info">
						<h3>{integration.provider}</h3>
						<span>{integration.purpose}</span>
						<p>{integration.description}</p>
					</div>

					<div class="integration-footer">
						<span>Connect</span>
						<span class="arrow">→</span>
					</div>
				</button>
			{/each}

			{#if filteredCatalog.length === 0}
				<div class="empty-state">
					<div class="empty-icon">⌕</div>
					<strong>No integrations found</strong>
					<span>Try a different provider or category.</span>
				</div>
			{/if}
		</div>

	</Card>

	<!-- Stores -->
	<Card class="stores-card">

		<div class="section-header">
			<div>
				<div class="section-kicker">COMMERCE ACCOUNTS</div>
				<h2>Connected stores</h2>
				<p>Manage your commerce storefront connections.</p>
			</div>

			<Button color="alternative" onclick={() => openAddModal()}>
				+ Add store
			</Button>
		</div>

		{#if stores.length > 0}
			<div class="store-list">

				{#each stores as store (store.id)}
					<div class="store-row">

						<div class="store-main">
							<div class="store-logo">
								{getProviderInitial(store.name)}
							</div>

							<div>
								<strong>{store.name}</strong>
								<span>{store.domain}</span>
							</div>
						</div>

						<div class="store-meta">
							<div>
								<span>Currency</span>
								<strong>{store.currency}</strong>
							</div>

							<div class="store-status">
								<Pill status="connected" />
							</div>
						</div>

						<div class="store-actions">
							<Button size="sm" color="alternative">
								Configure
							</Button>

							<Button size="sm" color="red">
								Disconnect
							</Button>
						</div>

					</div>
				{/each}

			</div>
		{:else}
			<div class="empty-state compact">
				<div class="empty-icon">▣</div>
				<strong>No stores connected</strong>
				<span>Connect your first commerce platform to begin.</span>
				<Button onclick={() => openAddModal()}>
					Connect a store
				</Button>
			</div>
		{/if}

	</Card>

	<!-- Connected integrations -->
	{#each kinds as kind (kind)}
		{@const kindItems = getKindIntegrations(kind)}

		<Card class="connections-card">

			<div class="connection-header">
				<div class="connection-heading">

					<div class="kind-icon">
						{KIND_ICONS[kind] ?? '🔌'}
					</div>

					<div>
						<div class="section-kicker">CONNECTION GROUP</div>
						<h2>{KINDS[kind] ?? kind}</h2>
					</div>

				</div>

				<div class="connection-summary">
					<Badge color="indigo">
						{kindItems.length} connected
					</Badge>
				</div>
			</div>

			{#if kindItems.length > 0}

				<div class="connection-list">

					{#each kindItems as integration (integration.id)}

						<div class="connection-row">

							<div class="connection-provider">
								<div class="provider-avatar">
									{getProviderInitial(integration.provider)}
								</div>

								<div>
									<strong>{integration.provider}</strong>
									<span>{integration.store_name}</span>
								</div>
							</div>

							<div class="connection-field">
								<span>Account</span>
								<strong class="mono">
									{integration.account_ref ?? '—'}
								</strong>
							</div>

							<div class="connection-field">
								<span>Last sync</span>
								<strong>
									{dateTime(integration.last_sync)}
								</strong>
							</div>

							<div class="connection-status">
								<Pill status={integration.status} />
							</div>

							<div class="connection-actions">

								<form method="POST" action="?/sync">
									<input
										type="hidden"
										name="id"
										value={integration.id}
									/>

									<Button
										type="submit"
										size="sm"
										color="alternative"
										disabled={integration.status !== 'connected'}
									>
										Sync
									</Button>
								</form>

								<form method="POST" action="?/toggle">
									<input
										type="hidden"
										name="id"
										value={integration.id}
									/>

									<input
										type="hidden"
										name="status"
										value={integration.status === 'connected'
											? 'disconnected'
											: 'connected'}
									/>

									{#if integration.status === 'connected'}
										<Button
											type="submit"
											size="sm"
											color="red"
										>
											Disconnect
										</Button>
									{:else}
										<Button
											type="submit"
											size="sm"
										>
											Connect
										</Button>
									{/if}
								</form>

							</div>

						</div>

					{/each}

				</div>

			{/if}

		</Card>
	{/each}

</div>

<!-- Add integration modal -->
<Modal
	bind:open={showAddModal}
	size="md"
	title="Connect integration"
	class="integration-modal"
>
	<div class="modal-intro">
		<div class="modal-provider">
			{selectedProvider
				? getProviderInitial(selectedProvider)
				: '＋'}
		</div>

		<div>
			<h3>
				{selectedProvider || 'New integration'}
			</h3>

			<p>
				Connect a provider to your Efoka workspace.
			</p>
		</div>
	</div>

	<div class="modal-form">

		<div class="field">
			<Label for="integration-type">
				Integration type
			</Label>

			<Select
				id="integration-type"
				items={[
					{ value: '', name: 'Select integration type...' },
					{ value: 'shopify', name: 'Shopify' },
					{ value: 'woocommerce', name: 'WooCommerce' },
					{ value: 'meta', name: 'Meta / WhatsApp' },
					{ value: 'stripe', name: 'Stripe' }
				]}
				bind:value={selectedProvider}
			/>
		</div>

		<div class="field">
			<Label for="api-key">
				API key / access token
			</Label>

			<Input
				id="api-key"
				type="password"
				placeholder="Enter your API key"
				bind:value={apiKey}
			/>

			<span class="field-help">
				Credentials are handled by the configured server-side adapter.
			</span>
		</div>

		<div class="field">
			<Label for="account-id">
				Store / account ID
			</Label>

			<Input
				id="account-id"
				type="text"
				placeholder="Enter store or account ID"
				bind:value={accountId}
			/>
		</div>

	</div>

	{#snippet footer()}
		<div class="modal-actions">
			<Button color="alternative" onclick={closeAddModal}>
				Cancel
			</Button>

			<Button onclick={closeAddModal}>
				Connect integration
			</Button>
		</div>
	{/snippet}
</Modal>

<style>
	.page {
		max-width: 1480px;
		margin: 0 auto;
		padding: 28px;
	}

	.page-header {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		gap: 24px;
		margin-bottom: 28px;
	}

	.eyebrow,
	.section-kicker {
		display: flex;
		align-items: center;
		gap: 7px;
		color: #6366f1;
		font-size: 10px;
		font-weight: 800;
		letter-spacing: 0.11em;
	}

	.eyebrow-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: #6366f1;
		box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
	}

	.page-header h1 {
		margin: 7px 0 5px;
		color: #0f172a;
		font-size: 30px;
		font-weight: 800;
		letter-spacing: -0.04em;
	}

	.page-header p {
		max-width: 680px;
		margin: 0;
		color: #64748b;
		font-size: 14px;
		line-height: 1.6;
	}

	:global(.add-button) {
		white-space: nowrap;
	}

	.button-icon {
		margin-right: 5px;
		font-size: 18px;
		line-height: 1;
	}

	.notice {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 13px 15px;
		margin-bottom: 18px;
		border-radius: 12px;
		font-size: 13px;
	}

	.notice > div:last-child {
		display: flex;
		flex-direction: column;
		gap: 2px;
	}

	.notice-icon {
		width: 28px;
		height: 28px;
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 8px;
		font-weight: 800;
	}

	.success-notice {
		border: 1px solid #bbf7d0;
		background: #f0fdf4;
		color: #166534;
	}

	.success-notice .notice-icon {
		background: #dcfce7;
	}

	.error-notice {
		border: 1px solid #fecaca;
		background: #fef2f2;
		color: #991b1b;
	}

	.error-notice .notice-icon {
		background: #fee2e2;
	}

	.stats-grid {
		display: grid;
		grid-template-columns: repeat(4, minmax(0, 1fr));
		gap: 14px;
		margin-bottom: 18px;
	}

	:global(.stat-card) {
		position: relative;
		display: flex;
		align-items: center;
		gap: 14px;
		min-height: 110px;
		box-sizing: border-box;
		border: 1px solid #e2e8f0;
		border-radius: 14px;
		box-shadow: 0 5px 18px rgba(15, 23, 42, 0.04);
	}

	.stat-icon {
		width: 42px;
		height: 42px;
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 11px;
		font-size: 19px;
		font-weight: 700;
	}

	.stat-icon.purple {
		background: #eef2ff;
		color: #4f46e5;
	}

	.stat-icon.orange {
		background: #fff7ed;
		color: #ea580c;
	}

	.stat-icon.blue {
		background: #eff6ff;
		color: #2563eb;
	}

	.stat-icon.green {
		background: #f0fdf4;
		color: #16a34a;
	}

	.stat-content {
		display: flex;
		flex-direction: column;
		min-width: 0;
	}

	.stat-label {
		color: #64748b;
		font-size: 11px;
		font-weight: 600;
	}

	.stat-content strong {
		margin-top: 1px;
		color: #0f172a;
		font-size: 22px;
		line-height: 1.25;
	}

	.stat-caption {
		margin-top: 1px;
		color: #94a3b8;
		font-size: 10px;
	}

	:global(.stat-badge) {
		position: absolute;
		top: 15px;
		right: 15px;
	}

	:global(.policy-card) {
		display: flex;
		align-items: flex-start;
		gap: 15px;
		margin-bottom: 18px;
		border: 1px solid #e0e7ff;
		border-radius: 14px;
		background: linear-gradient(135deg, #fafaff, #ffffff);
	}

	.policy-icon {
		width: 40px;
		height: 40px;
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 10px;
		background: #eef2ff;
		color: #4f46e5;
	}

	.policy-icon svg {
		width: 21px;
		height: 21px;
	}

	.policy-content {
		min-width: 0;
	}

	.policy-title-row {
		display: flex;
		align-items: center;
		gap: 10px;
		margin-bottom: 5px;
	}

	.policy-title-row h2,
	.section-header h2,
	.connection-header h2 {
		margin: 0;
		color: #0f172a;
		font-size: 17px;
		font-weight: 750;
		letter-spacing: -0.02em;
	}

	.policy-content p {
		max-width: 1050px;
		margin: 0;
		color: #64748b;
		font-size: 12px;
		line-height: 1.7;
	}

	:global(.catalog-card),
	:global(.stores-card),
	:global(.connections-card) {
		margin-bottom: 18px;
		border: 1px solid #e2e8f0;
		border-radius: 15px;
		box-shadow: 0 5px 18px rgba(15, 23, 42, 0.035);
	}

	.section-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 20px;
		padding-bottom: 18px;
		border-bottom: 1px solid #f1f5f9;
	}

	.section-header p {
		margin: 4px 0 0;
		color: #94a3b8;
		font-size: 12px;
	}

	.catalog-controls {
		display: flex;
		align-items: center;
		gap: 10px;
	}

	.search-box {
		position: relative;
		width: 260px;
	}

	.search-box svg {
		position: absolute;
		z-index: 2;
		left: 11px;
		top: 50%;
		width: 16px;
		height: 16px;
		transform: translateY(-50%);
		color: #94a3b8;
		pointer-events: none;
	}

	.search-box :global(input) {
		padding-left: 35px;
	}

	:global(.category-select) {
		min-width: 175px;
	}

	.catalog-grid {
		display: grid;
		grid-template-columns: repeat(4, minmax(0, 1fr));
		gap: 12px;
		padding-top: 18px;
	}

	.integration-card {
		position: relative;
		min-width: 0;
		padding: 16px;
		text-align: left;
		border: 1px solid #e2e8f0;
		border-radius: 13px;
		background: #fff;
		cursor: pointer;
		transition:
			transform 0.16s ease,
			border-color 0.16s ease,
			box-shadow 0.16s ease;
	}

	.integration-card:hover {
		transform: translateY(-2px);
		border-color: #c7d2fe;
		box-shadow: 0 12px 26px rgba(15, 23, 42, 0.08);
	}

	.integration-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 8px;
	}

	.provider-logo,
	.provider-avatar,
	.store-logo {
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		background: linear-gradient(135deg, #eef2ff, #ede9fe);
		color: #4f46e5;
		font-weight: 800;
	}

	.provider-logo {
		width: 40px;
		height: 40px;
		border-radius: 11px;
		font-size: 16px;
	}

	.integration-info {
		margin-top: 15px;
	}

	.integration-info h3 {
		margin: 0;
		color: #0f172a;
		font-size: 14px;
		font-weight: 700;
	}

	.integration-info > span {
		display: block;
		margin-top: 3px;
		color: #6366f1;
		font-size: 10px;
		font-weight: 700;
	}

	.integration-info p {
		min-height: 32px;
		margin: 8px 0 0;
		color: #64748b;
		font-size: 11px;
		line-height: 1.45;
	}

	.integration-footer {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-top: 15px;
		padding-top: 11px;
		border-top: 1px solid #f1f5f9;
		color: #4f46e5;
		font-size: 11px;
		font-weight: 700;
	}

	.arrow {
		font-size: 16px;
		transition: transform 0.15s ease;
	}

	.integration-card:hover .arrow {
		transform: translateX(3px);
	}

	.empty-state {
		grid-column: 1 / -1;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		gap: 5px;
		min-height: 180px;
		color: #64748b;
	}

	.empty-state strong {
		color: #334155;
		font-size: 14px;
	}

	.empty-state span {
		font-size: 12px;
	}

	.empty-icon {
		width: 42px;
		height: 42px;
		display: grid;
		place-items: center;
		margin-bottom: 5px;
		border-radius: 12px;
		background: #f1f5f9;
		color: #64748b;
		font-size: 21px;
	}

	.store-list,
	.connection-list {
		display: flex;
		flex-direction: column;
		padding-top: 4px;
	}

	.store-row,
	.connection-row {
		display: flex;
		align-items: center;
		gap: 18px;
		padding: 15px 0;
		border-bottom: 1px solid #f1f5f9;
	}

	.store-row:last-child,
	.connection-row:last-child {
		border-bottom: 0;
	}

	.store-main,
	.connection-provider {
		display: flex;
		align-items: center;
		gap: 11px;
		min-width: 260px;
		flex: 1;
	}

	.store-logo {
		width: 38px;
		height: 38px;
		border-radius: 10px;
	}

	.store-main div:last-child,
	.connection-provider div:last-child {
		display: flex;
		flex-direction: column;
		gap: 3px;
		min-width: 0;
	}

	.store-main strong,
	.connection-provider strong {
		color: #1e293b;
		font-size: 13px;
	}

	.store-main span,
	.connection-provider span {
		overflow: hidden;
		color: #94a3b8;
		font-size: 11px;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.store-meta {
		display: flex;
		align-items: center;
		gap: 45px;
	}

	.store-meta > div {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.store-meta span,
	.connection-field span {
		color: #94a3b8;
		font-size: 9px;
		font-weight: 700;
		text-transform: uppercase;
		letter-spacing: 0.06em;
	}

	.store-meta strong,
	.connection-field strong {
		color: #334155;
		font-size: 11px;
	}

	.store-actions,
	.connection-actions {
		display: flex;
		align-items: center;
		gap: 7px;
	}

	.connection-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 15px;
		padding-bottom: 15px;
		border-bottom: 1px solid #f1f5f9;
	}

	.connection-heading {
		display: flex;
		align-items: center;
		gap: 11px;
	}

	.kind-icon {
		width: 40px;
		height: 40px;
		display: grid;
		place-items: center;
		border-radius: 11px;
		background: #f8fafc;
		font-size: 18px;
	}

	.connection-row {
		padding: 14px 0;
	}

	.provider-avatar {
		width: 36px;
		height: 36px;
		border-radius: 9px;
		font-size: 13px;
	}

	.connection-field {
		display: flex;
		flex-direction: column;
		gap: 3px;
		width: 135px;
	}

	.connection-status {
		width: 90px;
	}

	.connection-actions {
		margin-left: auto;
	}

	.connection-actions form {
		margin: 0;
	}

	.mono {
		font-family:
			ui-monospace,
			SFMono-Regular,
			Menlo,
			Monaco,
			Consolas,
			monospace;
	}

	.compact {
		padding: 35px 0;
	}

	.modal-intro {
		display: flex;
		align-items: center;
		gap: 13px;
		padding: 12px;
		margin-bottom: 20px;
		border-radius: 12px;
		background: #f8fafc;
	}

	.modal-provider {
		width: 44px;
		height: 44px;
		display: grid;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 11px;
		background: linear-gradient(135deg, #4f46e5, #7c3aed);
		color: white;
		font-weight: 800;
	}

	.modal-intro h3 {
		margin: 0;
		color: #0f172a;
		font-size: 15px;
		font-weight: 750;
	}

	.modal-intro p {
		margin: 3px 0 0;
		color: #64748b;
		font-size: 11px;
	}

	.modal-form {
		display: flex;
		flex-direction: column;
		gap: 17px;
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 7px;
	}

	.field-help {
		color: #94a3b8;
		font-size: 10px;
		line-height: 1.4;
	}

	.modal-actions {
		display: flex;
		justify-content: flex-end;
		gap: 9px;
		width: 100%;
	}

	@media (max-width: 1200px) {
		.catalog-grid {
			grid-template-columns: repeat(3, minmax(0, 1fr));
		}

		.stats-grid {
			grid-template-columns: repeat(2, minmax(0, 1fr));
		}
	}

	@media (max-width: 900px) {
		.page {
			padding: 20px;
		}

		.page-header {
			align-items: flex-start;
			flex-direction: column;
		}

		.section-header {
			align-items: flex-start;
			flex-direction: column;
		}

		.catalog-controls {
			width: 100%;
		}

		.search-box {
			flex: 1;
			width: auto;
		}

		:global(.category-select) {
			min-width: 180px;
		}

		.store-row,
		.connection-row {
			align-items: flex-start;
			flex-wrap: wrap;
		}

		.connection-field {
			width: auto;
			min-width: 130px;
		}

		.connection-actions {
			width: 100%;
			margin-left: 0;
		}
	}

	@media (max-width: 650px) {
		.page {
			padding: 15px;
		}

		.stats-grid {
			grid-template-columns: 1fr;
		}

		.catalog-grid {
			grid-template-columns: 1fr;
		}

		.catalog-controls {
			align-items: stretch;
			flex-direction: column;
		}

		:global(.category-select) {
			width: 100%;
		}

		.store-meta {
			width: 100%;
			justify-content: space-between;
			padding-left: 49px;
		}

		.store-actions {
			width: 100%;
			padding-left: 49px;
		}

		.connection-field {
			padding-left: 47px;
		}

		.connection-status {
			padding-left: 47px;
		}

		.connection-actions {
			padding-left: 47px;
		}
	}
</style>