import { error, fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { listIntegrations, listStores, setIntegrationStatus } from '$lib/server/repo';
import { query } from '$lib/server/db';
import { oneOf, positiveId } from '$lib/server/validation';

const INTEGRATION_STATUSES = ['connected', 'disconnected'] as const;
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user || !can(locals.user.role, 'integrations.manage'))
		throw error(403, 'Only owners can manage integrations');
	const [integrations, stores] = await Promise.all([listIntegrations(), listStores()]);
	return { integrations, stores };
};

export const actions: Actions = {
	toggle: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'integrations.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await setIntegrationStatus(positiveId(form.get('id')), oneOf(form.get('status'), INTEGRATION_STATUSES, 'integration status'));
		return { success: 'Integration updated' };
	},
	sync: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'integrations.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('id'));
		const integration = await query<{ provider: string; status: string }>('SELECT provider, status FROM integrations WHERE id = $1', [id]);
		if (!integration[0]) return fail(404, { error: 'Integration not found' });
		if (integration[0].status !== 'connected') return fail(409, { error: 'Connect this integration before syncing' });
		// A successful sync is only recorded after a provider adapter completes. This avoids misleading “synced” data.
		return fail(501, { error: `${integration[0].provider} needs its provider adapter and credentials configured before it can sync` });
	}
};
