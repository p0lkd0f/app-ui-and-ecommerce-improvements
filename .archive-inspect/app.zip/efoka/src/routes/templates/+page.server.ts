import { error, fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { oneOf, positiveId, requiredText } from '$lib/server/validation';
import type { Actions, PageServerLoad } from './$types';

const CHANNELS = ['whatsapp', 'instagram', 'sms'] as const;

export const load: PageServerLoad = async ({ locals }) => {
	if (!locals.user || !can(locals.user.role, 'whatsapp.reply')) throw error(403, 'Not allowed');
	return { templates: await query<{ id: number; name: string; channel: string; body: string; category: string; active: boolean; created_at: string }>('SELECT * FROM message_templates ORDER BY active DESC, name') };
};

export const actions: Actions = {
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'whatsapp.reply')) return fail(403, { error: 'Not allowed' });
		try {
			const form = await request.formData();
			const name = requiredText(form.get('name'), 'Template name', 100);
			const body = requiredText(form.get('body'), 'Message', 4096);
			const channel = oneOf(form.get('channel'), CHANNELS, 'channel');
			const category = requiredText(form.get('category'), 'Category', 60);
			await query('INSERT INTO message_templates (name, channel, body, category) VALUES ($1,$2,$3,$4)', [name, channel, body, category]);
			return { success: `${name} was saved` };
		} catch (err) { return fail(400, { error: err instanceof Error ? err.message : 'Could not save template' }); }
	},
	remove: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'whatsapp.reply')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await query('DELETE FROM message_templates WHERE id = $1', [positiveId(form.get('id'))]);
		return { success: 'Template removed' };
	}
};
