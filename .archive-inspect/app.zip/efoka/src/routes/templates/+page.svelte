<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Input,
		Label,
		Select,
		Table,
		TableBody,
		TableBodyCell,
		TableBodyRow,
		TableHead,
		TableHeadCell,
		Textarea
	} from 'flowbite-svelte';

	import Pill from '$lib/components/Pill.svelte';
	import { date } from '$lib/format';

	let { data, form } = $props();

	const CHANNELS = ['whatsapp', 'instagram', 'sms'];

	let search = $state('');
	let channelFilter = $state('all');
	let categoryFilter = $state('all');

	let filteredTemplates = $derived(
		data.templates.filter((template: any) => {
			const term = search.trim().toLowerCase();

			const matchesSearch =
				!term ||
				String(template.name ?? '').toLowerCase().includes(term) ||
				String(template.body ?? '').toLowerCase().includes(term) ||
				String(template.category ?? '').toLowerCase().includes(term);

			const matchesChannel =
				channelFilter === 'all' ||
				template.channel === channelFilter;

			const matchesCategory =
				categoryFilter === 'all' ||
				template.category === categoryFilter;

			return matchesSearch && matchesChannel && matchesCategory;
		})
	);

	let categories = $derived(
		[
			...new Set(
				data.templates
					.map((template: any) => template.category)
					.filter(Boolean)
			)
		].sort()
	);

	let activeTemplates = $derived(
		data.templates.filter((template: any) => template.active).length
	);

	let inactiveTemplates = $derived(
		data.templates.filter((template: any) => !template.active).length
	);

	let channelCounts = $derived(
		CHANNELS.map((channel) => ({
			channel,
			count: data.templates.filter(
				(template: any) => template.channel === channel
			).length
		}))
	);

	function formatChannel(channel: string) {
		return String(channel)
			.replace(/_/g, ' ')
			.replace(/\b\w/g, (char) => char.toUpperCase());
	}

	function extractPlaceholders(body: string) {
		return [
			...new Set(
				String(body ?? '').match(/\{\{[^}]+\}\}/g) ?? []
			)
		];
	}

	function resetFilters() {
		search = '';
		channelFilter = 'all';
		categoryFilter = 'all';
	}
</script>

<svelte:head>
	<title>Templates · Efoka</title>
	<meta
		name="description"
		content="Manage approved customer response templates."
	/>
</svelte:head>

<!-- Header -->
<div class="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-start">
	<div>
		<div class="mb-2 flex items-center gap-2">
			<Badge color="blue">Messaging</Badge>

			<Badge color="gray">
				{data.templates.length} templates
			</Badge>
		</div>

		<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
			Templates
		</h1>

		<p class="mt-2 max-w-2xl text-sm leading-6 text-gray-500 dark:text-gray-400">
			Manage approved customer replies across your messaging channels.
		</p>
	</div>

	<div class="flex flex-wrap gap-2">
		<Badge color="green">
			{activeTemplates} active
		</Badge>

		{#if inactiveTemplates > 0}
			<Badge color="gray">
				{inactiveTemplates} inactive
			</Badge>
		{/if}
	</div>
</div>

<!-- Feedback -->
{#if form?.success}
	<div
		class="mb-6 rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-300"
	>
		<div class="font-medium">{form.success}</div>
	</div>
{/if}

{#if form?.error}
	<div
		class="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-300"
	>
		<div class="font-medium">{form.error}</div>
	</div>
{/if}

<!-- Overview -->
<div class="mb-6 grid gap-4 md:grid-cols-3">
	<Card>
		<div class="flex items-start justify-between">
			<div>
				<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Templates
				</div>

				<div class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{data.templates.length}
				</div>
			</div>

			<Badge color="blue">Total</Badge>
		</div>

		<p class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			Approved replies available to your team
		</p>
	</Card>

	<Card>
		<div class="flex items-start justify-between">
			<div>
				<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Active
				</div>

				<div class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{activeTemplates}
				</div>
			</div>

			<Badge color="green">Ready</Badge>
		</div>

		<p class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			Templates currently marked active
		</p>
	</Card>

	<Card>
		<div class="flex items-start justify-between">
			<div>
				<div class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Channels
				</div>

				<div class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{CHANNELS.length}
				</div>
			</div>

			<Badge color="purple">Messaging</Badge>
		</div>

		<div class="mt-3 flex flex-wrap gap-2">
			{#each channelCounts as item (item.channel)}
				<span class="text-xs text-gray-500 dark:text-gray-400">
					{formatChannel(item.channel)} · {item.count}
				</span>
			{/each}
		</div>
	</Card>
</div>

<!-- Main -->
<div class="grid gap-6 xl:grid-cols-12">
	<!-- Templates -->
	<div class="xl:col-span-8">
		<Card>
			<div class="mb-5">
				<div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
					<div>
						<h2 class="text-lg font-bold text-gray-900 dark:text-white">
							Approved replies
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Search, filter and manage your message templates.
						</p>
					</div>

					<Button
						size="sm"
						color="alternative"
						onclick={resetFilters}
					>
						Reset
					</Button>
				</div>

				<div class="mt-5 grid gap-3 md:grid-cols-[1fr_180px_180px]">
					<div>
						<Label for="template-search" class="sr-only">
							Search templates
						</Label>

						<Input
							id="template-search"
							bind:value={search}
							placeholder="Search name, message or category..."
						/>
					</div>

					<Select bind:value={channelFilter}>
						<option value="all">All channels</option>

						{#each CHANNELS as channel (channel)}
							<option value={channel}>
								{formatChannel(channel)}
							</option>
						{/each}
					</Select>

					<Select bind:value={categoryFilter}>
						<option value="all">All categories</option>

						{#each categories as category (category)}
							<option value={category}>{category}</option>
						{/each}
					</Select>
				</div>
			</div>

			{#if filteredTemplates.length > 0}
				<div class="overflow-x-auto">
					<Table hoverable={true}>
						<TableHead>
							<TableHeadCell>Template</TableHeadCell>
							<TableHeadCell>Channel</TableHeadCell>
							<TableHeadCell>Category</TableHeadCell>
							<TableHeadCell>Message</TableHeadCell>
							<TableHeadCell>Status</TableHeadCell>
							<TableHeadCell>Created</TableHeadCell>
							<TableHeadCell class="text-right">
								Action
							</TableHeadCell>
						</TableHead>

						<TableBody>
							{#each filteredTemplates as template (template.id)}
								<TableBodyRow>
									<TableBodyCell>
										<div class="min-w-[150px]">
											<div class="font-semibold text-gray-900 dark:text-white">
												{template.name}
											</div>

											<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
												#{template.id}
											</div>
										</div>
									</TableBodyCell>

									<TableBodyCell>
										<Pill status={template.channel} />
									</TableBodyCell>

									<TableBodyCell>
										<Badge color="gray">
											{template.category}
										</Badge>
									</TableBodyCell>

									<TableBodyCell>
										<div class="max-w-[300px]">
											<div
												class="line-clamp-2 text-sm leading-5 text-gray-600 dark:text-gray-300"
											>
												{template.body}
											</div>

											{#if extractPlaceholders(template.body).length > 0}
												<div class="mt-2 flex flex-wrap gap-1">
													{#each extractPlaceholders(template.body) as placeholder (placeholder)}
														<code
															class="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] text-gray-600 dark:bg-gray-800 dark:text-gray-300"
														>
															{placeholder}
														</code>
													{/each}
												</div>
											{/if}
										</div>
									</TableBodyCell>

									<TableBodyCell>
										{#if template.active}
											<Badge color="green">
												Active
											</Badge>
										{:else}
											<Badge color="gray">
												Inactive
											</Badge>
										{/if}
									</TableBodyCell>

									<TableBodyCell>
										<span class="whitespace-nowrap text-xs text-gray-500 dark:text-gray-400">
											{date(template.created_at)}
										</span>
									</TableBodyCell>

									<TableBodyCell class="text-right">
										<form
											method="POST"
											action="?/remove"
											onsubmit={(event) => {
												if (
													!confirm(
														`Remove template "${template.name}"?`
													)
												) {
													event.preventDefault();
												}
											}}
										>
											<input
												type="hidden"
												name="id"
												value={template.id}
											/>

											<Button size="xs" color="red">
												Remove
											</Button>
										</form>
									</TableBodyCell>
								</TableBodyRow>
							{/each}
						</TableBody>
					</Table>
				</div>
			{:else}
				<div class="rounded-xl border border-dashed border-gray-300 p-12 text-center dark:border-gray-700">
					<div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 text-xl text-gray-500 dark:bg-gray-800">
						⌕
					</div>

					<h3 class="mt-4 text-sm font-semibold text-gray-900 dark:text-white">
						No templates found
					</h3>

					<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
						Try another search term or clear the filters.
					</p>

					<div class="mt-4">
						<Button
							size="sm"
							color="alternative"
							onclick={resetFilters}
						>
							Clear filters
						</Button>
					</div>
				</div>
			{/if}
		</Card>
	</div>

	<!-- Create -->
	<div class="xl:col-span-4">
		<Card>
			<div class="mb-5">
				<div class="flex items-start justify-between gap-3">
					<div>
						<h2 class="text-lg font-bold text-gray-900 dark:text-white">
							New template
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Create an approved reply for your team.
						</p>
					</div>

					<Badge color="blue">Create</Badge>
				</div>
			</div>

			<form method="POST" action="?/create" class="space-y-5">
				<div>
					<Label for="template-name" class="mb-2 block">
						Template name
					</Label>

					<Input
						id="template-name"
						name="name"
						placeholder="Delivery reminder"
						required
					/>
				</div>

				<div>
					<Label for="template-channel" class="mb-2 block">
						Channel
					</Label>

					<Select id="template-channel" name="channel">
						{#each CHANNELS as channel (channel)}
							<option value={channel}>
								{formatChannel(channel)}
							</option>
						{/each}
					</Select>
				</div>

				<div>
					<Label for="template-category" class="mb-2 block">
						Category
					</Label>

					<Input
						id="template-category"
						name="category"
						value="operations"
						placeholder="operations"
						required
					/>

					<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
						Examples: operations, delivery, payment, support.
					</p>
				</div>

				<div>
					<Label for="template-body" class="mb-2 block">
						Message
					</Label>

					<Textarea
						id="template-body"
						name="body"
						rows={7}
						placeholder="Hi &#123;&#123;customer_name&#125;&#125;, your order &#123;&#123;order_reference&#125;&#125; is on its way."
						required
					/>

					<p class="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
						Maximum 4096 characters.
					</p>
				</div>

				<div class="rounded-lg border border-gray-200 bg-gray-50 p-3 dark:border-gray-700 dark:bg-gray-800/50">
					<div class="text-xs font-semibold text-gray-700 dark:text-gray-300">
						Supported placeholders
					</div>

					<div class="mt-2 flex flex-wrap gap-1.5">
						{#each [
							'{{customer_name}}',
							'{{order_reference}}',
							'{{tracking_code}}'
						] as placeholder (placeholder)}
							<code
								class="rounded bg-white px-2 py-1 text-[11px] text-gray-600 shadow-sm dark:bg-gray-900 dark:text-gray-300"
							>
								{placeholder}
							</code>
						{/each}
					</div>
				</div>

				<Button type="submit" color="primary" class="w-full">
					Save template
				</Button>
			</form>
		</Card>

		<!-- Channel distribution -->
		<Card class="mt-6">
			<div class="mb-4">
				<h2 class="text-base font-bold text-gray-900 dark:text-white">
					Channel distribution
				</h2>

				<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
					Templates available for each messaging channel.
				</p>
			</div>

			<div class="space-y-3">
				{#each channelCounts as item (item.channel)}
					<button
						type="button"
						class="flex w-full items-center justify-between rounded-lg p-2 text-left transition hover:bg-gray-50 dark:hover:bg-gray-800"
						onclick={() => {
							channelFilter = item.channel;
						}}
					>
						<div class="flex items-center gap-3">
							<Pill status={item.channel} />

							<span class="text-sm text-gray-500 dark:text-gray-400">
								templates
							</span>
						</div>

						<span class="text-sm font-semibold text-gray-900 dark:text-white">
							{item.count}
						</span>
					</button>
				{/each}
			</div>
		</Card>
	</div>
</div>

<!-- Placeholder information -->
<Card class="mt-6">
	<div class="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
		<div>
			<div class="flex items-center gap-2">
				<Badge color="purple">Personalization</Badge>

				<h2 class="text-base font-bold text-gray-900 dark:text-white">
					Message placeholders
				</h2>
			</div>

			<p class="mt-2 max-w-3xl text-sm leading-6 text-gray-500 dark:text-gray-400">
				Placeholders can be included in template content and are displayed
				automatically when reviewing saved templates.
			</p>
		</div>

		<div class="flex flex-wrap gap-2">
			{#each [
				'{{customer_name}}',
				'{{order_reference}}',
				'{{tracking_code}}'
			] as placeholder (placeholder)}
				<code
					class="rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-xs font-medium text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"
				>
					{placeholder}
				</code>
			{/each}
		</div>
	</div>
</Card>