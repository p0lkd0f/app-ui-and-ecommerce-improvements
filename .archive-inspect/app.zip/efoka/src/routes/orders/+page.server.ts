import { fail } from '@sveltejs/kit';
import { query } from '$lib/server/db';
import { createManualOrder, listOrders, setOrderStatus } from '$lib/server/repo';
import { can } from '$lib/permissions';
import { oneOf, positiveId, requiredText, ORDER_STATUSES } from '$lib/server/validation';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
	const filters = {
		status: url.searchParams.get('status') ?? 'all',
		confirmation: url.searchParams.get('confirmation') ?? 'all',
		city: url.searchParams.get('city') ?? 'all',
		search: url.searchParams.get('q') ?? ''
	};
	const [orders, cities, counts, stores, products] = await Promise.all([
		listOrders(filters),
		query<{ city: string }>('SELECT DISTINCT city FROM customers ORDER BY city'),
		query<{ status: string; count: number }>('SELECT status, count(*)::int AS count FROM orders GROUP BY status'),
		query<{ id: number; name: string }>('SELECT id, name FROM stores ORDER BY name'),
		query<{ id: number; sku: string; name: string; price: number; stock: number }>('SELECT id, sku, name, price, stock FROM products WHERE active = true ORDER BY name')
	]);
	return { orders, filters, cities: cities.map((c) => c.city), counts, stores, products };
};

export const actions: Actions = {
	setStatus: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const id = positiveId(form.get('id'));
		const status = oneOf(form.get('status'), ORDER_STATUSES, 'order status');
		await setOrderStatus(id, status, locals.user.name);
		return { success: true };
	},
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		try {
			const form = await request.formData();
			const quantity = Number(form.get('quantity'));
			const shippingFee = Number(form.get('shipping_fee'));
			if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100) return fail(400, { error: 'Quantity must be between 1 and 100' });
			if (!Number.isFinite(shippingFee) || shippingFee < 0 || shippingFee > 10000) return fail(400, { error: 'Enter a valid shipping fee' });
			const order = await createManualOrder({
				storeId: positiveId(form.get('store_id')), productId: positiveId(form.get('product_id')), quantity,
				fullName: requiredText(form.get('full_name'), 'Customer name', 120),
				phone: requiredText(form.get('phone'), 'Phone number', 32).replace(/[^+\d]/g, ''),
				city: requiredText(form.get('city'), 'City', 80),
				address: typeof form.get('address') === 'string' ? String(form.get('address')).trim().slice(0, 500) : '',
				shippingFee, paymentMethod: oneOf(form.get('payment_method'), ['cod', 'prepaid'] as const, 'payment method'), actor: locals.user.name
			});
			return { created: order };
		} catch (err) {
			return fail(400, { error: err instanceof Error ? err.message : 'Unable to create order' });
		}
	}
};
