<script lang="ts">
	import { goto } from '$app/navigation';
	import { page } from '$app/state';
	import Pill from '$lib/components/Pill.svelte';
	import { money, timeAgo } from '$lib/format';

	let { data, form } = $props();

	const STATUSES = [
		'all',
		'new',
		'confirmed',
		'packed',
		'shipped',
		'delivered',
		'cancelled',
		'returned'
	];

	const CONFIRMATIONS = [
		'all',
		'pending',
		'confirmed',
		'unreachable',
		'scheduled',
		'cancelled'
	];

	const activeFilters = $derived(
		[
			data.filters.search,
			data.filters.status !== 'all' ? data.filters.status : '',
			data.filters.confirmation !== 'all' ? data.filters.confirmation : '',
			data.filters.city !== 'all' ? data.filters.city : ''
		].filter(Boolean).length
	);

	const totalOrders = $derived(
		data.counts.reduce((sum, item) => sum + item.count, 0)
	);

	const pendingConfirmation = $derived(
		countFor('pending')
	);

	function apply(key: string, value: string) {
		const params = new URLSearchParams(page.url.searchParams);

		if (value && value !== 'all') {
			params.set(key, value);
		} else {
			params.delete(key);
		}

		goto(`/orders?${params.toString()}`, {
			keepFocus: true,
			noScroll: true
		});
	}

	function countFor(status: string): number {
		if (status === 'all') {
			return totalOrders;
		}

		return data.counts.find((item) => item.status === status)?.count ?? 0;
	}

	function clearFilters() {
		goto('/orders', {
			keepFocus: true,
			noScroll: true
		});
	}

	function formatSource(source: string) {
		return source.replaceAll('_', ' ');
	}
</script>

<svelte:head>
	<title>Orders</title>
</svelte:head>

{#if form?.error}
	<div class="error">
		{form.error}
	</div>
{/if}

{#if form?.created}
	<div class="notice">
		Order
		<a href="/orders/{form.created.id}" class="mono">
			{form.created.reference}
		</a>
		is ready for confirmation.
	</div>
{/if}

<div class="page-header">
	<div>
		<h1>Orders</h1>
		<p class="muted">
			Manage incoming orders, confirmation and fulfillment.
		</p>
	</div>

	<div class="header-actions">
		<span class="muted tiny">
			{totalOrders} total
		</span>

		<a class="btn primary" href="#new-order">
			+ New order
		</a>
	</div>
</div>

<div class="stats-grid">
	<div class="stat-card">
		<span class="stat-label">All orders</span>
		<strong>{totalOrders}</strong>
		<span class="muted tiny">Across all statuses</span>
	</div>

	<div class="stat-card">
		<span class="stat-label">New</span>
		<strong>{countFor('new')}</strong>
		<span class="muted tiny">Need processing</span>
	</div>

	<div class="stat-card">
		<span class="stat-label">Pending confirmation</span>
		<strong>{pendingConfirmation}</strong>
		<span class="muted tiny">Awaiting customer contact</span>
	</div>

	<div class="stat-card">
		<span class="stat-label">Shipped</span>
		<strong>{countFor('shipped')}</strong>
		<span class="muted tiny">Currently in transit</span>
	</div>
</div>

<details class="panel quick-create" id="new-order">
	<summary>
		<div>
			<strong>New manual order</strong>
			<span class="muted tiny">
				· add an order from a call, message or counter sale
			</span>
		</div>

		<span class="btn primary">Create order</span>
	</summary>

	<div class="panel-body">
		<form method="POST" action="?/create" class="order-entry">
			<div class="entry-section">
				<span class="entry-label">Customer</span>

				<div class="grid cols-3">
					<div class="field">
						<label for="order-name">Full name</label>
						<input
							id="order-name"
							name="full_name"
							autocomplete="name"
							required
						/>
					</div>

					<div class="field">
						<label for="order-phone">Phone</label>
						<input
							id="order-phone"
							name="phone"
							autocomplete="tel"
							inputmode="tel"
							required
						/>
					</div>

					<div class="field">
						<label for="order-city">City</label>
						<input
							id="order-city"
							name="city"
							autocomplete="address-level2"
							required
						/>
					</div>

					<div
						class="field"
						style="grid-column: span 3"
					>
						<label for="order-address">
							Delivery address
						</label>

						<input
							id="order-address"
							name="address"
							autocomplete="street-address"
						/>
					</div>
				</div>
			</div>

			<div class="entry-section">
				<span class="entry-label">Order</span>

				<div class="grid cols-3">
					<div class="field">
						<label for="order-store">Store</label>

						<select
							id="order-store"
							name="store_id"
							required
						>
							{#each data.stores as store (store.id)}
								<option value={store.id}>
									{store.name}
								</option>
							{/each}
						</select>
					</div>

					<div class="field">
						<label for="order-product">Product</label>

						<select
							id="order-product"
							name="product_id"
							required
						>
							{#each data.products as product (product.id)}
								<option
									value={product.id}
									disabled={product.stock === 0}
								>
									{product.name}
									·
									{money(product.price)}
									·
									{product.stock}
									left
								</option>
							{/each}
						</select>
					</div>

					<div class="field">
						<label for="order-quantity">Quantity</label>

						<input
							id="order-quantity"
							name="quantity"
							type="number"
							min="1"
							max="100"
							value="1"
							required
						/>
					</div>

					<div class="field">
						<label for="order-payment">Payment</label>

						<select
							id="order-payment"
							name="payment_method"
						>
							<option value="cod">
								Cash on delivery
							</option>
							<option value="prepaid">
								Prepaid
							</option>
						</select>
					</div>

					<div class="field">
						<label for="order-shipping">
							Shipping fee
						</label>

						<input
							id="order-shipping"
							name="shipping_fee"
							type="number"
							min="0"
							step="0.01"
							value="35"
							required
						/>
					</div>

					<div class="field action-field">
						<span class="field-spacer"></span>

						<button
							class="primary"
							type="submit"
						>
							Create confirmation-ready order
						</button>
					</div>
				</div>
			</div>
		</form>
	</div>
</details>

<div class="panel">
	<div class="panel-head orders-head">
		<div>
			<h2>All orders</h2>

			<span class="hint">
				{data.orders.length} shown
			</span>
		</div>

		{#if activeFilters > 0}
			<button
				class="btn small"
				type="button"
				onclick={clearFilters}
			>
				Clear filters
			</button>
		{/if}
	</div>

	<div class="panel-body filters">
		<div class="search-field">
			<label for="order-search" class="sr-only">
				Search orders
			</label>

			<input
				id="order-search"
				type="search"
				placeholder="Search reference, customer or phone"
				value={data.filters.search}
				onchange={(event) =>
					apply(
						'q',
						event.currentTarget.value.trim()
					)}
			/>
		</div>

		<select
			aria-label="Filter by order status"
			value={data.filters.status}
			onchange={(event) =>
				apply(
					'status',
					event.currentTarget.value
				)}
		>
			{#each STATUSES as status (status)}
				<option value={status}>
					{status === 'all'
						? 'All statuses'
						: status}
					({countFor(status)})
				</option>
			{/each}
		</select>

		<select
			aria-label="Filter by confirmation"
			value={data.filters.confirmation}
			onchange={(event) =>
				apply(
					'confirmation',
					event.currentTarget.value
				)}
		>
			{#each CONFIRMATIONS as confirmation (confirmation)}
				<option value={confirmation}>
					{confirmation === 'all'
						? 'Any confirmation'
						: confirmation}
				</option>
			{/each}
		</select>

		<select
			aria-label="Filter by city"
			value={data.filters.city}
			onchange={(event) =>
				apply(
					'city',
					event.currentTarget.value
				)}
		>
			<option value="all">All cities</option>

			{#each data.cities as city (city)}
				<option value={city}>{city}</option>
			{/each}
		</select>

		<a class="btn" href="/orders">
			Reset
		</a>
	</div>

	<div class="table-wrap">
		<table>
			<thead>
				<tr>
					<th>Order</th>
					<th>Customer</th>
					<th>Store / source</th>
					<th>Confirmation</th>
					<th>Status</th>
					<th>Payment</th>
					<th class="num">Items</th>
					<th class="num">Total</th>
				</tr>
			</thead>

			<tbody>
				{#each data.orders as order (order.id)}
					<tr>
						<td>
							<a
								class="mono order-reference"
								href="/orders/{order.id}"
							>
								{order.reference}
							</a>

							<div class="muted tiny">
								{timeAgo(order.created_at)}
							</div>
						</td>

						<td>
							<a
								class="customer-name"
								href="/customers/{order.customer_id}"
							>
								{order.customer_name}
							</a>

							<div class="muted tiny">
								{order.customer_city}
								·
								<span class="mono">
									{order.customer_phone}
								</span>
							</div>
						</td>

						<td>
							<div>{order.store_name}</div>

							<div class="muted tiny capitalize">
								{formatSource(order.source)}
							</div>
						</td>

						<td>
							<div class="status-stack">
								<Pill status={order.confirmation} />

								<span class="muted tiny">
									{order.call_attempts}
									{order.call_attempts === 1
										? 'call'
										: 'calls'}
								</span>
							</div>
						</td>

						<td>
							<Pill status={order.status} />
						</td>

						<td>
							<Pill
								status={order.payment_method}
								text={order.payment_method.toUpperCase()}
							/>
						</td>

						<td class="num">
							{order.items_count}
						</td>

						<td class="num total-cell">
							{money(order.total)}
						</td>
					</tr>
				{:else}
					<tr>
						<td colspan="8" class="empty">
							<div>
								<strong>No orders found</strong>
								<p class="muted">
									Try changing your filters or search.
								</p>
							</div>
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>
</div>

<style>
	.page-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 1rem;
		margin-bottom: 1.25rem;
	}

	.page-header h1 {
		margin: 0;
	}

	.page-header p {
		margin: 0.25rem 0 0;
	}

	.header-actions {
		display: flex;
		align-items: center;
		gap: 0.75rem;
	}

	.stats-grid {
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		gap: 0.85rem;
		margin-bottom: 1.25rem;
	}

	.stat-card {
		display: flex;
		flex-direction: column;
		gap: 0.25rem;
		padding: 1rem;
		border: 1px solid var(--line);
		border-radius: 10px;
		background: var(--panel);
	}

	.stat-card strong {
		font-size: 1.5rem;
	}

	.stat-label {
		font-size: 0.8rem;
		font-weight: 600;
	}

	.quick-create {
		margin-bottom: 1.25rem;
	}

	.quick-create summary {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 1rem;
		padding: 1rem;
		cursor: pointer;
		list-style: none;
	}

	.quick-create summary::-webkit-details-marker {
		display: none;
	}

	.entry-section + .entry-section {
		margin-top: 1.5rem;
		padding-top: 1.5rem;
		border-top: 1px solid var(--line);
	}

	.entry-label {
		display: block;
		margin-bottom: 0.75rem;
		font-weight: 650;
	}

	.order-entry .grid {
		gap: 10px;
	}

	.action-field {
		justify-content: flex-end;
	}

	.field-spacer {
		display: block;
		height: 1px;
	}

	.orders-head {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.filters {
		display: grid;
		grid-template-columns: minmax(220px, 2fr) repeat(3, 1fr) auto;
		gap: 0.65rem;
	}

	.search-field {
		min-width: 0;
	}

	.table-wrap {
		overflow-x: auto;
	}

	.order-reference {
		font-weight: 650;
	}

	.customer-name {
		font-weight: 600;
	}

	.status-stack {
		display: flex;
		align-items: flex-start;
		flex-direction: column;
		gap: 0.25rem;
	}

	.total-cell {
		font-weight: 650;
	}

	.capitalize {
		text-transform: capitalize;
	}

	.empty {
		padding: 3rem 1rem;
		text-align: center;
	}

	.empty p {
		margin: 0.4rem 0 0;
	}

	.sr-only {
		position: absolute;
		width: 1px;
		height: 1px;
		padding: 0;
		margin: -1px;
		overflow: hidden;
		clip: rect(0, 0, 0, 0);
		white-space: nowrap;
		border: 0;
	}

	@media (max-width: 1000px) {
		.stats-grid {
			grid-template-columns: repeat(2, 1fr);
		}

		.filters {
			grid-template-columns: 1fr 1fr;
		}

		.search-field {
			grid-column: span 2;
		}
	}

	@media (max-width: 650px) {
		.page-header,
		.quick-create summary {
			align-items: flex-start;
			flex-direction: column;
		}

		.stats-grid {
			grid-template-columns: 1fr 1fr;
		}

		.filters {
			grid-template-columns: 1fr;
		}

		.search-field {
			grid-column: auto;
		}
	}
</style>