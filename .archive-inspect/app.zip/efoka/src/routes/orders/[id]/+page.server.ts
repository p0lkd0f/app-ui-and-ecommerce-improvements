import { error, fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import {
	addOrderEvent,
	createShipment,
	getOrder,
	recordConfirmation,
	setOrderStatus
} from '$lib/server/repo';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params }) => {
	const detail = await getOrder(Number(params.id));
	if (!detail) throw error(404, 'Order not found');
	return detail;
};

export const actions: Actions = {
	confirm: async ({ request, params, locals }) => {
		if (!locals.user || !can(locals.user.role, 'confirmation.handle')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const outcome = String(form.get('outcome')) as 'confirmed' | 'no_answer' | 'cancelled' | 'scheduled' | 'wrong_number';
		await recordConfirmation(Number(params.id), outcome, locals.user.id, locals.user.name, String(form.get('notes') ?? ''));
		return { success: `Call logged as ${outcome.replace('_', ' ')}` };
	},
	status: async ({ request, params, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await setOrderStatus(Number(params.id), String(form.get('status')), locals.user.name);
		return { success: 'Order status updated' };
	},
	ship: async ({ request, params, locals }) => {
		if (!locals.user || !can(locals.user.role, 'shipping.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await createShipment(Number(params.id), String(form.get('carrier')), locals.user.name);
		return { success: 'Shipment created' };
	},
	note: async ({ request, params, locals }) => {
		if (!locals.user) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		const note = String(form.get('note') ?? '').trim();
		if (!note) return fail(400, { error: 'Note is empty' });
		await addOrderEvent(Number(params.id), 'note', note, locals.user.name);
		return { success: 'Note added' };
	}
};
