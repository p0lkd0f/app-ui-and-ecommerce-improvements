<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { dateTime, money } from '$lib/format';

	let { data, form } = $props();

	const order = $derived(data.order);

	const CARRIERS = [
		'Ozonexpress',
		'Sendit',
		'CTM Express',
		'Amana'
	];

	const NEXT_STATUS = [
		'confirmed',
		'packed',
		'shipped',
		'delivered',
		'cancelled',
		'returned'
	];

	const profit = $derived(
		Number(order.total ?? 0) -
			Number(order.cogs ?? 0) -
			Number(order.shipping_fee ?? 0)
	);

	function sourceLabel(source: string) {
		return source.replaceAll('_', ' ');
	}

	function callLabel(attempts: number) {
		return `${attempts} ${
			attempts === 1 ? 'attempt' : 'attempts'
		}`;
	}
</script>

<svelte:head>
	<title>{order.reference} · Orders</title>
</svelte:head>

<div class="order-header">
	<div class="header-top">
		<a class="btn small" href="/orders">
			← Orders
		</a>

		<div class="header-statuses">
			<Pill status={order.status} />
			<Pill status={order.confirmation} />
			<Pill
				status={order.payment_method}
				text={order.payment_method.toUpperCase()}
			/>
		</div>
	</div>

	<div class="header-main">
		<div>
			<div class="reference-row">
				<h1 class="mono">{order.reference}</h1>
			</div>

			<div class="muted tiny">
				Created {dateTime(order.created_at)}
				·
				{order.store_name}
				·
				<span class="capitalize">
					{sourceLabel(order.source)}
				</span>
			</div>
		</div>

		<div class="order-total">
			<span class="muted tiny">Order total</span>
			<strong>{money(order.total)}</strong>
		</div>
	</div>
</div>

{#if form?.success}
	<div class="notice">{form.success}</div>
{/if}

{#if form?.error}
	<div class="error">{form.error}</div>
{/if}

<div class="grid cols-3">
	<div class="stack" style="grid-column: span 2">
		<div class="panel">
			<div class="panel-head">
				<div>
					<h2>Items</h2>
					<span class="hint">
						{data.items.length}
						{data.items.length === 1 ? 'line' : 'lines'}
					</span>
				</div>
			</div>

			<div class="table-wrap">
				<table>
					<thead>
						<tr>
							<th>SKU</th>
							<th>Product</th>
							<th class="num">Qty</th>
							<th class="num">Unit</th>
							<th class="num">Line total</th>
						</tr>
					</thead>

					<tbody>
						{#each data.items as item (item.id)}
							<tr>
								<td class="mono">{item.sku}</td>
								<td>
									<strong>{item.name}</strong>
								</td>
								<td class="num">
									{item.quantity}
								</td>
								<td class="num">
									{money(item.unit_price)}
								</td>
								<td class="num">
									{money(
										item.quantity *
											item.unit_price
									)}
								</td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>

			<div
				class="panel-body totals"
				style="border-top:1px solid var(--line)"
			>
				<div class="spread">
					<span class="muted">Subtotal</span>
					<span>{money(order.subtotal)}</span>
				</div>

				<div class="spread">
					<span class="muted">Shipping</span>
					<span>{money(order.shipping_fee)}</span>
				</div>

				<div class="spread">
					<span class="muted">COD fee</span>
					<span>{money(order.cod_fee)}</span>
				</div>

				<div class="spread">
					<span class="muted">Cost of goods</span>
					<span>{money(order.cogs)}</span>
				</div>

				<div class="spread total-row">
					<span>Order total</span>
					<span>{money(order.total)}</span>
				</div>

				<div class="spread profit-row">
					<span>Expected profit</span>
					<span>{money(profit)}</span>
				</div>
			</div>
		</div>

		<div class="panel">
			<div class="panel-head">
				<div>
					<h2>Order timeline</h2>
					<span class="hint">
						{data.events.length} events
					</span>
				</div>
			</div>

			<div class="panel-body timeline">
				{#each data.events as event (event.id)}
					<div class="timeline-item">
						<div class="timeline-dot"></div>

						<div class="timeline-content">
							<div class="timeline-message">
								{event.message}
							</div>

							<div class="muted tiny">
								{event.actor}
								·
								{dateTime(event.created_at)}
							</div>
						</div>
					</div>
				{:else}
					<div class="empty">
						No timeline events yet.
					</div>
				{/each}
			</div>

			<div
				class="panel-body"
				style="border-top:1px solid var(--line)"
			>
				<form
					method="POST"
					action="?/note"
					class="row"
				>
					<input
						name="note"
						placeholder="Add an internal note"
						aria-label="Internal note"
					/>

					<button class="primary" type="submit">
						Add note
					</button>
				</form>
			</div>
		</div>
	</div>

	<div class="stack">
		<div class="panel">
			<div class="panel-head">
				<h2>Customer</h2>
			</div>

			<div class="panel-body stack">
				<a
					href="/customers/{order.customer_id}"
					class="customer-link"
				>
					{order.customer_name}
				</a>

				<div class="mono">
					{order.customer_phone}
				</div>

				<div class="muted">
					{order.customer_city}
				</div>

				<div class="customer-meta">
					<span class="muted tiny">
						Assigned agent
					</span>

					<strong>
						{order.agent_name ?? 'Unassigned'}
					</strong>
				</div>

				<a class="btn small" href="/whatsapp">
					Open WhatsApp
				</a>
			</div>
		</div>

		<div class="panel confirmation-panel">
			<div class="panel-head">
				<div>
					<h2>Confirmation</h2>
					<span class="hint">
						{callLabel(order.call_attempts)}
					</span>
				</div>

				<Pill status={order.confirmation} />
			</div>

			<div class="panel-body stack">
				<form
					method="POST"
					action="?/confirm"
					class="stack"
				>
					<input
						name="notes"
						placeholder="Call notes (optional)"
					/>

					<div class="confirmation-actions">
						<button
							class="success small"
							name="outcome"
							value="confirmed"
							type="submit"
						>
							✓ Confirmed
						</button>

						<button
							class="small"
							name="outcome"
							value="no_answer"
							type="submit"
						>
							No answer
						</button>

						<button
							class="small"
							name="outcome"
							value="scheduled"
							type="submit"
						>
							Call later
						</button>

						<button
							class="danger small"
							name="outcome"
							value="cancelled"
							type="submit"
						>
							Cancel
						</button>
					</div>
				</form>

				{#each data.calls as call (call.id)}
					<div class="call-history">
						<div>
							<Pill
								status={
									call.outcome === 'confirmed'
										? 'confirmed'
										: call.outcome ===
											  'cancelled'
											? 'cancelled'
											: 'pending'
								}
								text={call.outcome.replace(
									'_',
									' '
								)}
							/>
						</div>

						<span class="muted tiny">
							{call.agent ?? 'system'}
							·
							{dateTime(call.created_at)}
						</span>
					</div>
				{:else}
					<div class="muted tiny">
						No confirmation attempts yet.
					</div>
				{/each}
			</div>
		</div>

		<div class="panel">
			<div class="panel-head">
				<h2>Shipping</h2>

				{#if data.shipment}
					<Pill status={data.shipment.status} />
				{/if}
			</div>

			<div class="panel-body stack">
				{#if data.shipment}
					<div class="detail-row">
						<span class="muted">Carrier</span>
						<strong>{data.shipment.carrier}</strong>
					</div>

					<div class="detail-row">
						<span class="muted">Tracking</span>

						<span class="mono">
							{data.shipment.tracking_code}
						</span>
					</div>

					<div class="detail-row">
						<span class="muted">COD</span>

						<strong>
							{money(data.shipment.cod_amount)}
						</strong>
					</div>

					<div class="detail-row">
						<span class="muted">Collection</span>

						<span>
							{data.shipment.cod_collected
								? 'Collected'
								: 'Pending'}
						</span>
					</div>

					<a class="btn small" href="/shipping">
						Manage in shipping
					</a>
				{:else}
					<div class="muted tiny">
						No shipment has been created yet.
					</div>

					<form
						method="POST"
						action="?/ship"
						class="stack"
					>
						<label for="carrier">
							Carrier
						</label>

						<select id="carrier" name="carrier">
							{#each CARRIERS as carrier (carrier)}
								<option value={carrier}>
									{carrier}
								</option>
							{/each}
						</select>

						<button
							class="primary"
							type="submit"
						>
							Create shipment
						</button>
					</form>
				{/if}
			</div>
		</div>

		<div class="panel">
			<div class="panel-head">
				<h2>Move status</h2>
			</div>

			<div class="panel-body">
				<div class="status-actions">
					{#each NEXT_STATUS as status (status)}
						<button
							class="small"
							name="status"
							value={status}
							disabled={order.status === status}
							form="status-form"
						>
							{status}
						</button>
					{/each}
				</div>

				<form
					id="status-form"
					method="POST"
					action="?/status"
				></form>
			</div>
		</div>
	</div>
</div>

<style>
	.order-header {
		margin-bottom: 1.25rem;
	}

	.header-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 1rem;
	}

	.header-statuses {
		display: flex;
		flex-wrap: wrap;
		gap: 0.4rem;
	}

	.header-main {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		gap: 2rem;
		margin-top: 1rem;
	}

	.header-main h1 {
		margin: 0;
	}

	.order-total {
		display: flex;
		align-items: flex-end;
		flex-direction: column;
		gap: 0.15rem;
	}

	.order-total strong {
		font-size: 1.5rem;
	}

	.totals {
		display: flex;
		flex-direction: column;
		gap: 0.65rem;
	}

	.total-row {
		padding-top: 0.75rem;
		margin-top: 0.25rem;
		border-top: 1px solid var(--line);
		font-weight: 650;
	}

	.profit-row {
		font-weight: 650;
		color: var(--green);
	}

	.timeline {
		display: flex;
		flex-direction: column;
		gap: 1.25rem;
	}

	.timeline-item {
		display: flex;
		gap: 0.85rem;
	}

	.timeline-dot {
		flex: 0 0 9px;
		width: 9px;
		height: 9px;
		margin-top: 0.35rem;
		border-radius: 50%;
		background: currentColor;
	}

	.timeline-content {
		min-width: 0;
	}

	.timeline-message {
		font-weight: 500;
	}

	.customer-link {
		font-size: 1.05rem;
		font-weight: 650;
	}

	.customer-meta {
		display: flex;
		flex-direction: column;
		gap: 0.15rem;
		padding-top: 0.75rem;
		border-top: 1px solid var(--line);
	}

	.confirmation-actions {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 0.5rem;
	}

	.call-history {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 0.75rem;
		padding-top: 0.65rem;
		border-top: 1px solid var(--line);
	}

	.detail-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 1rem;
	}

	.status-actions {
		display: flex;
		flex-wrap: wrap;
		gap: 0.5rem;
	}

	.capitalize {
		text-transform: capitalize;
	}

	.empty {
		padding: 1.5rem;
		text-align: center;
	}

	.table-wrap {
		overflow-x: auto;
	}

	@media (max-width: 800px) {
		.header-main {
			align-items: flex-start;
			flex-direction: column;
			gap: 0.75rem;
		}

		.order-total {
			align-items: flex-start;
		}

		.header-top {
			align-items: flex-start;
			flex-direction: column;
		}
	}

	@media (max-width: 500px) {
		.confirmation-actions {
			grid-template-columns: 1fr;
		}
	}
</style>