<script lang="ts">
	import '../app.css';
	import { page } from '$app/stores';
	import { initials } from '$lib/format';
	import { ROLE_LABELS } from '$lib/permissions';
	import type { Role } from '$lib/types';
	import type { LayoutData } from './$types';
	import type { Snippet } from 'svelte';
	import PrivacyAnalytics from '$lib/components/PrivacyAnalytics.svelte';

	let { data, children }: { data: LayoutData; children: Snippet } = $props();

	let userProfileOpen = $state(false);
	let sidebarCollapsed = $state(false);
	let mobileSidebarOpen = $state(false);

	const NAV: {
		group: string;
		items: {
			href: string;
			label: string;
			icon: string;
			badge?: 'confirmation' | 'whatsapp' | 'inventory';
		}[];
	}[] = [
		{
			group: 'Operations',
			items: [
				{ href: '/', label: 'Dashboard', icon: '▦' },
				{ href: '/orders', label: 'Orders', icon: '□' },
				{
					href: '/confirmation',
					label: 'Confirmation',
					icon: '◉',
					badge: 'confirmation'
				},
				{ href: '/shipping', label: 'Shipping', icon: '↗' },
				{ href: '/delivery', label: 'Delivery', icon: '⌖' },
				{ href: '/returns', label: 'Returns', icon: '↩' }
			]
		},
		{
			group: 'AI & Automation',
			items: [
				{
					href: '/ai-agent',
					label: 'AI Agent',
					icon: '✦',
				},
				{
					href: '/whatsapp-automation',
					label: 'WhatsApp Automation',
					icon: '⚡'
				},
				{
					href: '/campaigns',
					label: 'WhatsApp Campaigns',
					icon: '↗',
				},
				{
					href: '/call-center',
					label: 'Call Center',
					icon: '◌'
				}
			]
		},
		{
			group: 'Communication',
			items: [
				{
					href: '/inbox',
					label: 'One Inbox',
					icon: '▱',
					badge: 'whatsapp'
				},
				{
					href: '/templates',
					label: 'Templates',
					icon: '▤'
				}
			]
		},
		{
			group: 'Growth',
			items: [
				{
					href: '/analytics',
					label: 'Marketing & Analytics',
					icon: '⌁'
				},
				{
					href: '/products',
					label: 'Products',
					icon: '◇',
					badge: 'inventory'
				},
				{
					href: '/customers',
					label: 'Customers',
					icon: '◎'
				}
			]
		},
		{
			group: 'Settings',
			items: [
				{
					href: '/integrations',
					label: 'Integrations',
					icon: '⌘'
				},
				{
					href: '/team',
					label: 'Team',
					icon: '♙'
				},
				{
					href: '/settings',
					label: 'Settings',
					icon: '⚙'
				}
			]
		}
	];

	const titles: Record<string, string> = {
		'/': 'Dashboard',
		'/orders': 'Orders',
		'/confirmation': 'Order Confirmation',
		'/shipping': 'Shipping Management',
		'/delivery': 'Delivery Tracking',
		'/returns': 'Returns & Exchanges',
		'/ai-agent': 'AI Agent',
		'/whatsapp-automation': 'WhatsApp Automation',
		'/campaigns': 'WhatsApp Campaigns',
		'/call-center': 'Call Center',
		'/inbox': 'One Inbox',
		'/templates': 'Message Templates',
		'/analytics': 'Marketing & Analytics',
		'/products': 'Products & Inventory',
		'/customers': 'Customers',
		'/integrations': 'Integrations',
		'/team': 'Team & Permissions',
		'/settings': 'Settings',
		'/profile': 'Profile'
	};

	const subtitles: Record<string, string> = {
		'/': 'Overview of your commerce operations',
		'/orders': 'Manage and process incoming orders',
		'/confirmation': 'Confirm orders before fulfillment',
		'/shipping': 'Prepare parcels and manage shipments',
		'/delivery': 'Monitor deliveries and carrier status',
		'/returns': 'Manage returned and refused parcels',
		'/ai-agent': 'AI-assisted customer operations',
		'/whatsapp-automation': 'Automate customer messaging workflows',
		'/campaigns': 'Create and monitor WhatsApp campaigns',
		'/call-center': 'Manage customer calls and follow-ups',
		'/inbox': 'Customer conversations in one place',
		'/templates': 'Manage approved messaging templates',
		'/analytics': 'Measure operational and marketing performance',
		'/products': 'Manage products and inventory',
		'/customers': 'Customer records and activity',
		'/integrations': 'Connected services and integrations',
		'/team': 'Manage workspace members and permissions',
		'/settings': 'Workspace configuration and preferences',
		'/profile': 'Manage your personal account'
	};

	const current = $derived($page.url.pathname);

	const title = $derived(
		titles[current] ??
			(current.startsWith('/orders')
				? 'Order Detail'
				: current.startsWith('/customers')
					? 'Customer'
					: 'Efoka.ma')
	);

	const subtitle = $derived(
		subtitles[current] ??
			(current.startsWith('/orders')
				? 'Review order information and customer details'
				: current.startsWith('/customers')
					? 'Review customer information and activity'
					: 'Efoka.ma operations platform')
	);

	function isActive(href: string): boolean {
		return href === '/' ? current === '/' : current.startsWith(href);
	}

	function toggleUserMenu() {
		userProfileOpen = !userProfileOpen;
	}

	function toggleSidebar() {
		sidebarCollapsed = !sidebarCollapsed;
	}

	function closeMobileSidebar() {
		mobileSidebarOpen = false;
	}
</script>

<svelte:window
	onkeydown={(event) => {
		if (event.key === 'Escape') {
			userProfileOpen = false;
			mobileSidebarOpen = false;
		}
	}}
/>

{#if !data.user}
	{@render children?.()}
{:else}
	<div
		class:sidebar-collapsed={sidebarCollapsed}
		class:mobile-sidebar-open={mobileSidebarOpen}
		class="app-shell"
	>
		{#if mobileSidebarOpen}
			<button
				class="mobile-backdrop"
				type="button"
				aria-label="Close navigation"
				onclick={closeMobileSidebar}
			></button>
		{/if}

		<aside class="sidebar">
			<div class="sidebar-top">
				<a href="/" class="brand" aria-label="Efoka.ma dashboard">
					<span class="brand-mark">E</span>

					<span class="brand-copy">
						<strong>Efoka</strong>
						<small>.ma</small>
					</span>
				</a>

				<button
					class="sidebar-toggle"
					type="button"
					aria-label={sidebarCollapsed
						? 'Expand sidebar'
						: 'Collapse sidebar'}
					title={sidebarCollapsed
						? 'Expand sidebar'
						: 'Collapse sidebar'}
					onclick={toggleSidebar}
				>
					{sidebarCollapsed ? '›' : '‹'}
				</button>
			</div>

			<div class="workspace-card">
				<div class="workspace-icon">E</div>

				<div class="workspace-copy">
					<strong>Efoka.ma</strong>
					<span>Operations workspace</span>
				</div>

				<span class="workspace-status"></span>
			</div>

			<div class="navigation">
				{#each NAV as group (group.group)}
					<nav class="nav-group" aria-label={group.group}>
						<div class="nav-group-label">
							<span>{group.group}</span>
						</div>

						<div class="nav-items">
							{#each group.items as item (item.href)}
								<a
									href={item.href}
									class="nav-item"
									class:active={isActive(item.href)}
									aria-current={isActive(item.href)
										? 'page'
										: undefined}
									title={sidebarCollapsed
										? item.label
										: undefined}
									onclick={closeMobileSidebar}
								>
									<span class="nav-icon" aria-hidden="true">
										{item.icon}
									</span>

									<span class="nav-label">
										{item.label}
									</span>

									{#if item.badge && data.badges?.[item.badge] > 0}
										<span class="nav-count">
											{data.badges[item.badge] > 99
												? '99+'
												: data.badges[item.badge]}
										</span>
									{/if}
								</a>
							{/each}
						</div>
					</nav>
				{/each}
			</div>

			<div class="sidebar-bottom">
				<div class="account-mini">
					<div class="account-avatar">
						{initials(data.user.name)}
					</div>

					<div class="account-info">
						<strong>{data.user.name}</strong>
						<span>
							{ROLE_LABELS[data.user.role as Role]}
						</span>
					</div>
				</div>

				<form method="POST" action="/logout">
					<button
						class="sidebar-signout"
						type="submit"
						title="Sign out"
					>
						<span>↪</span>
						<span>Sign out</span>
					</button>
				</form>
			</div>
		</aside>

		<div class="main">
			<header class="topbar">
				<div class="topbar-left">
					<button
						class="mobile-menu"
						type="button"
						aria-label="Open navigation"
						onclick={() => (mobileSidebarOpen = true)}
					>
						<span></span>
						<span></span>
						<span></span>
					</button>

					<div class="page-heading">
						<div class="breadcrumb">
							<span>Efoka.ma</span>
							<span class="breadcrumb-separator">/</span>
							<span>{title}</span>
						</div>

						<h1>{title}</h1>

						<p>{subtitle}</p>
					</div>
				</div>

				<div class="topbar-right">
					<div class="platform-status">
						<span class="status-dot"></span>
						<span>All systems operational</span>
					</div>

					<div class="topbar-divider"></div>

					<div class="user-menu">
						<button
							class="avatar-enhanced"
							type="button"
							aria-label="Open user menu"
							aria-expanded={userProfileOpen}
							onclick={toggleUserMenu}
						>
							{initials(data.user.name)}
						</button>

						{#if userProfileOpen}
							<button
								class="dropdown-backdrop"
								type="button"
								aria-label="Close user menu"
								onclick={() => (userProfileOpen = false)}
							></button>

							<div class="user-dropdown" role="menu">
								<div class="dropdown-user">
									<div class="dropdown-avatar">
										{initials(data.user.name)}
									</div>

									<div class="dropdown-user-info">
										<strong>{data.user.name}</strong>
										<span>{data.user.email}</span>

										<div class="dropdown-role">
											{ROLE_LABELS[
												data.user.role as Role
											]}
										</div>
									</div>
								</div>

								<div class="dropdown-links">
									<a href="/profile" role="menuitem">
										<span>◎</span>
										<span>Profile Settings</span>
									</a>

									<a href="/team" role="menuitem">
										<span>♙</span>
										<span>Team Management</span>
									</a>

									<a href="/settings" role="menuitem">
										<span>⚙</span>
										<span>Workspace Settings</span>
									</a>
								</div>

								<div class="dropdown-divider"></div>

								<form method="POST" action="/logout">
									<button
										type="submit"
										class="dropdown-signout"
									>
										<span>↪</span>
										<span>Sign out</span>
									</button>
								</form>
							</div>
						{/if}
					</div>
				</div>
			</header>

			<main class="content">
				{@render children?.()}
			</main>
		</div>

		<PrivacyAnalytics />
	</div>
{/if}

<style>
	.app-shell {
		--sidebar-width: 264px;
		--sidebar-collapsed-width: 76px;

		min-height: 100vh;
		display: grid;
		grid-template-columns: var(--sidebar-width) minmax(0, 1fr);
		background:
			radial-gradient(
				circle at 75% -10%,
				rgba(99, 102, 241, 0.07),
				transparent 30%
			),
			var(--background, #f7f8fc);
	}

	.app-shell.sidebar-collapsed {
		grid-template-columns: var(--sidebar-collapsed-width) minmax(0, 1fr);
	}

	.sidebar {
		position: sticky;
		top: 0;
		height: 100vh;
		display: flex;
		flex-direction: column;
		background:
			linear-gradient(
				180deg,
				#101426 0%,
				#0d1120 100%
			);
		border-right: 1px solid rgba(255, 255, 255, 0.06);
		color: #fff;
		z-index: 50;
		overflow: hidden;
	}

	.sidebar-top {
		height: 72px;
		display: flex;
		align-items: center;
		padding: 0 14px;
		gap: 10px;
		border-bottom: 1px solid rgba(255, 255, 255, 0.06);
	}

	.brand {
		min-width: 0;
		flex: 1;
		display: flex;
		align-items: center;
		gap: 10px;
		color: #fff;
		text-decoration: none;
	}

	.brand-mark {
		width: 36px;
		height: 36px;
		flex: 0 0 36px;
		display: grid;
		place-items: center;
		border-radius: 10px;
		background: linear-gradient(
			135deg,
			var(--gradient-start),
			var(--gradient-end)
		);
		color: #fff;
		font-size: 16px;
		font-weight: 800;
		box-shadow: 0 6px 18px rgba(99, 102, 241, 0.25);
	}

	.brand-copy {
		display: flex;
		align-items: baseline;
		font-size: 18px;
		letter-spacing: -0.03em;
	}

	.brand-copy small {
		color: #8993ae;
		font-size: 14px;
	}

	.sidebar-toggle {
		width: 30px;
		height: 30px;
		display: grid;
		place-items: center;
		flex: 0 0 30px;
		background: rgba(255, 255, 255, 0.05);
		border: 1px solid rgba(255, 255, 255, 0.08);
		border-radius: 8px;
		color: #aeb7cd;
		cursor: pointer;
		font-size: 20px;
	}

	.sidebar-toggle:hover {
		background: rgba(255, 255, 255, 0.1);
		color: #fff;
	}

	.workspace-card {
		margin: 14px 12px 8px;
		padding: 10px;
		display: flex;
		align-items: center;
		gap: 9px;
		background: rgba(255, 255, 255, 0.045);
		border: 1px solid rgba(255, 255, 255, 0.065);
		border-radius: 11px;
	}

	.workspace-icon {
		width: 32px;
		height: 32px;
		display: grid;
		place-items: center;
		flex: 0 0 32px;
		border-radius: 8px;
		background: rgba(255, 255, 255, 0.09);
		color: #dce2f2;
		font-size: 12px;
		font-weight: 700;
	}

	.workspace-copy {
		min-width: 0;
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.workspace-copy strong {
		font-size: 12px;
		color: #f5f7fb;
	}

	.workspace-copy span {
		margin-top: 2px;
		color: #77819b;
		font-size: 10px;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.workspace-status {
		width: 7px;
		height: 7px;
		flex: 0 0 7px;
		border-radius: 50%;
		background: #34d399;
		box-shadow: 0 0 0 3px rgba(52, 211, 153, 0.1);
	}

	.navigation {
		flex: 1;
		overflow-y: auto;
		padding: 8px 10px 16px;
		scrollbar-width: thin;
		scrollbar-color: rgba(255, 255, 255, 0.12) transparent;
	}

	.nav-group {
		margin-bottom: 18px;
	}

	.nav-group-label {
		padding: 0 10px 7px;
		color: #68728d;
		font-size: 9px;
		font-weight: 800;
		letter-spacing: 0.11em;
		text-transform: uppercase;
	}

	.nav-items {
		display: flex;
		flex-direction: column;
		gap: 2px;
	}

	.nav-item {
		position: relative;
		min-height: 40px;
		padding: 0 10px;
		display: flex;
		align-items: center;
		gap: 11px;
		border-radius: 9px;
		color: #aeb7cc;
		text-decoration: none;
		font-size: 12.5px;
		font-weight: 500;
		transition:
			background 0.15s ease,
			color 0.15s ease,
			transform 0.15s ease;
	}

	.nav-item:hover {
		background: rgba(255, 255, 255, 0.055);
		color: #fff;
	}

	.nav-item.active {
		background: linear-gradient(
			90deg,
			rgba(99, 102, 241, 0.2),
			rgba(99, 102, 241, 0.08)
		);
		color: #fff;
		font-weight: 650;
	}

	.nav-item.active::before {
		content: '';
		position: absolute;
		left: -10px;
		top: 8px;
		bottom: 8px;
		width: 3px;
		border-radius: 0 3px 3px 0;
		background: linear-gradient(
			180deg,
			var(--gradient-start),
			var(--gradient-end)
		);
	}

	.nav-icon {
		width: 20px;
		flex: 0 0 20px;
		display: grid;
		place-items: center;
		color: #8792ad;
		font-size: 16px;
		line-height: 1;
	}

	.nav-item.active .nav-icon {
		color: #aeb4ff;
	}

	.nav-label {
		min-width: 0;
		flex: 1;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.nav-count {
		min-width: 20px;
		height: 19px;
		padding: 0 6px;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		border-radius: 999px;
		background: rgba(255, 255, 255, 0.09);
		color: #dce2f3;
		font-size: 9px;
		font-weight: 750;
	}

	.nav-item.active .nav-count {
		background: rgba(129, 140, 248, 0.22);
		color: #c7cbff;
	}

	.sidebar-bottom {
		padding: 12px;
		border-top: 1px solid rgba(255, 255, 255, 0.06);
	}

	.account-mini {
		display: flex;
		align-items: center;
		gap: 9px;
		padding: 8px;
		margin-bottom: 7px;
		border-radius: 9px;
	}

	.account-avatar,
	.dropdown-avatar {
		display: grid;
		place-items: center;
		border-radius: 50%;
		background: linear-gradient(
			135deg,
			var(--gradient-start),
			var(--gradient-end)
		);
		color: #fff;
		font-weight: 700;
	}

	.account-avatar {
		width: 31px;
		height: 31px;
		flex: 0 0 31px;
		font-size: 10px;
	}

	.account-info {
		min-width: 0;
		display: flex;
		flex-direction: column;
	}

	.account-info strong {
		color: #e9edf7;
		font-size: 11px;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.account-info span {
		margin-top: 1px;
		color: #727c96;
		font-size: 9px;
	}

	.sidebar-signout {
		width: 100%;
		height: 34px;
		display: flex;
		align-items: center;
		gap: 9px;
		padding: 0 10px;
		background: transparent;
		border: 1px solid rgba(255, 255, 255, 0.08);
		border-radius: 8px;
		color: #8993ab;
		font-size: 11px;
		cursor: pointer;
	}

	.sidebar-signout:hover {
		background: rgba(255, 255, 255, 0.05);
		color: #fff;
	}

	.main {
		min-width: 0;
		min-height: 100vh;
	}

	.topbar {
		height: 76px;
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 20px;
		padding: 0 28px;
		background: rgba(255, 255, 255, 0.84);
		backdrop-filter: blur(18px);
		border-bottom: 1px solid var(--line);
		position: sticky;
		top: 0;
		z-index: 30;
	}

	.topbar-left {
		min-width: 0;
		display: flex;
		align-items: center;
		gap: 14px;
	}

	.page-heading {
		min-width: 0;
	}

	.breadcrumb {
		display: flex;
		align-items: center;
		gap: 7px;
		margin-bottom: 2px;
		color: #9aa3b8;
		font-size: 9px;
		font-weight: 600;
	}

	.breadcrumb-separator {
		color: #c2c8d5;
	}

	.page-heading h1 {
		margin: 0;
		color: var(--ink);
		font-size: 19px;
		font-weight: 700;
		letter-spacing: -0.025em;
		line-height: 1.2;
	}

	.page-heading p {
		margin: 2px 0 0;
		color: var(--muted);
		font-size: 10px;
	}

	.topbar-right {
		display: flex;
		align-items: center;
		gap: 13px;
	}

	.platform-status {
		display: flex;
		align-items: center;
		gap: 7px;
		color: #7d879d;
		font-size: 10px;
		white-space: nowrap;
	}

	.status-dot {
		width: 7px;
		height: 7px;
		border-radius: 50%;
		background: #22c55e;
		box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.1);
	}

	.topbar-divider {
		width: 1px;
		height: 28px;
		background: var(--line);
	}

	.user-menu {
		position: relative;
		z-index: 40;
	}

	.avatar-enhanced {
		width: 38px;
		height: 38px;
		display: grid;
		place-items: center;
		border-radius: 50%;
		background: linear-gradient(
			135deg,
			var(--gradient-start),
			var(--gradient-end)
		);
		border: 2px solid #fff;
		color: #fff;
		font-size: 11px;
		font-weight: 750;
		cursor: pointer;
		box-shadow: 0 3px 10px rgba(38, 44, 75, 0.12);
	}

	.avatar-enhanced:hover {
		transform: translateY(-1px);
	}

	.avatar-enhanced:focus-visible {
		outline: 2px solid var(--brand);
		outline-offset: 3px;
	}

	.dropdown-backdrop {
		position: fixed;
		inset: 0;
		z-index: -1;
		border: 0;
		background: transparent;
		cursor: default;
	}

	.user-dropdown {
		position: absolute;
		top: 48px;
		right: 0;
		width: 270px;
		padding: 7px;
		background: var(--panel);
		border: 1px solid var(--line);
		border-radius: 14px;
		box-shadow: 0 18px 45px rgba(23, 31, 56, 0.16);
		overflow: hidden;
	}

	.dropdown-user {
		padding: 12px;
		display: flex;
		gap: 10px;
		border-bottom: 1px solid var(--line);
	}

	.dropdown-avatar {
		width: 38px;
		height: 38px;
		flex: 0 0 38px;
		font-size: 11px;
	}

	.dropdown-user-info {
		min-width: 0;
		display: flex;
		flex-direction: column;
	}

	.dropdown-user-info strong {
		color: var(--ink);
		font-size: 12px;
	}

	.dropdown-user-info > span {
		margin-top: 2px;
		color: var(--muted);
		font-size: 9px;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.dropdown-role {
		width: fit-content;
		margin-top: 6px;
		padding: 3px 7px;
		border-radius: 999px;
		background: var(--brand-soft);
		color: var(--brand);
		font-size: 9px;
		font-weight: 700;
	}

	.dropdown-links {
		padding: 5px 0;
	}

	.user-dropdown a,
	.dropdown-signout {
		width: 100%;
		min-height: 36px;
		display: flex;
		align-items: center;
		gap: 9px;
		padding: 0 10px;
		border-radius: 8px;
		text-decoration: none;
		color: var(--ink);
		font-size: 11px;
	}

	.user-dropdown a:hover {
		background: var(--brand-soft);
		color: var(--brand);
	}

	.dropdown-divider {
		height: 1px;
		margin: 5px 0;
		background: var(--line);
	}

	.dropdown-signout {
		background: transparent;
		border: 0;
		color: var(--red);
		cursor: pointer;
		text-align: left;
	}

	.dropdown-signout:hover {
		background: rgba(239, 68, 68, 0.06);
	}

	.content {
		width: 100%;
		max-width: 1680px;
		margin: 0 auto;
		padding: 26px 28px 40px;
	}

	.mobile-menu {
		display: none;
		width: 36px;
		height: 36px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 4px;
		background: var(--panel);
		border: 1px solid var(--line);
		border-radius: 9px;
		cursor: pointer;
	}

	.mobile-menu span {
		width: 15px;
		height: 1.5px;
		background: var(--ink);
		border-radius: 2px;
	}

	.mobile-backdrop {
		display: none;
	}

	.app-shell.sidebar-collapsed .brand-copy,
	.app-shell.sidebar-collapsed .workspace-copy,
	.app-shell.sidebar-collapsed .workspace-status,
	.app-shell.sidebar-collapsed .nav-group-label,
	.app-shell.sidebar-collapsed .nav-label,
	.app-shell.sidebar-collapsed .nav-count,
	.app-shell.sidebar-collapsed .account-info,
	.app-shell.sidebar-collapsed .sidebar-signout span:last-child {
		display: none;
	}

	.app-shell.sidebar-collapsed .sidebar-top {
		justify-content: center;
	}

	.app-shell.sidebar-collapsed .sidebar-toggle {
		position: absolute;
		right: 7px;
		top: 21px;
	}

	.app-shell.sidebar-collapsed .brand {
		flex: 0;
	}

	.app-shell.sidebar-collapsed .workspace-card {
		justify-content: center;
		margin-left: 10px;
		margin-right: 10px;
	}

	.app-shell.sidebar-collapsed .nav-item {
		justify-content: center;
		padding: 0;
	}

	.app-shell.sidebar-collapsed .nav-icon {
		width: 24px;
		flex-basis: 24px;
	}

	.app-shell.sidebar-collapsed .account-mini {
		justify-content: center;
		padding: 6px;
	}

	.app-shell.sidebar-collapsed .sidebar-signout {
		justify-content: center;
		padding: 0;
	}

	@media (max-width: 1100px) {
		.platform-status,
		.topbar-divider {
			display: none;
		}
	}

	@media (max-width: 820px) {
		.app-shell,
		.app-shell.sidebar-collapsed {
			display: block;
		}

		.sidebar {
			position: fixed;
			left: 0;
			top: 0;
			bottom: 0;
			width: 264px;
			transform: translateX(-100%);
			transition: transform 0.2s ease;
			box-shadow: 20px 0 50px rgba(10, 15, 30, 0.25);
		}

		.app-shell.mobile-sidebar-open .sidebar {
			transform: translateX(0);
		}

		.mobile-backdrop {
			display: block;
			position: fixed;
			inset: 0;
			z-index: 45;
			background: rgba(7, 11, 23, 0.42);
			border: 0;
		}

		.sidebar-toggle {
			display: none;
		}

		.mobile-menu {
			display: flex;
		}

		.topbar {
			height: 68px;
			padding: 0 16px;
		}

		.content {
			padding: 20px 16px 32px;
		}
	}

	@media (max-width: 600px) {
		.topbar {
			gap: 10px;
		}

		.page-heading p,
		.breadcrumb {
			display: none;
		}

		.page-heading h1 {
			font-size: 16px;
		}

		.topbar-right {
			gap: 0;
		}

		.avatar-enhanced {
			width: 35px;
			height: 35px;
		}

		.user-dropdown {
			position: fixed;
			top: 60px;
			right: 10px;
			left: 10px;
			width: auto;
		}
	}
</style>