import { fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { advanceShipment, createShipment, listShipments } from '$lib/server/repo';
import { oneOf, positiveId, requiredText, SHIPMENT_STATUSES } from '$lib/server/validation';
import type { OrderRow } from '$lib/types';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
	const status = url.searchParams.get('status') ?? 'all';
	const [shipments, ready, carriers, cod] = await Promise.all([
		listShipments(status),
		query<OrderRow>(
			`SELECT o.id, o.reference, o.total, c.full_name AS customer_name, c.city AS customer_city
			 FROM orders o JOIN customers c ON c.id = o.customer_id
			 WHERE o.status IN ('confirmed','packed') AND NOT EXISTS (SELECT 1 FROM shipments s WHERE s.order_id = o.id)
			 ORDER BY o.created_at ASC LIMIT 25`
		),
		query<{ carrier: string; total: number; delivered: number; returned: number; cod: number }>(
			`SELECT carrier, count(*)::int AS total,
			        count(*) FILTER (WHERE status = 'delivered')::int AS delivered,
			        count(*) FILTER (WHERE status = 'returned')::int AS returned,
			        coalesce(sum(cod_amount) FILTER (WHERE cod_collected), 0) AS cod
			 FROM shipments GROUP BY carrier ORDER BY total DESC`
		),
		query<{ collected: number; pending: number }>(
			`SELECT coalesce(sum(cod_amount) FILTER (WHERE cod_collected), 0) AS collected,
			        coalesce(sum(cod_amount) FILTER (WHERE NOT cod_collected AND status NOT IN ('returned','failed')), 0) AS pending
			 FROM shipments`
		)
	]);
	return { shipments, ready, carriers, status, cod: cod[0] };
};

export const actions: Actions = {
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'shipping.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await createShipment(positiveId(form.get('orderId')), requiredText(form.get('carrier'), 'Carrier', 80), locals.user.name);
		return { success: 'Shipment created' };
	},
	advance: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'shipping.manage')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await advanceShipment(positiveId(form.get('shipmentId')), oneOf(form.get('status'), SHIPMENT_STATUSES, 'shipment status'), locals.user.name);
		return { success: 'Shipment updated' };
	}
};
