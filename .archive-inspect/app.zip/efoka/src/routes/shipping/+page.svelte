<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Checkbox,
		Input,
		Label,
		Modal,
		Select,
		Spinner,
		Table,
		TableBody,
		TableBodyCell,
		TableBodyRow,
		TableHead,
		TableHeadCell,
		Toggle
	} from 'flowbite-svelte';

	import Pill from '$lib/components/Pill.svelte';
	import { date, money } from '$lib/format';

	let { data, form } = $props();

	const CARRIERS = ['Ozonexpress', 'Sendit', 'CTM Express', 'Amana'];

	const STATUSES = [
		'all',
		'label_created',
		'picked_up',
		'in_transit',
		'out_for_delivery',
		'delivered',
		'failed',
		'returned'
	];

	const NEXT: Record<string, string[]> = {
		label_created: ['picked_up'],
		picked_up: ['in_transit'],
		in_transit: ['out_for_delivery', 'failed'],
		out_for_delivery: ['delivered', 'failed'],
		failed: ['out_for_delivery', 'returned'],
		delivered: [],
		returned: []
	};

	let search = $state('');
	let carrierFilter = $state('all');
	let selectedShipments = $state(new Set<number>());
	let selectedReadyOrders = $state(new Set<number>());
	let showCreateModal = $state(false);
	let showShipmentModal = $state(false);
	let selectedShipment = $state<any>(null);
	let selectedCarrier = $state(CARRIERS[0]);
	let autoRefresh = $state(false);

	let filteredShipments = $derived(
		data.shipments.filter((shipment: any) => {
			const term = search.trim().toLowerCase();

			const matchesSearch =
				!term ||
				String(shipment.tracking_code ?? '').toLowerCase().includes(term) ||
				String(shipment.reference ?? '').toLowerCase().includes(term) ||
				String(shipment.customer_name ?? '').toLowerCase().includes(term) ||
				String(shipment.customer_city ?? '').toLowerCase().includes(term);

			const matchesCarrier =
				carrierFilter === 'all' || shipment.carrier === carrierFilter;

			return matchesSearch && matchesCarrier;
		})
	);

	let selectedCOD = $derived(
		data.shipments
			.filter((shipment: any) => selectedShipments.has(shipment.id))
			.reduce(
				(total: number, shipment: any) =>
					total + Number(shipment.cod_amount ?? 0),
				0
			)
	);

	let selectedReadyTotal = $derived(
		data.ready
			.filter((order: any) => selectedReadyOrders.has(order.id))
			.reduce(
				(total: number, order: any) => total + Number(order.total ?? 0),
				0
			)
	);

	function toggleShipment(id: number) {
		const next = new Set(selectedShipments);

		if (next.has(id)) {
			next.delete(id);
		} else {
			next.add(id);
		}

		selectedShipments = next;
	}

	function toggleReadyOrder(id: number) {
		const next = new Set(selectedReadyOrders);

		if (next.has(id)) {
			next.delete(id);
		} else {
			next.add(id);
		}

		selectedReadyOrders = next;
	}

	function selectAllShipments(checked: boolean) {
		selectedShipments = checked
			? new Set(filteredShipments.map((shipment: any) => shipment.id))
			: new Set();
	}

	function selectAllReady(checked: boolean) {
		selectedReadyOrders = checked
			? new Set(data.ready.map((order: any) => order.id))
			: new Set();
	}

	function openShipment(shipment: any) {
		selectedShipment = shipment;
		showShipmentModal = true;
	}

	function clearSelection() {
		selectedShipments = new Set();
		selectedReadyOrders = new Set();
	}

	function statusLabel(status: string) {
		return status.replace(/_/g, ' ');
	}

	function deliveryRate(carrier: any) {
		return carrier.total
			? Math.round((carrier.delivered / carrier.total) * 100)
			: 0;
	}
</script>

<svelte:head>
	<title>Shipping · Efoka</title>
	<meta
		name="description"
		content="Manage shipments, carriers, labels and delivery progress."
	/>
</svelte:head>

<!-- Header -->
<div class="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-start">
	<div>
		<div class="mb-2 flex items-center gap-2">
			<Badge color="blue">Operations</Badge>

			<Badge color="gray">
				{data.shipments.length} shipments
			</Badge>
		</div>

		<h1 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
			Shipping
		</h1>

		<p class="mt-2 max-w-2xl text-sm leading-6 text-gray-500 dark:text-gray-400">
			Create shipping labels, track parcels, manage carrier handoffs and
			monitor COD collection.
		</p>
	</div>

	<div class="flex flex-wrap items-center gap-3">
		<div class="flex items-center gap-2">
			<Toggle bind:checked={autoRefresh} />

			<span class="text-sm text-gray-600 dark:text-gray-300">
				Auto refresh
			</span>
		</div>

		<Button
			color="alternative"
			onclick={() => {
				search = '';
				carrierFilter = 'all';
				clearSelection();
			}}
		>
			Reset
		</Button>
	</div>
</div>

{#if form?.success}
	<div
		class="mb-6 rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-300"
	>
		{form.success}
	</div>
{/if}

{#if form?.error}
	<div
		class="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-300"
	>
		{form.error}
	</div>
{/if}

<!-- KPI cards -->
<div class="mb-6 grid gap-4 md:grid-cols-3">
	<Card>
		<div class="flex items-start justify-between">
			<div>
				<p class="text-sm font-medium text-gray-500 dark:text-gray-400">
					COD collected
				</p>

				<p class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{money(data.cod?.collected ?? 0)}
				</p>
			</div>

			<Badge color="green">Collected</Badge>
		</div>

		<p class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			Cash reconciled with carriers
		</p>
	</Card>

	<Card>
		<div class="flex items-start justify-between">
			<div>
				<p class="text-sm font-medium text-gray-500 dark:text-gray-400">
					COD pending
				</p>

				<p class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{money(data.cod?.pending ?? 0)}
				</p>
			</div>

			<Badge color="yellow">Pending</Badge>
		</div>

		<p class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			Still held by carriers
		</p>
	</Card>

	<Card>
		<div class="flex items-start justify-between">
			<div>
				<p class="text-sm font-medium text-gray-500 dark:text-gray-400">
					Ready to ship
				</p>

				<p class="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
					{data.ready.length}
				</p>
			</div>

			<Badge color={data.ready.length > 0 ? 'blue' : 'green'}>
				{data.ready.length > 0 ? 'Action needed' : 'Clear'}
			</Badge>
		</div>

		<p class="mt-3 text-xs text-gray-500 dark:text-gray-400">
			Confirmed orders without a label
		</p>
	</Card>
</div>

<!-- Ready to ship -->
<Card class="mb-6">
	<div class="mb-5 flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
		<div>
			<div class="flex items-center gap-2">
				<h2 class="text-lg font-bold text-gray-900 dark:text-white">
					Ready to ship
				</h2>

				{#if data.ready.length > 0}
					<Badge color="yellow">{data.ready.length}</Badge>
				{/if}
			</div>

			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				Create a label and hand each parcel to a carrier.
			</p>
		</div>

		{#if selectedReadyOrders.size > 0}
			<div class="flex items-center gap-3">
				<Badge color="blue">
					{selectedReadyOrders.size} selected
				</Badge>

				<Badge color="gray">
					{money(selectedReadyTotal)}
				</Badge>

				<Button
					size="sm"
					color="alternative"
					onclick={() => (showCreateModal = true)}
				>
					Create labels
				</Button>
			</div>
		{/if}
	</div>

	{#if data.ready.length > 0}
		<div class="overflow-x-auto">
			<Table hoverable={true}>
				<TableHead>
					<TableHeadCell>
						<Checkbox
							checked={
								selectedReadyOrders.size === data.ready.length &&
								data.ready.length > 0
							}
							onchange={(event) =>
								selectAllReady(event.currentTarget.checked)}
						/>
					</TableHeadCell>

					<TableHeadCell>Order</TableHeadCell>
					<TableHeadCell>Customer</TableHeadCell>
					<TableHeadCell>Destination</TableHeadCell>
					<TableHeadCell>COD</TableHeadCell>
					<TableHeadCell>Carrier</TableHeadCell>
				</TableHead>

				<TableBody>
					{#each data.ready as order (order.id)}
						<TableBodyRow>
							<TableBodyCell>
								<Checkbox
									checked={selectedReadyOrders.has(order.id)}
									onchange={() => toggleReadyOrder(order.id)}
								/>
							</TableBodyCell>

							<TableBodyCell>
								<a
									class="font-mono text-sm font-semibold text-primary-600 hover:underline dark:text-primary-400"
									href="/orders/{order.id}"
								>
									{order.reference}
								</a>
							</TableBodyCell>

							<TableBodyCell>
								<div class="font-medium text-gray-900 dark:text-white">
									{order.customer_name}
								</div>

								<div class="text-xs text-gray-500 dark:text-gray-400">
									{order.customer_city}
								</div>
							</TableBodyCell>

							<TableBodyCell>
								<Badge color="gray">
									{order.customer_city}
								</Badge>
							</TableBodyCell>

							<TableBodyCell>
								<span class="font-semibold text-gray-900 dark:text-white">
									{money(order.total)}
								</span>
							</TableBodyCell>

							<TableBodyCell>
								<form method="POST" action="?/create" class="flex items-center gap-2">
									<input
										type="hidden"
										name="orderId"
										value={order.id}
									/>

									<Select
										name="carrier"
										class="min-w-[155px]"
									>
										{#each CARRIERS as carrier (carrier)}
											<option value={carrier}>
												{carrier}
											</option>
										{/each}
									</Select>

									<Button size="sm" color="primary">
										Create label
									</Button>
								</form>
							</TableBodyCell>
						</TableBodyRow>
					{/each}
				</TableBody>
			</Table>
		</div>
	{:else}
		<div class="rounded-xl border border-dashed border-gray-300 p-10 text-center dark:border-gray-700">
			<div class="text-3xl">✓</div>

			<h3 class="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
				Everything is shipped
			</h3>

			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				There are no confirmed orders waiting for a shipping label.
			</p>
		</div>
	{/if}
</Card>

<!-- Shipment workspace -->
<div class="grid gap-6 xl:grid-cols-12">
	<div class="xl:col-span-9">
		<Card>
			<div class="mb-5 flex flex-col gap-4">
				<div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
					<div>
						<h2 class="text-lg font-bold text-gray-900 dark:text-white">
							Shipments
						</h2>

						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							Track every parcel through its delivery lifecycle.
						</p>
					</div>

					{#if selectedShipments.size > 0}
						<div class="flex flex-wrap items-center gap-2">
							<Badge color="blue">
								{selectedShipments.size} selected
							</Badge>

							<Badge color="gray">
								COD {money(selectedCOD)}
							</Badge>

							<Button size="xs" color="alternative" onclick={clearSelection}>
								Clear
							</Button>
						</div>
					{/if}
				</div>

				<!-- Search / filters -->
				<div class="grid gap-3 md:grid-cols-[1fr_220px]">
					<div>
						<Label for="shipment-search" class="sr-only">
							Search shipments
						</Label>

						<Input
							id="shipment-search"
							bind:value={search}
							placeholder="Search tracking, order, customer or city..."
						/>
					</div>

					<Select bind:value={carrierFilter}>
						<option value="all">All carriers</option>

						{#each CARRIERS as carrier (carrier)}
							<option value={carrier}>
								{carrier}
							</option>
						{/each}
					</Select>
				</div>

				<!-- Status filters -->
				<div class="flex flex-wrap gap-2">
					{#each STATUSES as status (status)}
						<a
							href="/shipping?status={status}"
							class:status-filter-active={data.status === status}
							class="status-filter"
						>
							{statusLabel(status)}
						</a>
					{/each}
				</div>
			</div>

			{#if filteredShipments.length > 0}
				<div class="overflow-x-auto">
					<Table hoverable={true}>
						<TableHead>
							<TableHeadCell>
								<Checkbox
									checked={
										selectedShipments.size === filteredShipments.length &&
										filteredShipments.length > 0
									}
									onchange={(event) =>
										selectAllShipments(event.currentTarget.checked)}
								/>
							</TableHeadCell>

							<TableHeadCell>Tracking</TableHeadCell>
							<TableHeadCell>Order</TableHeadCell>
							<TableHeadCell>Customer</TableHeadCell>
							<TableHeadCell>Status</TableHeadCell>
							<TableHeadCell>COD</TableHeadCell>
							<TableHeadCell>Next action</TableHeadCell>
						</TableHead>

						<TableBody>
							{#each filteredShipments as shipment (shipment.id)}
								<TableBodyRow>
									<TableBodyCell>
										<Checkbox
											checked={selectedShipments.has(shipment.id)}
											onchange={() => toggleShipment(shipment.id)}
										/>
									</TableBodyCell>

									<TableBodyCell>
										<button
											type="button"
											class="text-left"
											onclick={() => openShipment(shipment)}
										>
											<div class="font-mono text-sm font-semibold text-primary-600 hover:underline dark:text-primary-400">
												{shipment.tracking_code}
											</div>

											<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
												{shipment.carrier}
												{#if shipment.shipped_at}
													· {date(shipment.shipped_at)}
												{/if}
											</div>
										</button>
									</TableBodyCell>

									<TableBodyCell>
										<a
											class="font-mono text-sm font-medium text-gray-900 hover:underline dark:text-white"
											href="/orders/{shipment.order_id}"
										>
											{shipment.reference}
										</a>
									</TableBodyCell>

									<TableBodyCell>
										<div class="font-medium text-gray-900 dark:text-white">
											{shipment.customer_name}
										</div>

										<div class="text-xs text-gray-500 dark:text-gray-400">
											{shipment.customer_city}
										</div>
									</TableBodyCell>

									<TableBodyCell>
										<Pill status={shipment.status} />
									</TableBodyCell>

									<TableBodyCell>
										<div class="font-semibold text-gray-900 dark:text-white">
											{money(shipment.cod_amount)}
										</div>

										<div class="mt-1">
											{#if shipment.cod_collected}
												<Badge color="green">Collected</Badge>
											{:else}
												<Badge color="yellow">Pending</Badge>
											{/if}
										</div>
									</TableBodyCell>

									<TableBodyCell>
										<form
											method="POST"
											action="?/advance"
											class="flex flex-wrap gap-2"
										>
											<input
												type="hidden"
												name="shipmentId"
												value={shipment.id}
											/>

											{#each NEXT[shipment.status] ?? [] as next (next)}
												<Button
													size="xs"
													color={
														next === 'failed' || next === 'returned'
															? 'alternative'
															: 'primary'
													}
													name="status"
													value={next}
												>
													{statusLabel(next)}
												</Button>
											{/each}

											{#if (NEXT[shipment.status] ?? []).length === 0}
												<span class="text-xs text-gray-400">
													No further action
												</span>
											{/if}
										</form>
									</TableBodyCell>
								</TableBodyRow>
							{/each}
						</TableBody>
					</Table>
				</div>
			{:else}
				<div class="rounded-xl border border-dashed border-gray-300 p-10 text-center dark:border-gray-700">
					<div class="text-3xl">⌕</div>

					<h3 class="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
						No matching shipments
					</h3>

					<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
						Try changing the search term or carrier filter.
					</p>
				</div>
			{/if}
		</Card>
	</div>

	<!-- Carrier performance -->
	<div class="xl:col-span-3">
		<Card>
			<div class="mb-5">
				<h2 class="text-lg font-bold text-gray-900 dark:text-white">
					Carrier performance
				</h2>

				<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
					Delivery performance by carrier.
				</p>
			</div>

			<div class="space-y-5">
				{#each data.carriers as carrier (carrier.carrier)}
					<div>
						<div class="flex items-center justify-between gap-3">
							<div>
								<div class="text-sm font-semibold text-gray-900 dark:text-white">
									{carrier.carrier}
								</div>

								<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									{carrier.total} parcels
								</div>
							</div>

							<Badge
								color={deliveryRate(carrier) >= 90
									? 'green'
									: deliveryRate(carrier) >= 70
										? 'yellow'
										: 'red'}
							>
								{deliveryRate(carrier)}%
							</Badge>
						</div>

						<div class="mt-3 h-2 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700">
							<div
								class="h-full rounded-full bg-primary-600 transition-all"
								style={`width: ${deliveryRate(carrier)}%`}
							></div>
						</div>

						<div class="mt-3 flex items-center justify-between text-xs">
							<span class="text-gray-500 dark:text-gray-400">
								Delivered
							</span>

							<span class="font-medium text-gray-900 dark:text-white">
								{carrier.delivered}/{carrier.total}
							</span>
						</div>

						<div class="mt-1 flex items-center justify-between text-xs">
							<span class="text-gray-500 dark:text-gray-400">
								COD
							</span>

							<span class="font-medium text-gray-900 dark:text-white">
								{money(carrier.cod, true)}
							</span>
						</div>
					</div>
				{/each}
			</div>
		</Card>
	</div>
</div>

<!-- Create labels modal -->
<Modal bind:open={showCreateModal} size="md">
	{#snippet header()}
		<h3 class="text-lg font-semibold text-gray-900 dark:text-white">
			Create shipping labels
		</h3>
	{/snippet}

	<div class="space-y-5">
		<div class="rounded-lg bg-gray-50 p-4 dark:bg-gray-800">
			<div class="text-sm text-gray-500 dark:text-gray-400">
				Selected orders
			</div>

			<div class="mt-1 text-xl font-bold text-gray-900 dark:text-white">
				{selectedReadyOrders.size}
			</div>

			<div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
				Total COD: {money(selectedReadyTotal)}
			</div>
		</div>

		<div>
			<Label for="bulk-carrier" class="mb-2 block">
				Carrier
			</Label>

			<Select id="bulk-carrier" bind:value={selectedCarrier}>
				{#each CARRIERS as carrier (carrier)}
					<option value={carrier}>
						{carrier}
					</option>
				{/each}
			</Select>
		</div>

		<div class="rounded-lg border border-yellow-200 bg-yellow-50 p-4 dark:border-yellow-900 dark:bg-yellow-900/20">
			<p class="text-xs leading-5 text-yellow-800 dark:text-yellow-300">
				The bulk action UI is ready, but the current server contract only
				exposes the existing <code>?/create</code> action for individual
				orders. No new bulk endpoint has been assumed here.
			</p>
		</div>
	</div>

	{#snippet footer()}
		<Button color="alternative" onclick={() => (showCreateModal = false)}>
			Close
		</Button>

		<Button
			color="primary"
			onclick={() => (showCreateModal = false)}
		>
			Continue
		</Button>
	{/snippet}
</Modal>

<!-- Shipment details -->
<Modal bind:open={showShipmentModal} size="lg">
	{#snippet header()}
		<div>
			<div class="text-lg font-semibold text-gray-900 dark:text-white">
				Shipment details
			</div>

			{#if selectedShipment}
				<div class="mt-1 font-mono text-xs text-gray-500 dark:text-gray-400">
					{selectedShipment.tracking_code}
				</div>
			{/if}
		</div>
	{/snippet}

	{#if selectedShipment}
		<div class="space-y-6">
			<div class="flex flex-wrap items-center gap-2">
				<Pill status={selectedShipment.status} />

				<Badge color="gray">
					{selectedShipment.carrier}
				</Badge>

				{#if selectedShipment.cod_collected}
					<Badge color="green">COD collected</Badge>
				{:else}
					<Badge color="yellow">COD pending</Badge>
				{/if}
			</div>

			<div class="grid gap-4 sm:grid-cols-2">
				<div class="detail-card">
					<div class="detail-label">Tracking</div>
					<div class="detail-value font-mono">
						{selectedShipment.tracking_code}
					</div>
				</div>

				<div class="detail-card">
					<div class="detail-label">Order</div>

					<a
						class="detail-value text-primary-600 hover:underline dark:text-primary-400"
						href="/orders/{selectedShipment.order_id}"
					>
						{selectedShipment.reference}
					</a>
				</div>

				<div class="detail-card">
					<div class="detail-label">Customer</div>
					<div class="detail-value">
						{selectedShipment.customer_name}
					</div>
				</div>

				<div class="detail-card">
					<div class="detail-label">Destination</div>
					<div class="detail-value">
						{selectedShipment.customer_city}
					</div>
				</div>

				<div class="detail-card">
					<div class="detail-label">COD amount</div>
					<div class="detail-value">
						{money(selectedShipment.cod_amount)}
					</div>
				</div>

				<div class="detail-card">
					<div class="detail-label">Shipped</div>
					<div class="detail-value">
						{selectedShipment.shipped_at
							? date(selectedShipment.shipped_at)
							: '—'}
					</div>
				</div>
			</div>

			<div>
				<div class="mb-3 text-sm font-semibold text-gray-900 dark:text-white">
					Available next steps
				</div>

				<div class="flex flex-wrap gap-2">
					<form method="POST" action="?/advance" class="flex flex-wrap gap-2">
						<input
							type="hidden"
							name="shipmentId"
							value={selectedShipment.id}
						/>

						{#each NEXT[selectedShipment.status] ?? [] as next (next)}
							<Button
								size="sm"
								color={
									next === 'failed' || next === 'returned'
										? 'alternative'
										: 'primary'
								}
								name="status"
								value={next}
							>
								{statusLabel(next)}
							</Button>
						{/each}

						{#if (NEXT[selectedShipment.status] ?? []).length === 0}
							<span class="text-sm text-gray-500 dark:text-gray-400">
								This shipment has reached a terminal state.
							</span>
						{/if}
					</form>
				</div>
			</div>
		</div>
	{/if}

	{#snippet footer()}
		<Button color="alternative" onclick={() => (showShipmentModal = false)}>
			Close
		</Button>
	{/snippet}
</Modal>

<style>
	.status-filter {
		display: inline-flex;
		align-items: center;
		border-radius: 9999px;
		border: 1px solid rgb(229 231 235);
		padding: 7px 12px;
		font-size: 12px;
		font-weight: 600;
		color: rgb(75 85 99);
		text-transform: capitalize;
		transition:
			background-color 150ms ease,
			border-color 150ms ease,
			color 150ms ease;
	}

	.status-filter:hover {
		border-color: rgb(156 163 175);
		background: rgb(249 250 251);
	}

	.status-filter-active {
		border-color: rgb(37 99 235);
		background: rgb(37 99 235);
		color: white;
	}

	:global(.dark) .status-filter {
		border-color: rgb(55 65 81);
		color: rgb(209 213 219);
	}

	:global(.dark) .status-filter:hover {
		background: rgb(31 41 55);
		border-color: rgb(75 85 99);
	}

	:global(.dark) .status-filter-active {
		border-color: rgb(37 99 235);
		background: rgb(37 99 235);
		color: white;
	}

	.detail-card {
		border-radius: 12px;
		border: 1px solid rgb(229 231 235);
		padding: 14px;
	}

	:global(.dark) .detail-card {
		border-color: rgb(55 65 81);
	}

	.detail-label {
		font-size: 11px;
		font-weight: 600;
		text-transform: uppercase;
		letter-spacing: 0.04em;
		color: rgb(107 114 128);
	}

	.detail-value {
		margin-top: 5px;
		font-size: 14px;
		font-weight: 600;
		color: rgb(17 24 39);
	}

	:global(.dark) .detail-value {
		color: white;
	}

	code {
		font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
			"Liberation Mono", "Courier New", monospace;
	}
</style>