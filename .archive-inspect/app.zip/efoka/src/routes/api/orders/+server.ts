import { error, json } from '@sveltejs/kit';
import { listOrders } from '$lib/server/repo';
import { can } from '$lib/permissions';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ url, locals }) => {
	if (!locals.user || !can(locals.user.role, 'orders.view')) throw error(403, 'Not allowed');
	const requestedLimit = Number(url.searchParams.get('limit') ?? 50);
	const limit = Number.isInteger(requestedLimit) ? Math.max(1, Math.min(200, requestedLimit)) : 50;
	const orders = await listOrders({
		status: url.searchParams.get('status') ?? 'all',
		confirmation: url.searchParams.get('confirmation') ?? 'all',
		search: url.searchParams.get('q') ?? '',
		limit
	});
	return json({ count: orders.length, orders });
};
