import { error, json } from '@sveltejs/kit';
import { analyticsOverview } from '$lib/server/repo';
import { can } from '$lib/permissions';
import type { RequestHandler } from './$types';

function csvCell(value: unknown): string {
	const text = value == null ? '' : String(value);
	return /[\",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function csv(rows: Array<Record<string, unknown>>): string {
	if (!rows.length) return '';
	const columns = [...new Set(rows.flatMap((row) => Object.keys(row)))];
	return [
		columns.map(csvCell).join(','),
		...rows.map((row) => columns.map((column) => csvCell(row[column])).join(','))
	].join('\n');
}

export const GET: RequestHandler = async ({ locals, url }) => {
	if (!locals.user || !can(locals.user.role, 'analytics.view')) throw error(403, 'Not allowed');

	const data = await analyticsOverview();
	if (url.searchParams.get('format') !== 'csv') return json(data);

	const rows: Array<Record<string, unknown>> = [];
	for (const item of data.monthly) rows.push({ section: 'monthly', ...item });
	for (const item of data.sources) rows.push({ section: 'source', ...item });
	for (const item of data.products) rows.push({ section: 'product', ...item });
	for (const item of data.returnsByReason) rows.push({ section: 'return', ...item });

	return new Response(csv(rows), {
		headers: {
			'Content-Type': 'text/csv; charset=utf-8',
			'Content-Disposition': 'attachment; filename="efoka-analytics.csv"'
		}
	});
};
