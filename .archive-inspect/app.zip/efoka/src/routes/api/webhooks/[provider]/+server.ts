import { error, json } from '@sveltejs/kit';
import { timingSafeEqual } from 'node:crypto';
import { ingestStoreOrder } from '$lib/server/ingest';
import type { RequestHandler } from './$types';

// Store platforms (Shopify, WooCommerce, YouCan, a landing page) post new COD
// orders here. Authentication is a shared secret header per integration.
export const POST: RequestHandler = async ({ request, params }) => {
	const secret = process.env.WEBHOOK_SECRET;
	if (!secret || secret.length < 32) throw error(503, 'Webhook authentication is not configured');
	const provided = request.headers.get('x-webhook-secret') ?? '';
	const expectedBytes = Buffer.from(secret);
	const providedBytes = Buffer.from(provided);
	if (expectedBytes.length !== providedBytes.length || !timingSafeEqual(expectedBytes, providedBytes)) {
		throw error(401, 'Invalid webhook secret');
	}
	if (!/^[a-z0-9_-]{1,48}$/i.test(params.provider)) throw error(400, 'Invalid provider');
	if (Number(request.headers.get('content-length') ?? 0) > 250_000) throw error(413, 'Payload too large');

	const payload = await request.json().catch(() => null);
	if (!payload) throw error(400, 'Invalid JSON body');

	const result = await ingestStoreOrder(params.provider, payload);
	return json(result, { status: 201 });
};
