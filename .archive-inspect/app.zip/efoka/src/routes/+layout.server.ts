import type { LayoutServerLoad } from './$types';
import { one } from '$lib/server/db';
import { permissionsFor } from '$lib/permissions';

export const load: LayoutServerLoad = async ({ locals }) => {
	if (!locals.user) {
		return {
			user: null,
			permissions: [],
			badges: {
				confirmation: 0,
				whatsapp: 0,
				inventory: 0
			}
		};
	}

	const counts = await one<{
		confirmation: number;
		whatsapp: number;
		inventory: number;
	}>(`
		SELECT
			(
				SELECT count(*)::int
				FROM orders
				WHERE status = 'new'
					AND confirmation IN ('pending', 'unreachable', 'scheduled')
			) AS confirmation,

			(
				SELECT coalesce(sum(unread), 0)::int
				FROM whatsapp_conversations
			) AS whatsapp,

			(
				SELECT count(*)::int
				FROM products
				WHERE stock <= low_stock
			) AS inventory
	`);

	return {
		user: locals.user,
		permissions: permissionsFor(locals.user.role),
		badges: counts ?? {
			confirmation: 0,
			whatsapp: 0,
			inventory: 0
		}
	};
};