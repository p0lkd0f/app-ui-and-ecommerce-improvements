import { fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { requiredText } from '$lib/server/validation';
import { listCustomers } from '$lib/server/repo';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
	const search = url.searchParams.get('q') ?? '';
	return { customers: await listCustomers(search), search };
};

export const actions: Actions = {
	create: async ({ request, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		try {
			const form = await request.formData();
			const name = requiredText(form.get('full_name'), 'Customer name', 120);
			const phone = requiredText(form.get('phone'), 'Phone number', 32).replace(/[^+\d]/g, '');
			if (phone.replace(/\D/g, '').length < 7) return fail(400, { error: 'Enter a valid customer phone number' });
			const city = requiredText(form.get('city'), 'City', 80);
			const email = typeof form.get('email') === 'string' ? String(form.get('email')).trim().toLowerCase().slice(0, 254) : '';
			const address = typeof form.get('address') === 'string' ? String(form.get('address')).trim().slice(0, 500) : '';
			const created = await query<{ id: number }>(
				'INSERT INTO customers (full_name, phone, email, city, address) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (phone) DO NOTHING RETURNING id',
				[name, phone, email || null, city, address || null]
			);
			if (!created.length) return fail(409, { error: 'A customer already uses that phone number' });
			return { success: `${name} was added` };
		} catch (err) {
			return fail(400, { error: err instanceof Error ? err.message : 'Could not add customer' });
		}
	}
};
