import { error, fail } from '@sveltejs/kit';
import { can } from '$lib/permissions';
import { query } from '$lib/server/db';
import { getCustomer } from '$lib/server/repo';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params }) => {
	const detail = await getCustomer(Number(params.id));
	if (!detail) throw error(404, 'Customer not found');
	return detail;
};

export const actions: Actions = {
	update: async ({ request, params, locals }) => {
		if (!locals.user || !can(locals.user.role, 'orders.edit')) return fail(403, { error: 'Not allowed' });
		const form = await request.formData();
		await query('UPDATE customers SET notes = $2, blacklisted = $3 WHERE id = $1', [
			Number(params.id),
			String(form.get('notes') ?? ''),
			form.get('blacklisted') === 'on'
		]);
		return { success: 'Customer updated' };
	}
};
