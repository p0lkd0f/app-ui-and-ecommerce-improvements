<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import Stat from '$lib/components/Stat.svelte';
	import { date, money, timeAgo } from '$lib/format';
	import type { ActionData, PageData } from './$types';

	let { data, form }: { data: PageData; form: ActionData } = $props();

	const c = $derived(data.customer);

	const deliveryRate = $derived(
		c.orders_count
			? Math.round((c.delivered_count / c.orders_count) * 100)
			: 0
	);

	const deliveryLabel = $derived(
		deliveryRate < 50 ? 'Risky for COD' : 'Reliable buyer'
	);

	const deliveryTone = $derived(
		deliveryRate < 50 ? 'warning' : 'positive'
	);
</script>

<div class="customer-header">
	<div class="header-main">
		<a class="btn small back-button" href="/customers">
			<span aria-hidden="true">←</span>
			Customers
		</a>

		<div class="identity">
			<div class="avatar" aria-hidden="true">
				{c.full_name.charAt(0).toUpperCase()}
			</div>

			<div>
				<div class="eyebrow">CUSTOMER PROFILE</div>

				<div class="identity-name">
					<h1>{c.full_name}</h1>

					<div class="tags">
						{#each c.tags as tag (tag)}
							<span class="pill blue">{tag}</span>
						{/each}

						{#if c.blacklisted}
							<span class="pill red">blacklisted</span>
						{/if}
					</div>
				</div>

				<div class="identity-meta">
					<span>{c.city}</span>
					<span aria-hidden="true">·</span>
					<span class="mono">{c.phone}</span>
				</div>
			</div>
		</div>
	</div>

	<div class="customer-since">
		<span class="muted tiny">Customer since</span>
		<strong>{date(c.created_at)}</strong>
	</div>
</div>

{#if form?.success}
	<div class="notice" role="status">
		<span class="notice-icon" aria-hidden="true">✓</span>
		{form.success}
	</div>
{/if}

{#if form?.error}
	<div class="error" role="alert">
		<span class="notice-icon" aria-hidden="true">!</span>
		{form.error}
	</div>
{/if}

<div class="grid cols-4 stats-grid">
	<Stat
		label="Lifetime value"
		value={money(c.total_spent)}
		foot="Delivered orders only"
	/>

	<Stat
		label="Orders"
		value={c.orders_count}
		foot={`${c.delivered_count} delivered`}
	/>

	<Stat
		label="Delivery rate"
		value={`${deliveryRate}%`}
		foot={deliveryLabel}
	/>

	<Stat
		label="City"
		value={c.city}
		foot={c.phone}
	/>
</div>

<div class="profile-layout">
	<section class="panel order-panel">
		<div class="panel-head">
			<div>
				<div class="section-kicker">ACTIVITY</div>
				<h2>Order history</h2>
			</div>

			<span class="pill gradient">
				{data.orders.length} orders
			</span>
		</div>

		<div class="table-wrap">
			<table>
				<thead>
					<tr>
						<th>Order</th>
						<th>When</th>
						<th>Confirmation</th>
						<th>Status</th>
						<th class="num">Total</th>
					</tr>
				</thead>

				<tbody>
					{#each data.orders as order (order.id)}
						<tr>
							<td>
								<a class="mono order-link" href="/orders/{order.id}">
									{order.reference}
								</a>
							</td>

							<td class="muted tiny">
								{timeAgo(order.created_at)}
							</td>

							<td>
								<Pill status={order.confirmation} />
							</td>

							<td>
								<Pill status={order.status} />
							</td>

							<td class="num">
								<strong>{money(order.total)}</strong>
							</td>
						</tr>
					{:else}
						<tr>
							<td colspan="5">
								<div class="empty-state">
									<div class="empty-icon" aria-hidden="true">⌁</div>
									<strong>No orders yet</strong>
									<span class="muted tiny">
										This customer has no order history.
									</span>
								</div>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>
	</section>

	<aside class="panel profile-panel">
		<div class="panel-head">
			<div>
				<div class="section-kicker">CUSTOMER DATA</div>
				<h2>Profile</h2>
			</div>

			<span class="status-dot" class:warning={deliveryTone === 'warning'}>
				<span></span>
				{deliveryLabel}
			</span>
		</div>

		<div class="panel-body">
			<div class="info-grid">
				<div class="info-item">
					<span class="muted tiny">Phone</span>
					<span class="mono">{c.phone}</span>
				</div>

				<div class="info-item">
					<span class="muted tiny">Email</span>
					<span>{c.email ?? '—'}</span>
				</div>

				<div class="info-item full">
					<span class="muted tiny">Delivery address</span>
					<span>{c.address ?? '—'}</span>
				</div>
			</div>

			<div class="divider"></div>

			<form method="POST" action="?/update" class="stack">
				<div class="field">
					<div class="field-heading">
						<div>
							<label for="notes">Internal notes</label>
							<span class="hint">Only visible to your operations team.</span>
						</div>
					</div>

					<textarea
						id="notes"
						name="notes"
						rows="5"
						placeholder="Add notes about this customer..."
					>{c.notes ?? ''}</textarea>
				</div>

				<label class="block-checkbox" for="blacklisted">
					<input
						id="blacklisted"
						type="checkbox"
						name="blacklisted"
						checked={c.blacklisted}
					/>

					<span class="checkbox-content">
						<strong>Block COD orders</strong>
						<span>
							Prevent this customer from placing new cash-on-delivery orders.
						</span>
					</span>
				</label>

				<button class="primary save-button" type="submit">
					<span aria-hidden="true">✓</span>
					Save customer
				</button>
			</form>
		</div>
	</aside>
</div>

<style>
	.customer-header {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 20px;
		margin-bottom: 20px;
	}

	.header-main {
		display: flex;
		align-items: flex-start;
		gap: 18px;
	}

	.back-button {
		margin-top: 4px;
		white-space: nowrap;
	}

	.identity {
		display: flex;
		align-items: center;
		gap: 13px;
	}

	.avatar {
		display: grid;
		width: 54px;
		height: 54px;
		flex: 0 0 auto;
		place-items: center;
		border: 1px solid var(--line);
		border-radius: 15px;
		background: var(--brand-soft);
		color: var(--brand);
		font-size: 20px;
		font-weight: 750;
		box-shadow: var(--shadow-sm);
	}

	.eyebrow,
	.section-kicker {
		font-size: 10px;
		font-weight: 750;
		letter-spacing: 0.12em;
		color: var(--brand);
	}

	.identity-name {
		display: flex;
		align-items: center;
		flex-wrap: wrap;
		gap: 9px;
		margin-top: 2px;
	}

	.identity-name h1 {
		margin: 0;
		font-size: 25px;
		letter-spacing: -0.03em;
	}

	.tags {
		display: flex;
		flex-wrap: wrap;
		gap: 5px;
	}

	.identity-meta {
		display: flex;
		flex-wrap: wrap;
		gap: 7px;
		margin-top: 5px;
		font-size: 12px;
		color: var(--muted);
	}

	.customer-since {
		display: flex;
		flex-direction: column;
		align-items: flex-end;
		gap: 2px;
		padding-top: 5px;
	}

	.stats-grid {
		margin-bottom: 18px;
	}

	.profile-layout {
		display: grid;
		grid-template-columns: minmax(0, 1.8fr) minmax(300px, 1fr);
		gap: 18px;
	}

	.order-panel,
	.profile-panel {
		min-width: 0;
		overflow: hidden;
	}

	.table-wrap {
		overflow-x: auto;
	}

	.order-link {
		font-weight: 650;
	}

	.status-dot {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		font-size: 11px;
		font-weight: 650;
		color: var(--green, #16a34a);
	}

	.status-dot > span {
		width: 7px;
		height: 7px;
		border-radius: 50%;
		background: currentColor;
	}

	.status-dot.warning {
		color: var(--amber, #d97706);
	}

	.info-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 14px;
	}

	.info-item {
		display: flex;
		flex-direction: column;
		gap: 4px;
		min-width: 0;
	}

	.info-item.full {
		grid-column: 1 / -1;
	}

	.info-item > span:last-child {
		overflow-wrap: anywhere;
	}

	.divider {
		height: 1px;
		margin: 20px 0;
		background: var(--line);
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 7px;
	}

	.field-heading {
		display: flex;
		justify-content: space-between;
	}

	.field-heading label {
		display: block;
		margin-bottom: 3px;
		font-size: 12px;
		font-weight: 650;
	}

	.block-checkbox {
		display: flex;
		align-items: flex-start;
		gap: 10px;
		padding: 12px;
		border: 1px solid var(--line);
		border-radius: 11px;
		cursor: pointer;
		transition: border-color 0.2s ease, background 0.2s ease;
	}

	.block-checkbox:hover {
		border-color: var(--brand);
		background: var(--brand-soft);
	}

	.block-checkbox input {
		width: auto;
		margin-top: 2px;
	}

	.checkbox-content {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.checkbox-content strong {
		font-size: 12px;
	}

	.checkbox-content span {
		font-size: 11px;
		color: var(--muted);
		line-height: 1.45;
	}

	.save-button {
		width: 100%;
		justify-content: center;
	}

	.empty-state {
		display: flex;
		min-height: 180px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 6px;
		text-align: center;
	}

	.empty-icon {
		display: grid;
		width: 42px;
		height: 42px;
		place-items: center;
		margin-bottom: 5px;
		border: 1px solid var(--line);
		border-radius: 12px;
		color: var(--muted);
	}

	.notice,
	.error {
		display: flex;
		align-items: center;
		gap: 10px;
		margin-bottom: 16px;
	}

	.notice-icon {
		display: grid;
		width: 24px;
		height: 24px;
		place-items: center;
		flex: 0 0 auto;
		border-radius: 50%;
		font-weight: 800;
	}

	@media (max-width: 950px) {
		.profile-layout {
			grid-template-columns: 1fr;
		}
	}

	@media (max-width: 700px) {
		.customer-header {
			flex-direction: column;
		}

		.customer-since {
			align-items: flex-start;
		}

		.header-main {
			flex-direction: column;
			width: 100%;
		}

		.identity {
			align-items: flex-start;
		}

		.info-grid {
			grid-template-columns: 1fr;
		}

		.info-item.full {
			grid-column: auto;
		}
	}
</style>