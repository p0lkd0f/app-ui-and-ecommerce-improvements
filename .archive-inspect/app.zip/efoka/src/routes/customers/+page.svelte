<script lang="ts">
	import { date, money } from '$lib/format';
	import type { ActionData, PageData } from './$types';

	let { data, form }: { data: PageData; form: ActionData } = $props();

	const customerCount = $derived(data.customers.length);
</script>

<div class="page-header">
	<div>
		<div class="eyebrow">CUSTOMER OPERATIONS</div>
		<h1>Customers</h1>
		<p class="muted">
			Manage customer records, COD history, risk indicators, and lifetime value.
		</p>
	</div>

	<a class="btn primary" href="#new-customer">
		<span aria-hidden="true">＋</span>
		New customer
	</a>
</div>

{#if form?.success}
	<div class="notice" role="status">
		<span class="notice-icon" aria-hidden="true">✓</span>
		{form.success}
	</div>
{/if}

{#if form?.error}
	<div class="error" role="alert">
		<span class="notice-icon" aria-hidden="true">!</span>
		{form.error}
	</div>
{/if}

<section class="customer-toolbar panel">
	<div class="toolbar-main">
		<div>
			<div class="section-kicker">CUSTOMER DIRECTORY</div>
			<h2>Customer database</h2>
			<span class="hint">{customerCount} customer{customerCount === 1 ? '' : 's'} shown</span>
		</div>

		<div class="toolbar-stats">
			<div class="mini-stat">
				<span class="mini-stat-icon">◉</span>
				<div>
					<strong>{customerCount}</strong>
					<span>Records</span>
				</div>
			</div>

			<div class="mini-stat">
				<span class="mini-stat-icon">⌕</span>
				<div>
					<strong>COD</strong>
					<span>Operations</span>
				</div>
			</div>
		</div>
	</div>

	<form class="customer-search" method="GET" data-sveltekit-keepfocus>
		<div class="search-input">
			<span aria-hidden="true">⌕</span>
			<input
				type="search"
				name="q"
				value={data.search}
				placeholder="Search name, phone or city"
				aria-label="Search customers"
			/>
		</div>

		<button class="primary" type="submit">
			Search
		</button>

		{#if data.search}
			<a class="btn" href="/customers">
				Clear
			</a>
		{/if}
	</form>
</section>

<section class="panel customer-table-panel">
	<div class="panel-head">
		<div>
			<h2>Customer list</h2>
			<span class="hint">Ranked by delivered spend</span>
		</div>

		<span class="pill gradient">
			{customerCount} shown
		</span>
	</div>

	<div class="table-wrap">
		<table>
			<thead>
				<tr>
					<th>Customer</th>
					<th>City</th>
					<th>Tags</th>
					<th class="num">Orders</th>
					<th class="num">Delivered</th>
					<th class="num">Lifetime value</th>
					<th>Since</th>
				</tr>
			</thead>

			<tbody>
				{#each data.customers as customer (customer.id)}
					{@const deliveryRate =
						customer.orders_count > 0
							? customer.delivered_count / customer.orders_count
							: 0}

					<tr>
						<td>
							<div class="customer-cell">
								<div class="customer-avatar" aria-hidden="true">
									{customer.full_name.charAt(0).toUpperCase()}
								</div>

								<div>
									<a
										class="customer-name"
										href="/customers/{customer.id}"
									>
										{customer.full_name}
									</a>

									<div class="muted tiny mono">
										{customer.phone}
									</div>
								</div>
							</div>
						</td>

						<td>
							<span class="city">
								<span aria-hidden="true">⌖</span>
								{customer.city}
							</span>
						</td>

						<td>
							<div class="tag-list">
								{#each customer.tags as tag (tag)}
									<span class="pill blue">{tag}</span>
								{/each}

								{#if customer.blacklisted}
									<span class="pill red">blacklisted</span>
								{/if}

								{#if customer.orders_count > 0 && deliveryRate < 0.4}
									<span class="pill amber">risky COD</span>
								{/if}
							</div>
						</td>

						<td class="num">
							<strong>{customer.orders_count}</strong>
						</td>

						<td class="num">
							<span class:good-number={customer.delivered_count > 0}>
								{customer.delivered_count}
							</span>
						</td>

						<td class="num">
							<strong class="money-value">
								{money(customer.total_spent)}
							</strong>
						</td>

						<td class="muted tiny">
							{date(customer.created_at)}
						</td>
					</tr>
				{:else}
					<tr>
						<td colspan="7">
							<div class="empty-state">
								<div class="empty-icon" aria-hidden="true">⌕</div>
								<strong>No customers found</strong>
								<span>
									No customers match
									{data.search ? `"${data.search}"` : 'your current search'}.
								</span>

								{#if data.search}
									<a class="btn small" href="/customers">
										Clear search
									</a>
								{/if}
							</div>
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>
</section>

<section class="panel quick-create" id="new-customer">
	<div class="panel-head">
		<div>
			<div class="section-kicker">QUICK CREATE</div>
			<h2>Add a customer</h2>
			<span class="hint">
				Create a record before the first order arrives.
			</span>
		</div>

		<span class="pill blue">New record</span>
	</div>

	<div class="panel-body">
		<form method="POST" action="?/create" class="create-form">
			<div class="field">
				<label for="customer-name">Full name</label>
				<input
					id="customer-name"
					name="full_name"
					required
					autocomplete="name"
					placeholder="Customer full name"
				/>
			</div>

			<div class="field">
				<label for="customer-phone">Phone</label>
				<input
					id="customer-phone"
					name="phone"
					inputmode="tel"
					required
					autocomplete="tel"
					placeholder="+212 ..."
				/>
			</div>

			<div class="field">
				<label for="customer-city">City</label>
				<input
					id="customer-city"
					name="city"
					required
					autocomplete="address-level2"
					placeholder="Casablanca"
				/>
			</div>

			<div class="field">
				<label for="customer-email">Email <span>(optional)</span></label>
				<input
					id="customer-email"
					name="email"
					type="email"
					autocomplete="email"
					placeholder="customer@example.com"
				/>
			</div>

			<div class="field address-field">
				<label for="customer-address">Delivery address <span>(optional)</span></label>
				<input
					id="customer-address"
					name="address"
					autocomplete="street-address"
					placeholder="Street, building, district..."
				/>
			</div>

			<div class="create-action">
				<button class="primary" type="submit">
					<span aria-hidden="true">＋</span>
					Save customer
				</button>
			</div>
		</form>
	</div>
</section>

<style>
	.page-header {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 20px;
		margin-bottom: 22px;
	}

	.page-header h1 {
		margin: 2px 0 6px;
		font-size: 28px;
		letter-spacing: -0.03em;
	}

	.page-header p {
		margin: 0;
		max-width: 680px;
	}

	.eyebrow,
	.section-kicker {
		font-size: 10px;
		font-weight: 750;
		letter-spacing: 0.12em;
		color: var(--brand);
	}

	.notice,
	.error {
		display: flex;
		align-items: center;
		gap: 10px;
		margin-bottom: 16px;
	}

	.notice-icon {
		display: grid;
		width: 24px;
		height: 24px;
		place-items: center;
		border-radius: 50%;
		font-weight: 800;
		flex: 0 0 auto;
	}

	.customer-toolbar {
		margin-bottom: 18px;
		overflow: hidden;
	}

	.toolbar-main {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 20px;
		padding: 20px;
		border-bottom: 1px solid var(--line);
	}

	.toolbar-main h2 {
		margin: 3px 0;
	}

	.toolbar-stats {
		display: flex;
		gap: 10px;
	}

	.mini-stat {
		display: flex;
		align-items: center;
		gap: 9px;
		padding: 9px 12px;
		border: 1px solid var(--line);
		border-radius: 10px;
		background: var(--panel-soft, rgba(0, 0, 0, 0.02));
	}

	.mini-stat-icon {
		display: grid;
		width: 30px;
		height: 30px;
		place-items: center;
		border-radius: 8px;
		background: var(--brand-soft);
		color: var(--brand);
		font-weight: 700;
	}

	.mini-stat strong,
	.mini-stat span {
		display: block;
	}

	.mini-stat strong {
		font-size: 13px;
	}

	.mini-stat span:not(.mini-stat-icon) {
		font-size: 10px;
		color: var(--muted);
	}

	.customer-search {
		display: flex;
		gap: 9px;
		padding: 14px 20px;
	}

	.search-input {
		position: relative;
		flex: 1;
	}

	.search-input > span {
		position: absolute;
		left: 12px;
		top: 50%;
		transform: translateY(-50%);
		color: var(--muted);
	}

	.search-input input {
		width: 100%;
		padding-left: 34px;
	}

	.customer-table-panel {
		overflow: hidden;
	}

	.table-wrap {
		overflow-x: auto;
	}

	.customer-cell {
		display: flex;
		align-items: center;
		gap: 10px;
		min-width: 180px;
	}

	.customer-avatar {
		display: grid;
		width: 34px;
		height: 34px;
		flex: 0 0 auto;
		place-items: center;
		border-radius: 10px;
		background: var(--brand-soft);
		color: var(--brand);
		font-size: 12px;
		font-weight: 750;
	}

	.customer-name {
		font-weight: 650;
	}

	.city {
		display: inline-flex;
		align-items: center;
		gap: 5px;
	}

	.tag-list {
		display: flex;
		flex-wrap: wrap;
		gap: 5px;
		min-width: 160px;
	}

	.good-number {
		font-weight: 650;
	}

	.money-value {
		white-space: nowrap;
	}

	.empty-state {
		display: flex;
		min-height: 190px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 7px;
		text-align: center;
		color: var(--muted);
	}

	.empty-state strong {
		color: var(--ink);
	}

	.empty-icon {
		display: grid;
		width: 44px;
		height: 44px;
		place-items: center;
		margin-bottom: 4px;
		border: 1px solid var(--line);
		border-radius: 12px;
		font-size: 20px;
	}

	.quick-create {
		margin-top: 18px;
	}

	.create-form {
		display: grid;
		grid-template-columns: repeat(3, minmax(0, 1fr));
		gap: 14px;
	}

	.field {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.field label {
		font-size: 12px;
		font-weight: 600;
		color: var(--muted);
	}

	.field label span {
		font-weight: 400;
	}

	.address-field {
		grid-column: span 2;
	}

	.create-action {
		display: flex;
		align-items: flex-end;
	}

	.create-action button {
		width: 100%;
		justify-content: center;
	}

	@media (max-width: 900px) {
		.toolbar-main,
		.page-header {
			align-items: stretch;
			flex-direction: column;
		}

		.toolbar-stats {
			width: 100%;
		}

		.mini-stat {
			flex: 1;
		}

		.create-form {
			grid-template-columns: 1fr;
		}

		.address-field {
			grid-column: auto;
		}

		.create-action {
			align-items: stretch;
		}
	}

	@media (max-width: 600px) {
		.customer-search {
			flex-wrap: wrap;
		}

		.search-input {
			flex-basis: 100%;
		}

		.toolbar-stats {
			display: none;
		}
	}
</style>