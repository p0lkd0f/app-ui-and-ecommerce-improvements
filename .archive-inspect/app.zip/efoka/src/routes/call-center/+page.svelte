<script lang="ts">
	import Pill from '$lib/components/Pill.svelte';
	import { money, timeAgo } from '$lib/format';

	let { data } = $props();

	let callStats = $state({
		totalCalls: 2345,
		callsToday: 156,
		answeredToday: 142,
		missedToday: 14,
		avgCallDuration: '4m 32s',
		confirmationRate: 67.8,
		customerSatisfaction: 4.5
	});

	let activeAgents = $state([
		{ id: 1, name: 'Hassan B.', status: 'available', callsHandled: 45, confirmations: 38, satisfaction: 4.7 },
		{ id: 2, name: 'Fatima M.', status: 'on_call', callsHandled: 52, confirmations: 41, satisfaction: 4.6 },
		{ id: 3, name: 'Karim L.', status: 'break', callsHandled: 38, confirmations: 29, satisfaction: 4.4 }
	]);

	let callQueue = $state([
		{ id: 1, orderId: 'EFK-1256', customer: 'Youssef A.', phone: '+212 661 234 567', priority: 'high', waitTime: '2m 15s', value: 450 },
		{ id: 2, orderId: 'EFK-1257', customer: 'Sara K.', phone: '+212 662 345 678', priority: 'medium', waitTime: '5m 30s', value: 280 }
	]);

	function assignCall(callId: number, agentId: number) {
		const call = callQueue.find(c => c.id === callId);
		const agent = activeAgents.find(a => a.id === agentId);
		if (call && agent) {
			agent.status = 'on_call';
			callQueue = callQueue.filter(c => c.id !== callId);
		}
	}
</script>

<div class="grid cols-4">
	<div class="panel stat"><div class="panel-body"><div class="label">Calls Today</div><div class="value">{callStats.callsToday}</div></div></div>
	<div class="panel stat"><div class="panel-body"><div class="label">Confirmation Rate</div><div class="value">{callStats.confirmationRate}%</div></div></div>
	<div class="panel stat"><div class="panel-body"><div class="label">Avg Call Duration</div><div class="value">{callStats.avgCallDuration}</div></div></div>
	<div class="panel stat"><div class="panel-body"><div class="label">Customer Satisfaction</div><div class="value">{callStats.customerSatisfaction}/5.0</div></div></div>
</div>

<div class="grid cols-2" style="margin-top: 18px;">
	<div class="panel">
		<div class="panel-head"><h2>Active Agents</h2></div>
		<div class="panel-body">
			{#each activeAgents as agent (agent.id)}
				<div style="padding: 12px; border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px;">
					<div class="spread"><strong>{agent.name}</strong><Pill status={agent.status} /></div>
					<div class="tiny muted">{agent.callsHandled} calls, {agent.confirmations} confirmations</div>
				</div>
			{/each}
		</div>
	</div>
	<div class="panel">
		<div class="panel-head"><h2>Call Queue</h2></div>
		<div class="panel-body">
			{#each callQueue as call (call.id)}
				<div style="padding: 12px; border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px;">
					<div class="spread"><strong>{call.customer}</strong><span class="pill red">{call.priority}</span></div>
					<div class="tiny muted">{call.phone} · {money(call.value)}</div>
				</div>
			{/each}
		</div>
	</div>
</div>
