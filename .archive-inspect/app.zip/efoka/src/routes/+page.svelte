<script lang="ts">
	import {
		Badge,
		Button,
		Card,
		Heading,
		Table,
		TableBody,
		TableBodyCell,
		TableBodyRow,
		TableHead,
		TableHeadCell
	} from 'flowbite-svelte';

	import BarChart from '$lib/components/BarChart.svelte';
	import Pill from '$lib/components/Pill.svelte';
	import { money, timeAgo } from '$lib/format';

	let { data } = $props();

	const s = $derived(data.summary);

	const maxCityRevenue = $derived(Math.max(
		1,
		...s.topCities.map((city) => city.revenue)
	));

	const totalPipeline = $derived(s.statusBreakdown.reduce(
		(total: number, row: { count: number }) => total + row.count,
		0
	));

	function cityRevenuePercent(revenue: number) {
		return Math.min(100, Math.max(0, (revenue / maxCityRevenue) * 100));
	}

	function deliveryPercent(delivered: number, orders: number) {
		return orders ? Math.round((delivered / orders) * 100) : 0;
	}

	function agentRate(confirmed: number, handled: number) {
		return handled ? Math.round((confirmed / handled) * 100) : 0;
	}
</script>

<div class="dashboard">
	<!-- Header -->
	<section class="dashboard-intro">
		<div>
			<div class="eyebrow">
				<span class="live-dot"></span>
				Operations overview
			</div>

			<Heading tag="h2" class="dashboard-title">
				Good overview, keep things moving.
			</Heading>

			<p class="dashboard-description">
				Monitor orders, deliveries, cash flow and customer operations
				from one place.
			</p>
		</div>

		<div class="intro-actions">
			<Button href="/orders" color="light" size="sm">
				View orders
			</Button>

			<Button href="/confirmation" size="sm">
				Open confirmation queue
			</Button>
		</div>
	</section>

	<!-- KPI cards -->
	<section class="kpi-grid">
		<Card class="kpi-card">
			<div class="kpi-top">
				<span class="kpi-label">Revenue</span>
				<span class="kpi-period">7 days</span>
			</div>

			<div class="kpi-value">
				{money(s.revenue7)}
			</div>

			<div class="kpi-footer">
				<span class="kpi-icon revenue">↗</span>
				<span>{s.orders7} orders created</span>
			</div>
		</Card>

		<Card class="kpi-card">
			<div class="kpi-top">
				<span class="kpi-label">Net profit</span>
				<span class="kpi-period">30 days</span>
			</div>

			<div class="kpi-value">
				{money(s.profit30)}
			</div>

			<div class="kpi-footer">
				<span class="kpi-icon profit">+</span>
				<span>on {money(s.revenue30)} delivered</span>
			</div>
		</Card>

		<Card class="kpi-card">
			<div class="kpi-top">
				<span class="kpi-label">Delivery rate</span>
				<span class="kpi-period">30 days</span>
			</div>

			<div class="kpi-value">
				{s.deliveryRate}%
			</div>

			<div class="kpi-progress">
				<div
					class="progress-fill"
					style={`width:${Math.min(100, Math.max(0, s.deliveryRate))}%`}
				></div>
			</div>

			<div class="kpi-footer">
				<span>{s.confirmationRate}% confirmed</span>
			</div>
		</Card>

		<Card class="kpi-card kpi-card-warning">
			<div class="kpi-top">
				<span class="kpi-label">COD cash in transit</span>
				<span class="kpi-period">{s.inTransit} parcels</span>
			</div>

			<div class="kpi-value">
				{money(s.codOutstanding)}
			</div>

			<div class="kpi-footer">
				<span class="kpi-icon cash">◌</span>
				<span>Currently with carriers</span>
			</div>
		</Card>
	</section>

	<!-- Main analytics row -->
	<section class="analytics-grid">
		<Card class="chart-card">
			<div class="section-heading">
				<div>
					<div class="section-kicker">Performance</div>
					<Heading tag="h3">Orders &amp; deliveries</Heading>
					<p>Daily activity over the last 14 days</p>
				</div>

				<Badge color="gray">
					Last 14 days
				</Badge>
			</div>

			<div class="chart-wrap">
				<BarChart series={s.series} />
			</div>
		</Card>

		<Card class="attention-card">
			<div class="section-heading">
				<div>
					<div class="section-kicker">Action center</div>
					<Heading tag="h3">Needs attention</Heading>
					<p>Items that may require action</p>
				</div>
			</div>

			<div class="attention-list">
				<a href="/confirmation" class="attention-item">
					<div class="attention-icon amber">
						◉
					</div>

					<div class="attention-copy">
						<strong>Orders waiting for a call</strong>
						<span>Confirmation queue</span>
					</div>

					<Badge color="yellow">
						{s.pendingConfirmation}
					</Badge>

					<span class="attention-arrow">›</span>
				</a>

				<a href="/inbox" class="attention-item">
					<div class="attention-icon green">
						▱
					</div>

					<div class="attention-copy">
						<strong>Unread WhatsApp messages</strong>
						<span>Customer conversations</span>
					</div>

					<Badge color="green">
						{s.unreadChats}
					</Badge>

					<span class="attention-arrow">›</span>
				</a>

				<a href="/products" class="attention-item">
					<div class="attention-icon red">
						◇
					</div>

					<div class="attention-copy">
						<strong>Low stock SKUs</strong>
						<span>At or below reorder point</span>
					</div>

					<Badge color="red">
						{s.lowStock}
					</Badge>

					<span class="attention-arrow">›</span>
				</a>

				<a href="/shipping" class="attention-item">
					<div class="attention-icon blue">
						↗
					</div>

					<div class="attention-copy">
						<strong>Parcels in transit</strong>
						<span>Currently with carriers</span>
					</div>

					<Badge color="blue">
						{s.inTransit}
					</Badge>

					<span class="attention-arrow">›</span>
				</a>
			</div>

			<div class="pipeline">
				<div class="pipeline-header">
					<span>Order pipeline</span>
					<span>{totalPipeline} orders</span>
				</div>

				<div class="pipeline-list">
					{#each s.statusBreakdown as row (row.status)}
						<div class="pipeline-row">
							<div class="pipeline-label">
								<Pill status={row.status} />
							</div>

							<div class="pipeline-track">
								<div
									class="pipeline-fill"
									style={`width:${totalPipeline ? (row.count / totalPipeline) * 100 : 0}%`}
								></div>
							</div>

							<span class="pipeline-count">
								{row.count}
							</span>
						</div>
					{/each}
				</div>
			</div>
		</Card>
	</section>

	<!-- Operational tables -->
	<section class="tables-grid">
		<Card class="table-card">
			<div class="section-heading">
				<div>
					<div class="section-kicker">Orders</div>
					<Heading tag="h3">Latest orders</Heading>
					<p>Most recently created orders</p>
				</div>

				<Button
					href="/orders"
					color="light"
					size="xs"
				>
					View all
				</Button>
			</div>

			<div class="table-scroll">
				<Table hoverable={true}>
					<TableHead>
						<TableHeadCell>Order</TableHeadCell>
						<TableHeadCell>Customer</TableHeadCell>
						<TableHeadCell>Status</TableHeadCell>
						<TableHeadCell class="text-right">
							Total
						</TableHeadCell>
					</TableHead>

					<TableBody>
						{#each data.latest as order (order.id)}
							<TableBodyRow>
								<TableBodyCell>
									<a
										class="order-reference"
										href="/orders/{order.id}"
									>
										{order.reference}
									</a>
								</TableBodyCell>

								<TableBodyCell>
									<div class="customer-name">
										{order.customer_name}
									</div>

									<div class="customer-meta">
										{order.customer_city}
										<span>·</span>
										{timeAgo(order.created_at)}
									</div>
								</TableBodyCell>

								<TableBodyCell>
									<Pill status={order.status} />
								</TableBodyCell>

								<TableBodyCell class="text-right amount">
									{money(order.total)}
								</TableBodyCell>
							</TableBodyRow>
						{:else}
							<TableBodyRow>
								<TableBodyCell colspan={4}>
									<div class="empty-state">
										<div class="empty-icon">□</div>
										<strong>No orders yet</strong>
										<span>
											New orders will appear here.
										</span>
									</div>
								</TableBodyCell>
							</TableBodyRow>
						{/each}
					</TableBody>
				</Table>
			</div>
		</Card>

		<Card class="table-card">
			<div class="section-heading">
				<div>
					<div class="section-kicker">Confirmation</div>
					<Heading tag="h3">Call queue</Heading>
					<p>Orders waiting for customer confirmation</p>
				</div>

				<Button
					href="/confirmation"
					color="light"
					size="xs"
				>
					Open queue
				</Button>
			</div>

			<div class="table-scroll">
				<Table hoverable={true}>
					<TableHead>
						<TableHeadCell>Order</TableHeadCell>
						<TableHeadCell>Customer</TableHeadCell>
						<TableHeadCell>Attempts</TableHeadCell>
						<TableHeadCell class="text-right">
							Total
						</TableHeadCell>
					</TableHead>

					<TableBody>
						{#each data.queue as order (order.id)}
							<TableBodyRow>
								<TableBodyCell>
									<a
										class="order-reference"
										href="/orders/{order.id}"
									>
										{order.reference}
									</a>
								</TableBodyCell>

								<TableBodyCell>
									<div class="customer-name">
										{order.customer_name}
									</div>

									<div class="customer-meta phone">
										{order.customer_phone}
									</div>
								</TableBodyCell>

								<TableBodyCell>
									<Pill
										status={order.confirmation}
										text={`${order.confirmation} · ${order.call_attempts}`}
									/>
								</TableBodyCell>

								<TableBodyCell class="text-right amount">
									{money(order.total)}
								</TableBodyCell>
							</TableBodyRow>
						{:else}
							<TableBodyRow>
								<TableBodyCell colspan={4}>
									<div class="empty-state compact">
										<div class="empty-icon success">
											✓
										</div>
										<strong>Queue is clear</strong>
										<span>
											There are no orders waiting for
											a call.
										</span>
									</div>
								</TableBodyCell>
							</TableBodyRow>
						{/each}
					</TableBody>
				</Table>
			</div>
		</Card>
	</section>

	<!-- Performance -->
	<section class="performance-grid">
		<Card class="city-card">
			<div class="section-heading">
				<div>
					<div class="section-kicker">Geography</div>
					<Heading tag="h3">
						Top cities by delivered revenue
					</Heading>
					<p>Where your delivered revenue is coming from</p>
				</div>
			</div>

			<div class="table-scroll">
				<Table hoverable={true}>
					<TableHead>
						<TableHeadCell>City</TableHeadCell>
						<TableHeadCell>Orders</TableHeadCell>
						<TableHeadCell>Delivery rate</TableHeadCell>
						<TableHeadCell class="text-right">
							Revenue
						</TableHeadCell>
					</TableHead>

					<TableBody>
						{#each s.topCities as city (city.city)}
							<TableBodyRow>
								<TableBodyCell>
									<strong>{city.city}</strong>
								</TableBodyCell>

								<TableBodyCell>
									{city.orders}
								</TableBodyCell>

								<TableBodyCell>
									<div class="city-performance">
										<div class="city-progress">
											<div
												class="city-progress-fill"
												style={`width:${cityRevenuePercent(city.revenue)}%`}
											></div>
										</div>

										<span>
											{deliveryPercent(
												city.delivered,
												city.orders
											)}%
										</span>
									</div>
								</TableBodyCell>

								<TableBodyCell class="text-right amount">
									{money(city.revenue)}
								</TableBodyCell>
							</TableBodyRow>
						{:else}
							<TableBodyRow>
								<TableBodyCell colspan={4}>
									<div class="empty-state">
										<strong>No city data</strong>
										<span>
											Delivered revenue will appear
											here.
										</span>
									</div>
								</TableBodyCell>
							</TableBodyRow>
						{/each}
					</TableBody>
				</Table>
			</div>
		</Card>

		<Card class="agents-card">
			<div class="section-heading">
				<div>
					<div class="section-kicker">Team</div>
					<Heading tag="h3">Call center performance</Heading>
					<p>Confirmation activity by agent</p>
				</div>
			</div>

			<div class="agent-list">
				{#each s.agents as agent (agent.name)}
					<div class="agent-row">
						<div class="agent-avatar">
							{agent.name
								.split(' ')
								.map((part: string) => part[0])
								.join('')
								.slice(0, 2)
								.toUpperCase()}
						</div>

						<div class="agent-info">
							<strong>{agent.name}</strong>

							<span>
								{agent.handled} calls
								<span class="separator">·</span>
								{agent.confirmed} confirmed
							</span>
						</div>

						<div class="agent-rate">
							<strong>
								{agentRate(
									agent.confirmed,
									agent.handled
								)}%
							</strong>

							<div class="agent-progress">
								<div
									class="agent-progress-fill"
									style={`width:${agentRate(agent.confirmed, agent.handled)}%`}
								></div>
							</div>
						</div>
					</div>
				{:else}
					<div class="empty-state">
						<strong>No agent activity</strong>
						<span>
							Call center performance will appear here.
						</span>
					</div>
				{/each}
			</div>
		</Card>
	</section>
</div>

<style>
	.dashboard {
		display: flex;
		flex-direction: column;
		gap: 20px;
	}

	.dashboard-intro {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		gap: 24px;
		padding: 2px 2px 4px;
	}

	.eyebrow {
		display: flex;
		align-items: center;
		gap: 7px;
		margin-bottom: 7px;
		color: var(--brand);
		font-size: 10px;
		font-weight: 750;
		letter-spacing: 0.08em;
		text-transform: uppercase;
	}

	.live-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: #22c55e;
		box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.1);
	}

	:global(.dashboard-title) {
		margin: 0 !important;
		color: var(--ink);
		font-size: 22px !important;
		font-weight: 750 !important;
		letter-spacing: -0.035em;
	}

	.dashboard-description {
		margin: 5px 0 0;
		color: var(--muted);
		font-size: 11px;
	}

	.intro-actions {
		display: flex;
		align-items: center;
		gap: 8px;
	}

	.kpi-grid {
		display: grid;
		grid-template-columns: repeat(4, minmax(0, 1fr));
		gap: 14px;
	}

	:global(.kpi-card) {
		min-width: 0;
		padding: 17px !important;
		border: 1px solid var(--line);
		border-radius: 13px !important;
		box-shadow: 0 2px 8px rgba(24, 32, 56, 0.035);
	}

	:global(.kpi-card-warning) {
		background:
			linear-gradient(
				135deg,
				rgba(245, 158, 11, 0.045),
				var(--panel)
			);
	}

	.kpi-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 8px;
	}

	.kpi-label {
		color: var(--muted);
		font-size: 10px;
		font-weight: 650;
	}

	.kpi-period {
		color: #9ba4b7;
		font-size: 9px;
	}

	.kpi-value {
		margin-top: 8px;
		color: var(--ink);
		font-size: 23px;
		font-weight: 750;
		letter-spacing: -0.035em;
	}

	.kpi-footer {
		display: flex;
		align-items: center;
		gap: 7px;
		margin-top: 10px;
		color: var(--muted);
		font-size: 9px;
	}

	.kpi-icon {
		width: 20px;
		height: 20px;
		display: grid;
		place-items: center;
		border-radius: 6px;
		font-size: 11px;
		font-weight: 800;
	}

	.kpi-icon.revenue {
		background: rgba(99, 102, 241, 0.09);
		color: var(--brand);
	}

	.kpi-icon.profit {
		background: rgba(34, 197, 94, 0.09);
		color: #16a34a;
	}

	.kpi-icon.cash {
		background: rgba(245, 158, 11, 0.1);
		color: #d97706;
	}

	.kpi-progress {
		height: 4px;
		margin-top: 11px;
		overflow: hidden;
		border-radius: 99px;
		background: #eef0f5;
	}

	.progress-fill {
		height: 100%;
		border-radius: inherit;
		background: linear-gradient(
			90deg,
			var(--gradient-start),
			var(--gradient-end)
		);
	}

	.analytics-grid {
		display: grid;
		grid-template-columns: minmax(0, 1.8fr) minmax(330px, 1fr);
		gap: 14px;
	}

	:global(.chart-card),
	:global(.attention-card),
	:global(.table-card),
	:global(.city-card),
	:global(.agents-card) {
		min-width: 0;
		padding: 0 !important;
		overflow: hidden;
		border: 1px solid var(--line);
		border-radius: 13px !important;
		box-shadow: 0 2px 8px rgba(24, 32, 56, 0.035);
	}

	.section-heading {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 16px;
		padding: 17px 18px;
		border-bottom: 1px solid var(--line);
	}

	.section-kicker {
		margin-bottom: 3px;
		color: var(--brand);
		font-size: 8px;
		font-weight: 800;
		letter-spacing: 0.09em;
		text-transform: uppercase;
	}

	.section-heading :global(h3) {
		margin: 0;
		color: var(--ink);
		font-size: 13px;
		font-weight: 700;
		letter-spacing: -0.015em;
	}

	.section-heading p {
		margin: 3px 0 0;
		color: var(--muted);
		font-size: 9px;
	}

	.chart-wrap {
		min-height: 300px;
		padding: 18px;
	}

	.attention-list {
		padding: 8px 10px;
	}

	.attention-item {
		display: grid;
		grid-template-columns: 31px minmax(0, 1fr) auto 10px;
		align-items: center;
		gap: 9px;
		min-height: 52px;
		padding: 6px 8px;
		border-radius: 9px;
		color: inherit;
		text-decoration: none;
		transition: background 0.15s ease;
	}

	.attention-item:hover {
		background: var(--brand-soft);
	}

	.attention-icon {
		width: 31px;
		height: 31px;
		display: grid;
		place-items: center;
		border-radius: 8px;
		font-size: 12px;
		font-weight: 700;
	}

	.attention-icon.amber {
		background: rgba(245, 158, 11, 0.1);
		color: #d97706;
	}

	.attention-icon.green {
		background: rgba(34, 197, 94, 0.1);
		color: #16a34a;
	}

	.attention-icon.red {
		background: rgba(239, 68, 68, 0.1);
		color: #dc2626;
	}

	.attention-icon.blue {
		background: rgba(59, 130, 246, 0.1);
		color: #2563eb;
	}

	.attention-copy {
		min-width: 0;
		display: flex;
		flex-direction: column;
	}

	.attention-copy strong {
		color: var(--ink);
		font-size: 10px;
		font-weight: 650;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.attention-copy span {
		margin-top: 2px;
		color: var(--muted);
		font-size: 8px;
	}

	.attention-arrow {
		color: #adb5c5;
		font-size: 17px;
	}

	.pipeline {
		margin: 6px 18px 18px;
		padding-top: 14px;
		border-top: 1px solid var(--line);
	}

	.pipeline-header {
		display: flex;
		justify-content: space-between;
		margin-bottom: 10px;
		color: var(--muted);
		font-size: 9px;
		font-weight: 650;
	}

	.pipeline-list {
		display: flex;
		flex-direction: column;
		gap: 7px;
	}

	.pipeline-row {
		display: grid;
		grid-template-columns: 90px minmax(0, 1fr) 25px;
		align-items: center;
		gap: 7px;
	}

	.pipeline-track {
		height: 5px;
		overflow: hidden;
		border-radius: 99px;
		background: #edf0f5;
	}

	.pipeline-fill {
		height: 100%;
		border-radius: inherit;
		background: linear-gradient(
			90deg,
			var(--gradient-start),
			var(--gradient-end)
		);
	}

	.pipeline-count {
		color: var(--muted);
		font-size: 9px;
		text-align: right;
	}

	.tables-grid,
	.performance-grid {
		display: grid;
		grid-template-columns: repeat(2, minmax(0, 1fr));
		gap: 14px;
	}

	.table-scroll {
		width: 100%;
		overflow-x: auto;
	}

	.order-reference {
		color: var(--brand);
		font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
			monospace;
		font-size: 10px;
		font-weight: 650;
		text-decoration: none;
	}

	.order-reference:hover {
		text-decoration: underline;
	}

	.customer-name {
		color: var(--ink);
		font-size: 10px;
		font-weight: 550;
	}

	.customer-meta {
		display: flex;
		align-items: center;
		gap: 4px;
		margin-top: 3px;
		color: var(--muted);
		font-size: 8px;
	}

	.customer-meta.phone {
		font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
			monospace;
	}

	:global(.amount) {
		font-size: 10px;
		font-weight: 650;
		white-space: nowrap;
	}

	:global(.text-right) {
		text-align: right !important;
	}

	.empty-state {
		min-height: 130px;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		gap: 4px;
		color: var(--muted);
		text-align: center;
	}

	.empty-state strong {
		color: var(--ink);
		font-size: 11px;
	}

	.empty-state span {
		font-size: 9px;
	}

	.empty-state.compact {
		min-height: 110px;
	}

	.empty-icon {
		width: 30px;
		height: 30px;
		display: grid;
		place-items: center;
		margin-bottom: 3px;
		border-radius: 50%;
		background: #f0f2f6;
		color: #8993a8;
		font-size: 12px;
	}

	.empty-icon.success {
		background: rgba(34, 197, 94, 0.09);
		color: #16a34a;
	}

	.city-performance {
		display: grid;
		grid-template-columns: minmax(60px, 1fr) 30px;
		align-items: center;
		gap: 8px;
		min-width: 120px;
	}

	.city-progress {
		height: 5px;
		overflow: hidden;
		border-radius: 99px;
		background: #edf0f5;
	}

	.city-progress-fill {
		height: 100%;
		border-radius: inherit;
		background: var(--brand);
	}

	.city-performance > span {
		color: var(--muted);
		font-size: 8px;
		text-align: right;
	}

	.agent-list {
		padding: 8px 16px 16px;
	}

	.agent-row {
		display: grid;
		grid-template-columns: 34px minmax(0, 1fr) 100px;
		align-items: center;
		gap: 10px;
		min-height: 58px;
		border-bottom: 1px solid var(--line);
	}

	.agent-row:last-child {
		border-bottom: 0;
	}

	.agent-avatar {
		width: 32px;
		height: 32px;
		display: grid;
		place-items: center;
		border-radius: 9px;
		background: var(--brand-soft);
		color: var(--brand);
		font-size: 9px;
		font-weight: 750;
	}

	.agent-info {
		min-width: 0;
		display: flex;
		flex-direction: column;
	}

	.agent-info strong {
		color: var(--ink);
		font-size: 10px;
		font-weight: 650;
	}

	.agent-info span {
		margin-top: 3px;
		color: var(--muted);
		font-size: 8px;
	}

	.separator {
		padding: 0 3px;
	}

	.agent-rate {
		text-align: right;
	}

	.agent-rate strong {
		color: var(--ink);
		font-size: 11px;
	}

	.agent-progress {
		height: 4px;
		margin-top: 5px;
		overflow: hidden;
		border-radius: 99px;
		background: #edf0f5;
	}

	.agent-progress-fill {
		height: 100%;
		border-radius: inherit;
		background: var(--brand);
	}

	@media (max-width: 1200px) {
		.kpi-grid {
			grid-template-columns: repeat(2, minmax(0, 1fr));
		}

		.analytics-grid {
			grid-template-columns: 1fr;
		}
	}

	@media (max-width: 800px) {
		.dashboard-intro {
			align-items: flex-start;
			flex-direction: column;
		}

		.tables-grid,
		.performance-grid {
			grid-template-columns: 1fr;
		}
	}

	@media (max-width: 560px) {
		.kpi-grid {
			grid-template-columns: 1fr;
		}

		:global(.dashboard-title) {
			font-size: 19px !important;
		}

		.intro-actions {
			width: 100%;
		}

		.intro-actions :global(a) {
			flex: 1;
		}

		.section-heading {
			padding: 14px;
		}

		.chart-wrap {
			padding: 10px;
		}

		.pipeline-row {
			grid-template-columns: 75px minmax(0, 1fr) 22px;
		}

		.agent-row {
			grid-template-columns: 34px minmax(0, 1fr) 75px;
		}
	}
</style>