# CODCommerce

CODCommerce is an operations workspace for cash-on-delivery commerce: orders, confirmation calls, customer conversations, stock, carrier hand-offs, returns, team access and reporting all live in one place.

## Run locally

1. Copy `.env.example` to `.env` and configure PostgreSQL and Redis.
2. Create an empty PostgreSQL database, fill in the `OWNER_*` and `STORE_*` values in `.env`, then run `npm run db:init`.
4. Run `npm ci`, then `npm run dev`.

The workspace does not ship a shared password, a default webhook secret, or pretend that a provider has synced. Webhooks require a unique `WEBHOOK_SECRET` with at least 32 characters.

## Google sign-in

Create an OAuth 2.0 Web application in Google Cloud Console and add `https://your-domain/auth/google/callback` as an authorized redirect URI. Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and optionally `GOOGLE_REDIRECT_URI`; existing workspaces must run `npm run db:migrate:google` once. Google sign-in is intentionally limited to people who already have a workspace account with the same verified email.

## Production checklist

- Use TLS and set `DATABASE_URL`, `REDIS_URL`, and `WEBHOOK_SECRET` as deployment secrets.
- Restrict database and Redis networking to the app only; back up the database before applying migrations.
- Configure provider credentials and an approved adapter before connecting WhatsApp, carriers, or store platforms.
- Publish a privacy notice and obtain visitor consent before enabling Hotjar or any behavioral analytics.
- Review team roles regularly; suspending a member immediately prevents future logins.
