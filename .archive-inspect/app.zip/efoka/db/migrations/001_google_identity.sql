-- Apply once to existing workspaces before enabling Google sign-in.
ALTER TABLE users ADD COLUMN IF NOT EXISTS google_subject TEXT UNIQUE;
