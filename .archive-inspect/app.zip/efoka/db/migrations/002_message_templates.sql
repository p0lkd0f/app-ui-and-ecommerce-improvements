CREATE TABLE IF NOT EXISTS message_templates (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  channel TEXT NOT NULL DEFAULT 'whatsapp' CHECK (channel IN ('whatsapp','instagram','sms')),
  body TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'operations',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
