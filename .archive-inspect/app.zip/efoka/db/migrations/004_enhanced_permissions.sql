-- Enhanced Permissions and Role Management
-- This migration adds granular permissions for the advanced features

-- Add new permissions
INSERT INTO permissions (name) VALUES
('ai.manage'),
('ai.view'),
('campaigns.manage'),
('campaigns.view'),
('delivery.manage'),
('delivery.view'),
('analytics.advanced'),
('profile.edit'),
('settings.manage'),
('reports.export'),
('webhooks.manage')
ON CONFLICT (name) DO NOTHING;

-- Update role permissions
-- Owner gets all permissions
UPDATE roles SET permissions = (
	SELECT array_agg(name) FROM permissions
) WHERE name = 'owner';

-- Manager gets most permissions except team management
UPDATE roles SET permissions = (
	SELECT array_agg(name) FROM permissions
	WHERE name NOT IN ('team.manage', 'settings.manage')
) WHERE name = 'manager';

-- Agent gets basic operational permissions
UPDATE roles SET permissions = (
	SELECT array_agg(name) FROM permissions
	WHERE name IN (
		'orders.view',
		'confirmation.handle',
		'whatsapp.reply',
		'delivery.view',
		'ai.view',
		'campaigns.view'
	)
) WHERE name = 'agent';

-- Packer gets fulfillment permissions
UPDATE roles SET permissions = (
	SELECT array_agg(name) FROM permissions
	WHERE name IN (
		'orders.view',
		'shipping.manage',
		'inventory.manage',
		'delivery.view'
	)
) WHERE name = 'packer';

-- Add role descriptions
ALTER TABLE roles ADD COLUMN IF NOT EXISTS description TEXT;
UPDATE roles SET description = 'Full access to all features and settings' WHERE name = 'owner';
UPDATE roles SET description = 'Manage operations, team, and most features' WHERE name = 'manager';
UPDATE roles SET description = 'Handle order confirmations and customer support' WHERE name = 'agent';
UPDATE roles SET description = 'Manage shipping and inventory operations' WHERE name = 'packer';

-- Create audit log table
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(255) NOT NULL,
    resource_type VARCHAR(100),
    resource_id INTEGER,
    old_values JSONB,
    new_values JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_resource ON audit_log(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(created_at);

-- Create webhook logs table
CREATE TABLE IF NOT EXISTS webhook_logs (
    id SERIAL PRIMARY KEY,
    provider VARCHAR(100) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB,
    response_status INTEGER,
    response_body TEXT,
    processing_time_ms INTEGER,
    success BOOLEAN DEFAULT false,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_webhook_logs_provider ON webhook_logs(provider);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_event ON webhook_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_timestamp ON webhook_logs(created_at);

-- Add comments
COMMENT ON TABLE audit_log IS 'Audit trail for all user actions';
COMMENT ON TABLE webhook_logs IS 'Log of all incoming and outgoing webhooks';
