import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import pg from 'pg';
import { hashPassword } from '../src/lib/server/password.js';

const databaseUrl = process.env.DATABASE_URL;
const ownerEmail = process.env.OWNER_EMAIL?.trim().toLowerCase();
const ownerPassword = process.env.OWNER_PASSWORD;
const storeName = process.env.STORE_NAME?.trim();
const storeDomain = process.env.STORE_DOMAIN?.trim();

if (!databaseUrl || !ownerEmail || !ownerPassword || !storeName || !storeDomain) {
	throw new Error('Set DATABASE_URL, OWNER_EMAIL, OWNER_PASSWORD, STORE_NAME and STORE_DOMAIN before initializing.');
}
if (ownerPassword.length < 12) throw new Error('OWNER_PASSWORD must be at least 12 characters.');

const here = dirname(fileURLToPath(import.meta.url));
const client = new pg.Client({ connectionString: databaseUrl });

async function main() {
	await client.connect();
	await client.query(readFileSync(join(here, 'schema.sql'), 'utf8'));
	await client.query('INSERT INTO stores (name, domain) VALUES ($1,$2)', [storeName, storeDomain]);
	await client.query("INSERT INTO users (name, email, password_hash, role) VALUES ($1,$2,$3,'owner')", [
		'Workspace owner', ownerEmail, hashPassword(ownerPassword)
	]);
	console.log('Workspace initialized. Sign in with the owner account you configured.');
	await client.end();
}

main().catch(async (err) => {
	console.error(err instanceof Error ? err.message : err);
	await client.end().catch(() => {});
	process.exitCode = 1;
});
