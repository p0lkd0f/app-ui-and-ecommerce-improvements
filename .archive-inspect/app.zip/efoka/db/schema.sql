-- CODCommerce schema (PostgreSQL 14+)
--
-- This file is for an empty database only. It deliberately never drops data.
-- Apply future changes through versioned migrations, after taking a backup.

CREATE TABLE users (
  id            SERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
	google_subject TEXT UNIQUE,
  role          TEXT NOT NULL CHECK (role IN ('owner', 'manager', 'agent', 'packer')),
  active        BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE stores (
  id         SERIAL PRIMARY KEY,
  name       TEXT NOT NULL,
  domain     TEXT NOT NULL,
  currency   TEXT NOT NULL DEFAULT 'USD',
  country    TEXT NOT NULL DEFAULT 'MA',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE integrations (
  id          SERIAL PRIMARY KEY,
  store_id    INTEGER REFERENCES stores(id) ON DELETE CASCADE,
  provider    TEXT NOT NULL,
  kind        TEXT NOT NULL CHECK (kind IN ('store', 'shipping', 'messaging', 'analytics')),
  status      TEXT NOT NULL CHECK (status IN ('connected', 'disconnected', 'error')),
  account_ref TEXT,
  last_sync   TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE customers (
  id          SERIAL PRIMARY KEY,
  full_name   TEXT NOT NULL,
  phone       TEXT NOT NULL UNIQUE,
  email       TEXT,
  city        TEXT NOT NULL,
  address     TEXT,
  tags        TEXT[] NOT NULL DEFAULT '{}',
  blacklisted BOOLEAN NOT NULL DEFAULT FALSE,
  notes       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE products (
  id         SERIAL PRIMARY KEY,
  sku        TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  category   TEXT NOT NULL DEFAULT 'general',
  price      NUMERIC(12, 2) NOT NULL,
  cost       NUMERIC(12, 2) NOT NULL DEFAULT 0,
  stock      INTEGER NOT NULL DEFAULT 0,
  low_stock  INTEGER NOT NULL DEFAULT 10,
  active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE stock_movements (
  id         SERIAL PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  delta      INTEGER NOT NULL,
  reason     TEXT NOT NULL,
  actor_id   INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- status: the operational pipeline
--   new -> confirmed | cancelled -> packed -> shipped -> delivered | returned
CREATE TABLE orders (
  id                SERIAL PRIMARY KEY,
  reference         TEXT NOT NULL UNIQUE,
  store_id          INTEGER NOT NULL REFERENCES stores(id),
  customer_id       INTEGER NOT NULL REFERENCES customers(id),
  status            TEXT NOT NULL CHECK (status IN ('new','confirmed','packed','shipped','delivered','cancelled','returned')),
  confirmation      TEXT NOT NULL CHECK (confirmation IN ('pending','confirmed','unreachable','cancelled','scheduled')),
  payment_method    TEXT NOT NULL DEFAULT 'cod' CHECK (payment_method IN ('cod','prepaid')),
  subtotal          NUMERIC(12, 2) NOT NULL DEFAULT 0,
  shipping_fee      NUMERIC(12, 2) NOT NULL DEFAULT 0,
  cod_fee           NUMERIC(12, 2) NOT NULL DEFAULT 0,
  total             NUMERIC(12, 2) NOT NULL DEFAULT 0,
  cogs              NUMERIC(12, 2) NOT NULL DEFAULT 0,
  assigned_agent_id INTEGER REFERENCES users(id),
  source            TEXT NOT NULL DEFAULT 'store',
  call_attempts     INTEGER NOT NULL DEFAULT 0,
  scheduled_for     TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX orders_status_idx ON orders(status);
CREATE INDEX orders_confirmation_idx ON orders(confirmation);
CREATE INDEX orders_created_idx ON orders(created_at DESC);

CREATE TABLE order_items (
  id         SERIAL PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  quantity   INTEGER NOT NULL,
  unit_price NUMERIC(12, 2) NOT NULL,
  unit_cost  NUMERIC(12, 2) NOT NULL DEFAULT 0
);

CREATE TABLE order_events (
  id         SERIAL PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  type       TEXT NOT NULL,
  message    TEXT NOT NULL,
  actor      TEXT NOT NULL DEFAULT 'system',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE call_attempts (
  id         SERIAL PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  agent_id   INTEGER REFERENCES users(id),
  outcome    TEXT NOT NULL CHECK (outcome IN ('confirmed','no_answer','cancelled','scheduled','wrong_number')),
  notes      TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE shipments (
  id            SERIAL PRIMARY KEY,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  carrier       TEXT NOT NULL,
  tracking_code TEXT NOT NULL UNIQUE,
  status        TEXT NOT NULL CHECK (status IN ('label_created','picked_up','in_transit','out_for_delivery','delivered','failed','returned')),
  cod_amount    NUMERIC(12, 2) NOT NULL DEFAULT 0,
  cod_collected BOOLEAN NOT NULL DEFAULT FALSE,
  shipped_at    TIMESTAMPTZ,
  delivered_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE returns (
  id            SERIAL PRIMARY KEY,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  reason        TEXT NOT NULL,
  status        TEXT NOT NULL CHECK (status IN ('requested','in_transit','received','restocked','refused')),
  refund_amount NUMERIC(12, 2) NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE whatsapp_conversations (
  id              SERIAL PRIMARY KEY,
  customer_id     INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  phone           TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','pending','closed')),
  unread          INTEGER NOT NULL DEFAULT 0,
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE whatsapp_messages (
  id              SERIAL PRIMARY KEY,
  conversation_id INTEGER NOT NULL REFERENCES whatsapp_conversations(id) ON DELETE CASCADE,
  direction       TEXT NOT NULL CHECK (direction IN ('in','out')),
  body            TEXT NOT NULL,
  author          TEXT NOT NULL DEFAULT 'customer',
  status          TEXT NOT NULL DEFAULT 'delivered' CHECK (status IN ('queued','sent','delivered','read','failed')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE message_templates (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  channel     TEXT NOT NULL DEFAULT 'whatsapp' CHECK (channel IN ('whatsapp','instagram','sms')),
  body        TEXT NOT NULL,
  category    TEXT NOT NULL DEFAULT 'operations',
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE automations (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  trigger     TEXT NOT NULL,
  action      TEXT NOT NULL,
  enabled     BOOLEAN NOT NULL DEFAULT TRUE,
  runs        INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE automation_runs (
  id            SERIAL PRIMARY KEY,
  automation_id INTEGER NOT NULL REFERENCES automations(id) ON DELETE CASCADE,
  order_id      INTEGER REFERENCES orders(id) ON DELETE SET NULL,
  result        TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
